# Layout Editor Theme Guide

## Quick Rebranding

To rebrand the Layout Editor for another app, edit only the **Brand Tokens** section in `nce/public/css/layout_editor_theme.css`:

### 1. Change Colors

```css
/* Find this section in the CSS file */
:root {
    /* Primary Brand Colors */
    --le-brand-primary: #YOUR_PRIMARY_COLOR;
    --le-brand-secondary: #YOUR_SECONDARY_COLOR;
    
    /* Neutral Colors */
    --le-color-gray-dark: #YOUR_DARK_GRAY;
    --le-color-gray-medium: #YOUR_MEDIUM_GRAY;
    --le-color-gray-light: #YOUR_LIGHT_GRAY;
}
```

### 2. Change Fonts

```css
/* Typography */
--le-font-family: 'YourFont', sans-serif;
--le-font-weight-normal: 400;
--le-font-weight-medium: 500;
--le-font-weight-bold: 600;
```

### 3. Done!

All UI elements automatically update with your new brand colors and fonts.

---

## Element → Style Mapping

This table shows which CSS variables control each UI element:

### Visual Panel Elements

| UI Element | CSS Class | Token Used | Example |
|------------|-----------|------------|---------|
| **Sections** |
| Section (odd) | `.le-section:nth-child(odd)` | `--le-section-bg-primary` | White background |
| Section (even) | `.le-section:nth-child(even)` | `--le-section-bg-alternate` | Light citron background |
| Section header | `.le-section-header` | `--le-section-header-*` | Charcoal with citron border |
| Section body | `.le-section-body` | Inherits from section | Padding container |
| **Columns** |
| Column 1 | `.le-column:nth-child(1)` | `--le-column-bg-1` | Subtle citron tint (30%) |
| Column 2 | `.le-column:nth-child(2)` | `--le-column-bg-2` | Medium citron tint (50%) |
| Column 3 | `.le-column:nth-child(3)` | `--le-column-bg-3` | Stronger citron tint (70%) |
| Column divider | `.le-column-divider` | `--le-column-divider` | Gray line between columns |
| **Fields** |
| Field (normal) | `.le-field` | `--le-field-*` | White with gray border |
| Field (hover) | `.le-field:hover` | `--le-selected-border` | Citron border |
| Field (selected) | `.le-field.selected` | `--le-selected-*` | Citron border + glow |
| Field icon | `.le-field-icon` | `--le-icon-*` | Color by field type |
| Field label | `.le-field-label` | `--le-field-text` | Charcoal text |
| Required indicator | `.le-field-required::after` | `--le-btn-danger-bg` | Red asterisk |
| **Drag & Drop** |
| Drag handle | `.le-drag-handle` | `--le-drag-handle` | Citron color |
| Drop zone (inactive) | `.le-drop-zone` | Transparent | No visible border |
| Drop zone (active) | `.le-drop-zone.active` | `--le-drop-zone-*` | Citron dashed border |

### Properties Panel Elements

| UI Element | CSS Class | Token Used | Example |
|------------|-----------|------------|---------|
| Panel background | `.layout-editor-properties-panel` | `--le-panel-bg` | Light gray |
| Panel border | Border | `--le-panel-border` | Medium gray line |
| Input field | `.le-input` | `--le-input-*` | White with gray border |
| Input (focused) | `.le-input:focus` | `--le-input-focus` | Citron border + glow |
| Select dropdown | `.le-select` | `--le-input-*` | Same as input |
| Textarea | `.le-textarea` | `--le-input-*` | Same as input |

### Buttons

| UI Element | CSS Class | Token Used | Example |
|------------|-----------|------------|---------|
| Primary button | `.le-btn-primary` | `--le-btn-primary-*` | Citron bg, charcoal text |
| Primary (hover) | `.le-btn-primary:hover` | `--le-btn-primary-hover` | Darker citron |
| Success button | `.btn-update-properties` | `--le-btn-success-*` | Green bg, white text |
| Secondary button | `.le-btn-secondary` | `--le-btn-secondary-*` | White bg, charcoal text |
| Secondary (hover) | `.le-btn-secondary:hover` | `--le-color-gray-light` | Light gray bg |
| Danger button | `.le-btn-danger` | `--le-btn-danger-*` | Red bg, white text |

### Tabs

| UI Element | CSS Class | Token Used | Example |
|------------|-----------|------------|---------|
| Tab (inactive) | `.le-tab` | `--le-tab-inactive` | Gray text |
| Tab (hover) | `.le-tab:hover` | `--le-tab-active` | Charcoal text |
| Tab (active) | `.le-tab.active` | `--le-tab-*` | Charcoal text, citron underline |

### Messages & Alerts

| UI Element | CSS Class | Token Used | Example |
|------------|-----------|------------|---------|
| Instructions box | `.layout-editor-instructions` | `--le-info-*` | Light citron bg |
| Error message | `.layout-editor-error` | `--le-error-*` | Red background |
| Success message | N/A (Frappe default) | `--le-success-*` | Green background |

### Field Type Icons

Each field type has its own color:

| Field Type | CSS Class | Token | Color |
|------------|-----------|-------|-------|
| Data, Text | `.le-icon-data` | `--le-icon-data` | Citron (#D7DF23) |
| Link | `.le-icon-link` | `--le-icon-link` | Blue (#0066cc) |
| Int, Float | `.le-icon-number` | `--le-icon-number` | Green (#28a745) |
| Date, Datetime | `.le-icon-date` | `--le-icon-date` | Purple (#6f42c1) |
| Select | `.le-icon-select` | `--le-icon-select` | Orange (#fd7e14) |
| Check | `.le-icon-check` | `--le-icon-check` | Citron (#D7DF23) |
| Table | `.le-icon-table` | `--le-icon-table` | Teal (#17a2b8) |

---

## Color Customization Strategies

### Strategy 1: Minimal (2-3 Colors)

Use your primary brand color for multiple purposes:

```css
:root {
    --le-brand-primary: #FF5733;        /* Your orange */
    --le-brand-secondary: #2C3E50;      /* Your dark gray */
    
    /* Reuse primary for accents */
    --le-brand-accent: #FF5733;         /* Same as primary */
    --le-drag-handle: #FF5733;          /* Same as primary */
    --le-icon-data: #FF5733;            /* Same as primary */
    --le-icon-check: #FF5733;           /* Same as primary */
}
```

**Result**: Clean, unified look with consistent branding.

---

### Strategy 2: Rich (5+ Colors)

Assign different colors to each UI element type:

```css
:root {
    --le-brand-primary: #FF5733;        /* Orange */
    --le-brand-secondary: #2C3E50;      /* Dark blue-gray */
    
    /* Unique colors for each icon type */
    --le-icon-data: #FF5733;            /* Orange */
    --le-icon-link: #3498db;            /* Blue */
    --le-icon-number: #2ecc71;          /* Green */
    --le-icon-date: #9b59b6;            /* Purple */
    --le-icon-select: #e67e22;          /* Dark orange */
    --le-icon-check: #1abc9c;           /* Teal */
    --le-icon-table: #34495e;           /* Dark gray */
}
```

**Result**: Colorful, information-rich interface. Users can identify field types by color.

---

### Strategy 3: Monochrome

Use shades of one color:

```css
:root {
    --le-brand-primary: #2C3E50;        /* Dark blue */
    --le-brand-secondary: #34495e;      /* Darker blue */
    
    /* All grays/blues */
    --le-color-gray-dark: #7f8c8d;      /* Medium blue-gray */
    --le-color-gray-medium: #bdc3c7;    /* Light blue-gray */
    --le-color-gray-light: #ecf0f1;     /* Very light blue-gray */
    
    /* Same color for all icons */
    --le-icon-data: #2C3E50;
    --le-icon-link: #2C3E50;
    --le-icon-number: #2C3E50;
    /* etc. */
}
```

**Result**: Minimalist, professional, distraction-free.

---

## Background Pattern Options

### Current: Alternating Sections + Progressive Columns

```css
/* Sections alternate between white and light citron */
.le-section:nth-child(odd) {
    background: var(--le-section-bg-primary);    /* White */
}

.le-section:nth-child(even) {
    background: var(--le-section-bg-alternate);  /* Light citron */
}

/* Columns get progressively more tinted */
.le-column:nth-child(1) { background: var(--le-column-bg-1); }  /* 30% */
.le-column:nth-child(2) { background: var(--le-column-bg-2); }  /* 50% */
.le-column:nth-child(3) { background: var(--le-column-bg-3); }  /* 70% */
```

### Alternative 1: All White

```css
:root {
    --le-section-bg-primary: #ffffff;
    --le-section-bg-alternate: #ffffff;
    --le-column-bg-1: transparent;
    --le-column-bg-2: transparent;
    --le-column-bg-3: transparent;
}
```

### Alternative 2: Subtle Borders Only

```css
:root {
    --le-section-bg-primary: #ffffff;
    --le-section-bg-alternate: #ffffff;
    --le-column-bg-1: transparent;
    --le-column-bg-2: transparent;
    --le-column-bg-3: transparent;
}

/* Add this CSS */
.le-section {
    border: 1px solid var(--le-color-gray-medium);
}

.le-column {
    border-right: 1px solid var(--le-color-gray-light);
}
```

---

## Typography Customization

### Change Font

```css
/* Replace Poppins with your font */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

:root {
    --le-font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}
```

### Adjust Font Weights

```css
:root {
    --le-font-weight-normal: 300;    /* Lighter */
    --le-font-weight-medium: 400;    /* Normal */
    --le-font-weight-bold: 600;      /* Semi-bold */
}
```

---

## Testing Your Theme

### 1. Change Brand Tokens

Edit the "Brand Tokens" section in `layout_editor_theme.css`

### 2. Clear Browser Cache

Hard refresh: `Cmd+Shift+R` (Mac) or `Ctrl+Shift+F5` (Windows)

### 3. Check These Elements

- [ ] Section headers (should use your secondary color)
- [ ] Selected fields (should use your primary color)
- [ ] Buttons (should use your primary color)
- [ ] Tab active state (should use your primary color underline)
- [ ] Drag handles (should use your primary color)
- [ ] Input focus (should use your primary color glow)

### 4. Test Alternating Backgrounds

- [ ] Odd sections (should be white or primary background)
- [ ] Even sections (should be alternate background)
- [ ] Columns (should have subtle progressive tinting)

---

## File Structure

```
nce_frappe_app/
├── nce/
│   └── public/
│       └── css/
│           ├── layout_editor_theme.css     ← THEME FILE (edit this)
│           ├── nce_theme.css               ← General app theme
│           └── NCE_BRAND_PALETTE.md        ← Brand colors reference
└── docs/
    ├── LAYOUT_EDITOR_THEME_GUIDE.md        ← This file
    └── VISUAL-LAYOUT-EDITOR-USER-MANUAL.md ← User guide
```

---

## Troubleshooting

### Theme Not Loading

1. Check CSS file path in `layout_editor.js`:
   ```javascript
   frappe.require('/assets/nce/css/layout_editor_theme.css');
   ```

2. Clear browser cache (hard refresh)

3. Check browser console for 404 errors

### Colors Not Changing

1. Verify you're editing **Brand Tokens** section (top of CSS)
2. Check for typos in hex codes (must start with `#`)
3. Clear browser cache
4. Inspect element in browser DevTools to see which CSS is applied

### Font Not Loading

1. Check `@import` URL is correct
2. Verify font name matches exactly (case-sensitive)
3. Include fallback fonts: `'YourFont', sans-serif`

---

## Example: Rebranding for "Acme Corp"

```css
/* Acme Corp Brand */
:root {
    /* Acme uses red and navy */
    --le-brand-primary: #E31B23;        /* Acme Red */
    --le-brand-secondary: #002B5C;      /* Acme Navy */
    
    /* Neutrals */
    --le-color-gray-dark: #4A4A4A;
    --le-color-gray-medium: #9B9B9B;
    --le-color-gray-light: #F5F5F5;
    
    /* Backgrounds - red tints */
    --le-bg-citron-ultra-light: #FFF5F5;  /* Very light red */
    --le-bg-citron-light: #FFE5E6;        /* Light red */
    
    /* Typography - Acme uses Montserrat */
    --le-font-family: 'Montserrat', Arial, sans-serif;
}

@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap');
```

**Result**: Layout Editor with red accents, navy text, and Montserrat font.

---

## Best Practices

### ✅ Do

- Keep primary color bright enough for contrast
- Use desaturated tints for backgrounds
- Test on different screen sizes
- Maintain sufficient color contrast (WCAG AA minimum)
- Document your color choices

### ❌ Don't

- Use pure bright colors for backgrounds (too intense)
- Set text and background to similar colors (poor contrast)
- Use more than 3-4 brand colors (too busy)
- Forget to test in light/dark mode (if applicable)

---

## Support

For questions about theming:
- Check this guide first
- Review `layout_editor_theme.css` comments
- See `NCE_BRAND_PALETTE.md` for NCE examples
- Test changes in browser DevTools before editing CSS

---

**Last Updated**: January 3, 2026  
**Theme Version**: 1.0  
**Compatible With**: Layout Editor v2.0+

