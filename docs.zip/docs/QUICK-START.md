# Quick Start - Deployment Guide

**5-Minute deployment guide for NCE Frappe App v0.0.2**

---

## Prerequisites

- ✅ Code ready in `nce_frappe_app/` folder
- ✅ WordPress site running (any hosting, including WP Engine)
- ✅ Frappe Cloud account with deployed site
- ✅ GitHub repository: https://github.com/oliver-nce/nce

---

## Step 1: WordPress Plugin (2 minutes)

### Upload Plugin

1. Copy file: `custom-sql-endpoint/custom-sql-endpoint.php`
2. Upload to WordPress: `wp-content/plugins/custom-sql-endpoint/`
3. Activate in WordPress admin: **Plugins → Installed Plugins**

### Create Application Password

1. Go to: **Users → Your Profile**
2. Scroll to: **Application Passwords**
3. Enter name: `Frappe Sync`
4. Click: **Add New Application Password**
5. **COPY THE PASSWORD** (you won't see it again!)

Example: `abcd efgh ijkl mnop qrst uvwx`

---

## Step 2: Deploy to Frappe Cloud (2 minutes)

### Push to GitHub

```bash
cd /Users/oliver2/_NCE_prjects/Frappe/nce_frappe_app
git add .
git commit -m "Migrate to REST API (v0.0.2)"
git push origin main
```

### Deploy

1. Go to: https://cloud.frappe.io/dashboard/groups/bench-29150
2. Click: **Deploy** button
3. Wait for completion (2-5 minutes)

---

## Step 3: Configure Frappe (1 minute)

### Update Settings

1. Open Frappe site
2. Search for: **WP Sync Settings**
3. Fill in:
   - **WordPress Site URL**: `https://yoursite.com` (no trailing slash!)
   - **WordPress Username**: Your WP admin username
   - **Application Password**: Paste the password from Step 1
4. Click: **Save**
5. Click: **Test Connection**
6. Verify: "Connected Successfully" ✅

---

## Step 4: Test Sync (1 minute)

### Run Test

1. Go to: **WP Sync Task**
2. Open existing task or create new one
3. Run manually (via API):

```python
# In Frappe Console
frappe.call("nce.wp_sync.api.run_task", task_name="YOUR_TASK_NAME")
```

### Verify

1. Check: **WP Sync Log** → Latest entry should be "Success"
2. Check: Target DocType → Data should appear
3. If successful: Enable scheduled sync ✅

---

## Step 5: Enable Scheduled Sync (30 seconds)

1. Go back to: **WP Sync Settings**
2. Check: **Enable Scheduled Sync**
3. Save
4. Done! Sync will run every 5 minutes automatically ✅

---

## Troubleshooting

### "Connection test failed"

```bash
# Test manually
curl -X POST https://yoursite.com/wp-json/custom/v1/sql-query \
  -u "username:app_password" \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT 1"}'

# Should return: {"result":[{"1":"1"}]}
```

**Fixes:**
- Verify URL (no trailing slash)
- Check plugin is activated
- Regenerate Application Password
- Remove spaces from password when testing with curl

### "401 Unauthorized"

- Wrong username or password
- Application Password not activated
- User doesn't have 'read' permission

### "Table not found"

- Add `wp_` prefix to table name
- Check table exists in WordPress database

---

## That's It!

Your sync should now be running automatically every 5 minutes.

### What to Monitor

- **WP Sync Log**: Check for errors
- **Target DocType**: Verify data is syncing
- **Error Log**: Watch for Python exceptions

### Next Steps

- Add more sync tasks for other tables
- Adjust sync interval if needed
- Set up monitoring/alerts

---

## Important Files Reference

```
WordPress:
  📄 wp-content/plugins/custom-sql-endpoint/custom-sql-endpoint.php

Frappe Cloud:
  📦 nce app (deployed via GitHub)
  ⚙️ WP Sync Settings (configuration)
  📋 WP Sync Task (task definitions)
  📊 WP Sync Log (execution logs)

Documentation:
  📖 README.md - Full documentation
  📖 DEPLOYMENT-CHECKLIST.md - Detailed checklist
  📖 MIGRATION_TO_REST_API.md - Migration guide
  📖 ARCHITECTURE.md - How it works
```

---

## API Quick Reference

```python
# Test connection
frappe.call("nce.wp_sync.api.test_wp_connection")

# Run single task
frappe.call("nce.wp_sync.api.run_task", task_name="YOUR_TASK")

# Run all tasks
frappe.call("nce.wp_sync.api.run_all_tasks")

# Get status
frappe.call("nce.wp_sync.api.get_sync_status")
```

---

## Need Help?

- **Full Guide**: See `DEPLOYMENT-CHECKLIST.md`
- **Migration**: See `MIGRATION_TO_REST_API.md`
- **Architecture**: See `ARCHITECTURE.md`

---

**Version:** 0.0.2  
**Last Updated:** 2025-12-28

✅ **Ready to Deploy!**

