# Frappe JavaScript Loading, Boot Info & Caching

**Created**: January 4, 2026  
**Source**: Research and testing during NCE app development  
**Purpose**: Technical reference for JavaScript patterns in Frappe Desk

---

## Table of Contents

1. [JavaScript Loading in Frappe](#javascript-loading-in-frappe)
2. [Boot Info (frappe.boot)](#boot-info-frappeboot)
3. [Caching Architecture](#caching-architecture)
4. [Patterns for Global UI Elements](#patterns-for-global-ui-elements)
5. [Common Mistakes](#common-mistakes)
6. [Best Practices](#best-practices)

---

## JavaScript Loading in Frappe

### Two Contexts: Website vs Desk

Frappe has two distinct JavaScript contexts:

| Context | URL Pattern | Ready Event | Boot Available |
|---------|-------------|-------------|----------------|
| **Website** (Portal) | `/`, `/about`, etc. | `frappe.ready()` | Limited |
| **Desk** (Admin) | `/app/*` | Form events, Page events | Full `frappe.boot` |

### The `app_include_js` Hook

In `hooks.py`:
```python
app_include_js = "/assets/myapp/js/myfile.js"
```

**When it loads:** The script is included in `desk.html` and executes when the page loads.

**Problem:** At execution time, `frappe.boot` may not yet be populated.

### Script Execution Timeline (Desk)

```
1. HTML loads
2. Frappe core JS loads
3. app_include_js files execute  ← frappe.boot NOT ready yet
4. Boot info fetched from server
5. frappe.boot populated
6. Desk renders
7. Page/Form events fire          ← frappe.boot IS ready
```

---

## Boot Info (frappe.boot)

### What is frappe.boot?

After successful login, Frappe injects a dictionary of global values called `bootinfo` into the Desk. This is available as `frappe.boot` in JavaScript.

### What it Contains

```javascript
frappe.boot = {
    // System defaults
    sysdefaults: {
        currency: "USD",
        country: "United States",
        // ...
    },
    
    // User info
    user: {
        name: "user@example.com",
        roles: ["System Manager", "..."],
        // ...
    },
    
    // Permissions
    user_permissions: { /* ... */ },
    
    // Notification status
    notification_info: { /* ... */ },
    
    // Language and timezone
    lang: "en",
    time_zone: "America/New_York",
    
    // Cached docs (frequently accessed)
    docs: [ /* ... */ ],
    
    // Custom data from extend_bootinfo hook
    // e.g., nce_version, nce_branch
};
```

### Adding Custom Data to Boot Info

In `hooks.py`:
```python
extend_bootinfo = "myapp.api.extend_bootinfo"
```

In `myapp/api.py`:
```python
def extend_bootinfo(bootinfo):
    """Add custom data to frappe.boot"""
    bootinfo.myapp_version = "1.0.0"
    bootinfo.myapp_config = {
        "feature_enabled": True,
        "api_url": "https://api.example.com"
    }
```

Access in JavaScript:
```javascript
// In a form event (safe - boot is ready)
frappe.ui.form.on('MyDocType', {
    refresh: function(frm) {
        console.log(frappe.boot.myapp_version);  // "1.0.0"
    }
});
```

---

## Caching Architecture

### Two Separate Cache Systems

```
┌─────────────────────────────────────────────────────────┐
│                      USER BROWSER                        │
│  ┌─────────────────────────────────────────────────┐   │
│  │              Browser Cache                        │   │
│  │  - JS files, CSS files, images                   │   │
│  │  - Controlled by HTTP headers                    │   │
│  │  - Cleared by: hard refresh, DevTools, settings │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────┐
│                    FRAPPE SERVER                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │              Redis Cache                          │   │
│  │  - DocType metadata                               │   │
│  │  - User permissions                               │   │
│  │  - Session data                                   │   │
│  │  - Method results (if cached)                    │   │
│  │  - Cleared by: bench clear-cache, API calls     │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

### Key Point: They Don't Sync Automatically

**Clearing server cache does NOT clear browser cache.**

When you run `bench clear-cache` or call a cache-clearing API:
- ✅ Server will send fresh data on next request
- ❌ Browser may still serve cached JS/CSS files

### Clearing Server Cache (Python)

```python
import frappe

@frappe.whitelist()
def clear_all_caches():
    """Clear all Frappe server-side caches"""
    frappe.clear_cache()           # General cache
    frappe.clear_document_cache()  # Document cache
    
    # For website cache
    from frappe.website.utils import clear_website_cache
    clear_website_cache()
    
    return {"success": True}
```

### Clearing Browser Cache (JavaScript)

```javascript
// Hard reload (bypasses browser cache)
window.location.reload(true);

// Or user can press:
// - Mac: Cmd + Shift + R
// - Windows/Linux: Ctrl + Shift + R
// - Or Ctrl + F5
```

### Complete Cache Clear Workflow

For users to get fresh code after deployment:

1. **Clear server cache** (via button, API, or `bench clear-cache`)
2. **Hard refresh browser** (`Cmd+Shift+R` or `reload(true)`)
3. **For other open tabs**: Manual hard refresh needed

---

## Patterns for Global UI Elements

### ❌ Anti-Pattern: Top-Level Boot Access

```javascript
// nce_version_badge.js - THIS DOESN'T WORK

$(document).ready(function() {
    // frappe.boot may be undefined here!
    const version = frappe.boot.nce_version;  // FAILS
    
    // Create badge...
});
```

### ❌ Anti-Pattern: frappe.ready() for Desk

```javascript
// THIS IS FOR WEBSITE PAGES, NOT DESK
frappe.ready(function() {
    // This never fires on /app/* pages
});
```

### ✅ Pattern 1: Form Event Handler

Best for UI elements that appear on specific forms:

```javascript
frappe.ui.form.on('WP Sync Settings', {
    refresh: function(frm) {
        // frappe.boot is guaranteed to be ready here
        const version = frappe.boot.nce_version;
        
        // Add button or UI element
        frm.fields_dict.my_html_field.$wrapper.html(
            '<button>Version: ' + version + '</button>'
        );
    }
});
```

### ✅ Pattern 2: Define Now, Call Later (ERPNext Style)

For utility functions that will be called from form events:

```javascript
// At top level - define the function
frappe.provide("myapp");

$.extend(myapp, {
    get_version: function() {
        // Called later when boot is ready
        return frappe.boot.myapp_version || 'unknown';
    },
    
    get_currency: function() {
        return frappe.boot.sysdefaults.currency;
    }
});

// In form event - call the function
frappe.ui.form.on('Sales Invoice', {
    refresh: function(frm) {
        console.log(myapp.get_currency());  // Works!
    }
});
```

### ✅ Pattern 3: Page Event Handler

For custom Desk pages:

```javascript
frappe.pages['my-custom-page'].on_page_load = function(wrapper) {
    // frappe.boot is ready here
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'My Page - v' + frappe.boot.myapp_version
    });
};
```

### ✅ Pattern 4: Router Event (Advanced)

For truly global elements, hook into page navigation:

```javascript
// Listen for route changes
$(document).on('page-change', function() {
    // Check if element exists, if not create it
    if (!$('#my-global-badge').length) {
        // frappe.boot should be ready by now
        $('body').append('<div id="my-global-badge">...</div>');
    }
});
```

---

## Common Mistakes

### 1. Using frappe.ready() for Desk

```javascript
// WRONG - frappe.ready is for website, not desk
frappe.ready(function() {
    // Never fires on /app/* pages
});
```

### 2. Accessing Boot at Load Time

```javascript
// WRONG - boot may not be ready
const config = frappe.boot.myapp_config;

// RIGHT - access in event handler
frappe.ui.form.on('MyDoc', {
    refresh: function(frm) {
        const config = frappe.boot.myapp_config;
    }
});
```

### 3. Using setTimeout as a Workaround

```javascript
// BAND-AID - works but fragile
setTimeout(function() {
    if (frappe.boot) {
        // Do something
    }
}, 500);  // What if boot takes longer?

// BETTER - use proper event handlers
```

### 4. Expecting Server Cache Clear to Update Browser

```python
# Clears server cache only
frappe.clear_cache()
# Browser still has old JS/CSS cached!
```

---

## Best Practices

### 1. For Form-Specific UI

Use form events - they guarantee `frappe.boot` is ready:

```javascript
frappe.ui.form.on('DocType Name', {
    refresh: function(frm) {
        // Safe to access frappe.boot here
    }
});
```

### 2. For Utility Functions

Define at load time, call from events:

```javascript
frappe.provide("myapp.utils");

myapp.utils.get_setting = function(key) {
    return frappe.boot.myapp_settings[key];
};
```

### 3. For Cache Clearing

Provide both server and browser cache clearing:

```javascript
frappe.call({
    method: 'myapp.api.clear_server_cache',
    callback: function(r) {
        if (r.message.success) {
            // Now clear browser cache by reloading
            window.location.reload(true);
        }
    }
});
```

### 4. For Multiple Tabs

Warn users that other tabs need manual refresh:

```javascript
frappe.show_alert({
    message: __('Cache cleared! Please hard-refresh other open tabs (Cmd+Shift+R)'),
    indicator: 'green'
}, 5);
```

---

## Quick Reference

### JavaScript Ready Events

| Event | Works On | Boot Ready? |
|-------|----------|-------------|
| `frappe.ready()` | Website only | Limited |
| `$(document).ready()` | Both | **No** |
| `frappe.ui.form.on('X', {refresh:})` | Desk forms | **Yes** |
| `frappe.pages['x'].on_page_load` | Custom pages | **Yes** |

### Cache Commands

| Action | Server Cache | Browser Cache |
|--------|--------------|---------------|
| `bench clear-cache` | ✅ Cleared | ❌ Not cleared |
| `frappe.clear_cache()` | ✅ Cleared | ❌ Not cleared |
| `window.location.reload(true)` | Not affected | ✅ Bypassed |
| `Cmd+Shift+R` | Not affected | ✅ Bypassed |

### Hooks Reference

```python
# hooks.py

# Include JS on all Desk pages
app_include_js = "/assets/myapp/js/myfile.js"

# Include CSS on all Desk pages
app_include_css = "/assets/myapp/css/myfile.css"

# Add data to frappe.boot
extend_bootinfo = "myapp.api.extend_bootinfo"

# Include JS on specific page
page_js = {"page_name": "public/js/page_script.js"}

# Include JS on specific DocType form
doctype_js = {"DocType Name": "public/js/doctype_script.js"}
```

---

## Related Documentation

- [Frappe Hooks Reference](https://docs.frappe.io/framework/user/en/python-api/hooks)
- [Frappe Caching Guide](https://docs.frappe.io/framework/user/en/guides/caching)
- [Frappe Asset Bundling](https://docs.frappe.io/framework/user/en/basics/asset-bundling)
- [Frappe Static Assets](https://docs.frappe.io/framework/user/en/basics/static-assets)

---

*Document based on practical testing and research, January 2026*

