# Frappe Cloud: Operations and Developer Tools

## Overview

Frappe Cloud provides operational tools for monitoring, debugging, and maintaining your sites and benches. This document covers backups, monitoring, database access, logs, and developer tools available through the dashboard.

## Backups

### Automated Backups

For sites on USD 25+ plans:

- Backups run every 24 hours
- No scheduled time (round-robin across all sites)
- Offsite storage on AWS S3

Each backup includes:

- **Database backup** — SQL dump of your MariaDB database
- **Public files backup** — Files in the public directory
- **Private files backup** — Files in the private directory

Backups are stored compressed (gzip).

### Backup Retention Policy

Frappe Cloud maintains backups with this rotation:

| Age | Frequency |
|-----|-----------|
| Last 7 days | Daily |
| 2-4 weeks | Weekly |
| 1-12 months | Monthly |
| Beyond 1 year | Yearly |

Maximum single backup size: 5 TB (AWS S3 limit).

### Manual Backups

Trigger a backup on-demand:

1. Go to Site Dashboard > **Backups** tab
2. Click **Schedule Backup**
3. Wait for the job to complete

Manual backups are queued and processed within minutes.

### Downloading Backups

Only **offsite** backups can be downloaded from the dashboard:

1. Go to Site Dashboard > Backups tab
2. Find the backup marked "offsite"
3. Click the download link for database, public, or private files

Onsite backups must be downloaded from within the site itself.

### Backup Encryption

Enable encrypted backups:

1. Go to Site Dashboard > Site Config
2. Add the `backup_encryption_key` configuration
3. Subsequent backups will be encrypted

Store your encryption key securely—Frappe Cloud cannot recover encrypted backups without it.

## Site Monitoring

### Overview Metrics

Available on USD 25+ plans via Site Dashboard > Monitoring:

- Request counts and response times
- CPU time usage
- Error rates
- Background job status

### Plan Limits

Sites are metered on:

- **CPU Time** — Web request processing time (resets daily)
- **Database Size** — Real database space usage
- **Storage** — Public and private file storage

Usage is updated daily in the dashboard.

### Resource Calculation

- CPU time: Only web requests (excludes background jobs)
- Database: Information schema table size
- Storage: Sum of public and private files (excludes local backups)

## Database Access

Available for sites on USD 50+ plans.

### Managing Database Users

1. Go to Site Dashboard > Actions > **Manage Database Users**
2. View existing users and their permissions
3. Click **Add User** to create a new database user

### Permission Types

- **Read Only** — View data, no modifications
- **Read Write** — Full access to all tables
- **Granular** — Fine-grained table/column access

### Granular Permissions

For detailed access control:

1. Select Granular mode when creating/editing a user
2. Wait for schema loading (30 seconds to 5 minutes)
3. Set Read Only or Read Write per table
4. Optionally restrict to specific columns

### Connecting to the Database

Use the MySQL/MariaDB client:

1. Get connection details from the database user settings
2. Connect using TLS:

```bash
mysql -h <host> -u <user> -p --ssl
```

Use the Let's Encrypt certificate chain for `*.frappe.cloud` domains.

### External Analytics Tools

Connect tools like:

- Frappe Insights
- Metabase
- Apache Superset
- Looker Studio
- Power BI
- Zoho Analytics

See specific documentation for each tool's connection process. All require TLS connections.

## Log Browser

Access application logs:

1. Go to Site Dashboard or Bench Dashboard
2. Navigate to **Logs** or use **Dev Tools > Log Browser**
3. Browse and search log entries

Available logs include:

- Web server logs
- Background job logs
- Error logs
- Scheduler logs

## Database Analyzer

Identify performance issues:

1. Go to Dev Tools > **Database Analyzer**
2. View slow queries and their frequency
3. Analyze query patterns

Use for:

- Finding slow queries
- Identifying missing indexes
- Optimizing database performance

## Site Process List

View running database processes:

1. Go to Dev Tools > **Site Process List**
2. See active connections and queries
3. Identify long-running queries

Useful for debugging performance issues and connection leaks.

## Binlog Browser

For dedicated database servers:

1. Go to Dev Tools > **Binlog Browser**
2. View binary log events
3. Track data changes

Useful for auditing and debugging data issues.

## Database Server Actions

For dedicated database servers:

- View server status
- Restart services (with downtime)
- Adjust configurations

Access via Server Dashboard > Database Server Actions.

## Performance Tuning

### DB Performance Tuning

1. Go to Site Dashboard > Actions > **DB Performance Tuning**
2. Review recommendations
3. Apply suggested optimizations

### Slow Query Monitoring

MariaDB logs queries exceeding thresholds:

- Enable via Site Config
- Review in Log Browser or Database Analyzer

### Common Optimizations

- Add missing indexes
- Optimize heavy queries
- Increase bufferpool size (dedicated servers)
- Configure query caching

## Version Upgrades

### Site Version Upgrade

1. Go to Site Dashboard > Actions > **Version Upgrade**
2. Review available versions
3. Click **Upgrade**

### Bench Version Upgrade

For private benches:

1. Update app versions in the bench group
2. Deploy the updated bench
3. Sites update automatically or manually

### Update Testing

Use staging environments to test upgrades before production.

## Server Scripts

Available on v15+ for sites on USD 25+ plans (private benches only):

1. Go to Site Dashboard > Actions > **Enable Server Script**
2. Enable the feature
3. Create server scripts within your Frappe site

Server scripts allow custom Python code execution within your site.

## Webhooks

Configure webhooks for event notifications:

1. Go to Settings > **Webhooks**
2. Add a webhook endpoint URL
3. Select events to trigger notifications

Available events include:

- Site creation/deletion
- Backup completion
- Deployment status
- Plan changes

### Webhook Logs

View webhook delivery attempts:

1. Go to Settings > Webhooks > **Attempt Logs**
2. Review delivery status and response codes
3. Debug failed deliveries

## Common Operational Tasks

### Restarting Site Services

For issues requiring a restart, contact support or use SSH access (private benches).

### Clearing Cache

Through your Frappe site:

1. Log in as Administrator
2. Go to Setup > Clear Cache

Or via bench CLI (SSH access required):

```bash
bench --site <sitename> clear-cache
```

### Running Bench Commands

With SSH access on private benches:

```bash
bench --site <sitename> migrate
bench --site <sitename> set-maintenance-mode on
bench --site <sitename> backup
```

### Debugging Errors

1. Check Site Dashboard > Activity for recent issues
2. Review logs in Log Browser
3. Check Database Analyzer for query issues
4. Use Site Process List for connection issues

## Static IP

For sites requiring a fixed IP address:

1. Go to Site Dashboard > Actions > **Obtain Static IP**
2. Review pricing and confirm
3. Wait for IP assignment

Use for:

- IP-based access controls
- External integrations requiring fixed IPs

## Email Configuration

### Email Delivery Service

Upgrade email sending capacity:

1. Go to Site Dashboard
2. Navigate to email plan settings
3. Upgrade the Email Delivery Service plan

### SMTP Configuration

Configure outgoing email in Site Config:

1. Add SMTP server settings
2. Configure authentication
3. Test email delivery

## Related Concepts

- **Backups** — Automated daily, offsite storage
- **Monitoring** — Resource usage tracking
- **Database Access** — Direct database connections
- **SSH Access** — Command-line access to benches
- **Webhooks** — Event-driven notifications
