# Frappe Migrations and Schema Auto-Deployment

## Overview

This document explains how Frappe Framework handles database schema migrations—a critical concept for understanding deployments on Frappe Cloud. When you deploy code changes, schema modifications happen automatically without manual database intervention.

## Core Concept: DocType-Driven Schema

Frappe uses a declarative approach to database schema management. Each DocType definition (stored as a JSON file in your app's source code) represents the complete schema for that entity. The framework compares these JSON definitions against the current database state during migrations.

### The DocType JSON File

When you create or modify a DocType in Developer Mode, Frappe generates a JSON file containing:

- Field definitions (name, type, constraints)
- Naming rules and autoname patterns
- Permission configurations
- Form layout metadata
- Link relationships to other DocTypes

Location: `[app]/[module]/doctype/[doctype_name]/[doctype_name].json`

### Database Table Naming

Frappe prefixes all DocType tables with `tab`. A DocType named "Sales Order" creates a table named `tabSales Order`. This convention applies universally—your custom DocTypes follow the same pattern.

## The Migration Process

### Triggering Migrations

Migrations run automatically when:

1. **App Installation**: `bench --site [site] install-app [app]`
2. **Site Migration**: `bench --site [site] migrate`
3. **Bench Update**: `bench update` (runs migrate on all sites)
4. **Frappe Cloud Deployments**: Automatically triggered after code pulls

### What Happens During Migration

The `bench migrate` command executes these steps in order:

1. **before_migrate hook**: Runs app-defined pre-migration code
2. **Patch execution**: Runs data migration scripts (pre_model_sync)
3. **Schema synchronization**: Compares DocType JSONs to database tables
4. **Fixture synchronization**: Imports predefined data records
5. **Post-model patches**: Runs remaining data migrations
6. **after_migrate hook**: Runs app-defined post-migration code

### Schema Comparison Method

Frappe computes an MD5 hash of each DocType JSON file and compares it against stored hashes in the database. If hashes differ, the framework reloads that DocType's schema. This checksum approach (introduced in v14) replaced the older timestamp-based comparison.

## Schema Change Behavior

### Adding Fields

New fields defined in the DocType JSON are added as columns to the corresponding database table. The column type maps from the Frappe fieldtype:

- Data → VARCHAR(140)
- Text → TEXT
- Int → INT
- Currency → DECIMAL
- Link → VARCHAR(140) (stores document name)
- Table → No column (child table reference)

### Removing or Renaming Fields

**Critical behavior**: Removing a field from the DocType JSON does NOT remove the database column. The column remains in the table but becomes invisible in the UI. This design:

- Prevents accidental data loss
- Allows patches to access old field values during migration
- Requires manual cleanup for permanent removal

### No Reverse Migrations

Frappe does not support automatic rollback of schema changes. If you need to revert a field change, you must create a new patch that reverses the modification manually.

## Data Patches

### Purpose

Patches handle data transformations that must accompany schema changes. Examples:

- Populating new required fields with default values
- Transforming data formats
- Migrating values between fields
- Cleaning up obsolete records

### Patch File Structure

```python
# [app]/patches/v14_0/update_status_field.py
import frappe

def execute():
    # Migration logic here
    frappe.db.sql("""
        UPDATE `tabSales Order`
        SET new_status = 'Draft'
        WHERE old_status = 0
    """)
```

### patches.txt Registration

Patches must be registered in `[app]/patches.txt`:

```
[pre_model_sync]
myapp.patches.v14_0.prepare_data_before_schema_change

[post_model_sync]
myapp.patches.v14_0.update_status_field
myapp.patches.v14_0.cleanup_old_records
```

### Execution Guarantees

- Each patch runs exactly once per site
- Execution is recorded in the Patch Log DocType
- Failed patches abort the migration (unless `--skip-failing` flag)
- Patches run in the order listed in patches.txt

## Frappe Cloud Deployment Context

On Frappe Cloud, migrations trigger automatically when you deploy updates to your bench. The sequence:

1. Code pulled from GitHub repository
2. Dependencies installed (Python/Node)
3. Assets built
4. `bench migrate` runs on each site
5. Workers restarted

### Implications for Development

- Test migrations locally before pushing to production branches
- Schema changes in your code propagate automatically—no manual ALTER TABLE required
- Data does not deploy with code; only structure definitions travel via JSON
- Plan patch scripts for any data transformations required by schema changes

## Related Documentation

- Frappe Cloud: Bench Groups and Apps (#03)
- Frappe Cloud: GitHub Integration (#04)
- Code vs Data Deployment Concepts (#10)

## Sources

- https://docs.frappe.io/framework/user/en/database-migrations
- https://docs.frappe.io/framework/user/en/guides/deployment/migrations
- https://docs.frappe.io/framework/user/en/basics/doctypes
