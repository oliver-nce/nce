# Frappe Workspace: Blocks Reference

**Source:** Official Frappe Framework Documentation  
**Verified:** December 2024

---

## What are Blocks?

Blocks are the building blocks of a workspace page. You add, edit, arrange, and resize them to create a customized workspace layout.

**Current block count:** 9 block types available

---

## Overview: Settings Panel Tabs

When you open workspace settings (as shown in your screenshot), the tabs correspond to block types:

| Tab | Corresponding Block |
|-----|---------------------|
| Shortcuts | Shortcut block |
| Number Cards | Number Card block |
| Dashboards | Chart block |
| Link Cards | Card block |
| Quick Lists | Quick List block |
| Custom Blocks | Various (Heading, Text, Spacer) |

---

## Block Types in Detail

### 1. Heading Block
**Purpose:** Section headers or paragraph headers

**Features:**
- Inline toolbar for formatting
- Sizes from H1 to H6
- Bold, italic, and link formatting

**Use case:** Organize workspace into labeled sections

---

### 2. Text Block
**Purpose:** Paragraphs or descriptions

**Features:**
- Same inline toolbar as Heading
- Bold, italic, link formatting
- Multi-line text support

**Use case:** Add explanatory text or instructions

---

### 3. Card Block
**Purpose:** Grouped navigation links

**Features:**
- Contains multiple link items
- Each link can be a DocType, Report, or Page
- Visual card-style presentation

**Use case:** Create categorized navigation menus

---

### 4. Chart Block
**Purpose:** Display Dashboard Charts

**Features:**
- Connects to existing Dashboard Chart documents
- Visual data representation
- Auto-updates with data changes

**Use case:** Show metrics, trends, KPIs on workspace

---

### 5. Shortcut Block
**Purpose:** Quick navigation to specific views

**Features:**
- Links to DocType, Report, or Page
- **Customizable view selection** (List, Report, etc.)
- **Filter support** - apply filters when opening
- **Count pill** - shows record count based on filters

**Configuration options:**
- Link To: Select the target DocType/Report/Page
- Label: Display name
- Type: Defines the view type
- Filters: Pre-applied filters when clicked

**Use case:** One-click access to filtered lists (e.g., "Open Tasks", "Pending Invoices")

---

### 6. Spacer Block
**Purpose:** Add visual spacing between blocks

**Features:**
- Creates empty space
- Used for layout positioning
- Can add whitespace before/after other blocks

**Use case:** Improve visual organization and readability

---

### 7. Onboarding Block
**Purpose:** Guide new users through setup steps

**Features:**
- Step-by-step instruction format
- Description panel on right side
- Can include video links
- Shows completion status

**Use case:** Training modules, setup wizards

---

### 8. Quick List Block
**Purpose:** Display recent records from a DocType

**Features:**
- Shows recently updated records
- Filter support
- Read-only mode includes:
  - Refresh button
  - Filter update option
  - Create new record button
  - Link to full list view

**Use case:** Dashboard-style recent activity view

---

### 9. Number Card Block
**Purpose:** Display metric numbers

**Features:**
- Connects to existing Number Card documents
- Shows calculated values
- Visual metric presentation

**Use case:** KPI display (e.g., "Total Sales", "Open Tasks")

---

## Adding Blocks (Edit Mode)

**Note:** Adding blocks must be done in Edit Mode, not the Settings panel.

**Steps:**
1. On the workspace page, click **Edit**
2. Click the **+** button or use the block picker
3. Select the block type
4. Configure the block properties
5. Click **Save**

---

## Next Document
Continue to **03-workspace-customization-guide.md** for step-by-step customization procedures.
