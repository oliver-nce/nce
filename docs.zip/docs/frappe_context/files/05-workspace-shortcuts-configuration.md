# Frappe Workspace: Shortcuts Configuration

**Source:** Official Frappe Framework Documentation  
**Verified:** December 2024

---

## What is a Shortcut?

A Shortcut block provides quick navigation to any DocType, Report, or Page. It's one of the most useful blocks for daily workflow optimization.

**Key feature:** Shortcuts can include pre-applied filters, so clicking them opens a filtered view immediately.

---

## Shortcut Block Features

| Feature | Description |
|---------|-------------|
| Link To | Target DocType, Report, or Page |
| Label | Display name shown on workspace |
| Type | The view to open (List, Report, etc.) |
| Filters | Pre-applied filters |
| Count Pill | Shows record count matching filters |

---

## Accessing Shortcuts Tab

From your screenshot, the **Shortcuts** tab in workspace settings shows:

- List of defined shortcuts
- Each shortcut's configuration
- Add/remove shortcut rows

**Remember:** This tab defines shortcuts, but positioning happens in Edit mode.

---

## Adding a Shortcut (Settings Panel Method)

### Step 1: Open Settings
1. Navigate to your workspace
2. Click settings/gear icon (or three dots → Settings)

### Step 2: Go to Shortcuts Tab
1. Click **Shortcuts** tab
2. You see existing shortcuts listed

### Step 3: Add New Shortcut
1. Click **Add Row** or **+** button
2. Fill in fields:

| Field | Value Example |
|-------|---------------|
| Label | "My Open Tasks" |
| Link To | Task |
| Type | List |

### Step 4: Add Filters (Optional)
In the filter field, enter JSON:
```json
{"status": "Open"}
```

### Step 5: Save
Click **Save** button

---

## Adding a Shortcut (Edit Mode Method)

### Step 1: Enter Edit Mode
1. Go to workspace
2. Click **Edit** button

### Step 2: Add Block
1. Click **+** or block picker
2. Select **Shortcut**

### Step 3: Configure
1. Click the new shortcut block
2. Set Link To, Label, Type
3. Configure filters if needed

### Step 4: Position
1. Drag shortcut to desired location
2. Resize if needed

### Step 5: Save
Click **Save**

---

## Shortcut Configuration Options

### Link To Options
| Option | Opens |
|--------|-------|
| DocType | List view of that DocType |
| Report | Report view |
| Page | Custom page |

### Type Options (for DocTypes)
| Type | Result |
|------|--------|
| List | Standard list view |
| Report Builder | Report Builder interface |
| Dashboard | DocType dashboard |
| New | New document form |

---

## Filter Syntax

Filters use JSON format. Common patterns:

### Simple Equality
```json
{"status": "Open"}
```

### Multiple Conditions (AND)
```json
{"status": "Open", "priority": "High"}
```

### Using Current User
```json
{"owner": "session_user"}
```
Or for assigned_to:
```json
{"_assign": ["like", "%session_user%"]}
```

### Date Filters
```json
{"due_date": ["<", "2024-12-31"]}
```

### Filter Operators
| Operator | Example |
|----------|---------|
| `=` (default) | `{"status": "Open"}` |
| `!=` | `{"status": ["!=", "Closed"]}` |
| `<` | `{"amount": ["<", 1000]}` |
| `>` | `{"amount": [">", 1000]}` |
| `like` | `{"name": ["like", "%sales%"]}` |
| `in` | `{"status": ["in", ["Open", "Pending"]]}` |

---

## Count Pill Feature

### What It Shows
A small badge on the shortcut showing how many records match the filters.

### Automatic Behavior
- Updates periodically
- Uses the same filters as the shortcut

### Example
Shortcut "Open Invoices" with filter `{"status": "Unpaid"}` shows **(23)** if there are 23 unpaid invoices.

---

## Common Shortcut Examples

### Example 1: My Tasks
```
Label: My Tasks
Link To: Task
Type: List
Filters: {"_assign": ["like", "%session_user%"]}
```

### Example 2: Urgent Items
```
Label: Urgent
Link To: Task
Type: List
Filters: {"priority": "Urgent", "status": ["!=", "Completed"]}
```

### Example 3: Today's Appointments
```
Label: Today
Link To: Event
Type: List
Filters: {"starts_on": [">=", "today"]}
```

### Example 4: Quick Create
```
Label: + New Customer
Link To: Customer
Type: New
Filters: (none needed)
```

---

## Shortcuts vs Link Cards

| Shortcut | Link Card |
|----------|-----------|
| Single clickable item | Group of related links |
| Shows count pill | No count display |
| Supports filters | Links only, no filters |
| Prominent display | Compact grouped display |

**When to use which:**
- **Shortcuts:** For frequently accessed filtered views
- **Link Cards:** For organizing navigation by category

---

## Troubleshooting Shortcuts

### Shortcut Shows Wrong Count
- Check filter syntax (must be valid JSON)
- Verify field names match DocType fields

### Shortcut Opens Empty List
- Filters might be too restrictive
- Check if DocType has any records
- Verify user has permission to view DocType

### Shortcut Not Appearing
- Did you save in Edit mode?
- Is the workspace saved?
- Check role restrictions on workspace

---

## Next Document
Continue to **06-workspace-troubleshooting.md** for common issues and solutions.
