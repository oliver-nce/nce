# Frappe Workspace: Customization Guide

**Source:** Official Frappe Framework Documentation  
**Verified:** December 2024

---

## Two Types of Customization

Frappe workspaces have **two distinct customization scopes**:

| Scope | What You Customize | Where |
|-------|-------------------|-------|
| Workspace Customization | Sidebar items, workspace properties | Sidebar menu |
| Workspace Page Customization | Blocks on the page itself | Edit mode |

**Critical distinction:** Save/Discard buttons only apply to **page customizations**. Sidebar changes save automatically.

---

## Workspace Customization (Sidebar)

All these actions are done via the sidebar, **except** creating new workspaces.

### Edit Workspace Details
**What you can change:**
- Title
- Icon
- Parent/child relationship
- Public or private status

**Steps:**
1. Right-click workspace in sidebar (or use menu)
2. Select **Edit**
3. Modify fields
4. Changes save automatically

### Create Duplicate Workspace
**Purpose:** Copy an existing workspace and modify it

**Steps:**
1. Right-click the workspace to duplicate
2. Select **Duplicate**
3. A copy is created
4. Edit the copy as needed

**Use case:** Create role-specific versions of standard workspaces

### Delete Workspace
**Steps:**
1. Right-click the workspace
2. Select **Delete**
3. Confirm deletion

**Warning:** This cannot be undone

### Hide Workspace
**Who can hide what:**
- Any user can hide their private workspaces
- Only **Workspace Manager** role can hide public workspaces

**Steps:**
1. Right-click the workspace
2. Select **Hide**
3. Workspace disappears from sidebar

### Rearrange Position
**Method:** Drag and drop in the sidebar

**Capabilities:**
- Change order of workspaces
- Move workspace to become child of another (indent)
- Move child to become parent (outdent)

---

## Workspace Page Customization (Edit Mode)

### Enter Edit Mode
1. Navigate to the workspace
2. Click the **Edit** button (top right area)

### Add a New Block
1. In Edit mode, click **+** or use block picker
2. Select block type (see Document 02 for block types)
3. Configure the block
4. Block appears on page

### Edit an Existing Block
1. In Edit mode, click on the block
2. Edit panel appears
3. Make changes
4. Changes reflect immediately

### Delete a Block
1. In Edit mode, select the block
2. Click delete icon or press Delete
3. Block is removed

### Resize Block Width
**Method:** Drag the block edges

**Grid system:** Blocks snap to grid positions for alignment

### Rearrange Blocks
**Method:** Drag and drop blocks

**Steps:**
1. In Edit mode, click and hold a block
2. Drag to new position
3. Release to drop

### Save Changes
**Important:** Page customizations require explicit save

1. Make all your changes
2. Click **Save** button
3. Or click **Discard** to abandon changes

---

## Settings Panel vs Edit Mode (Recap)

From Document 01, the Settings panel (your screenshot) has limited functionality:

| Settings Panel Tabs | What You Can Do |
|---------------------|-----------------|
| Details | Title, icon, module |
| Shortcuts | Add shortcut definitions |
| Link Cards | Add card link definitions |
| Number Cards | Add number card references |
| Quick Lists | Add quick list definitions |
| Roles | Configure access |

**Limitation:** You cannot position blocks visually from Settings. The system doesn't know where to place them on the page.

**Best practice:** Use Settings to define what items exist, then use Edit mode to arrange them visually.

---

## Common Customization Workflows

### Workflow 1: Add a Shortcut with Filter
1. Go to workspace → Click **Edit**
2. Add Shortcut block
3. Set Link To: (e.g., "Task")
4. Set Label: (e.g., "My Open Tasks")
5. Set Filters: `{"status": "Open", "assigned_to": ["like", "%user%"]}`
6. Save

### Workflow 2: Create a Dashboard-Style Workspace
1. Create new workspace
2. Add Number Card blocks for key metrics
3. Add Chart blocks for trends
4. Add Quick List blocks for recent activity
5. Use Spacer blocks for layout
6. Add Heading blocks for sections
7. Save

---

## Next Document
Continue to **04-workspace-access-permissions.md** for role-based access control.
