# Frappe Workspace: Troubleshooting Guide

**Source:** Official Frappe Framework Documentation + Community Reports  
**Verified:** December 2024

---

## Common Issues & Solutions

### Issue 1: "Create Workspace" Button Not Visible

**Symptom:** You have Workspace Manager role but cannot find the Create button.

**Known bug:** In Frappe v15.31+, the Create Workspace button sometimes fails to render.

**Workarounds:**

**Solution A - Direct URL:**
```
/app/workspace/new-workspace-1
```
Navigate to this URL directly to create a new workspace.

**Solution B - Duplicate Existing:**
1. Right-click any existing workspace in sidebar
2. Select **Duplicate**
3. Rename and customize the copy

**Solution C - Edit Mode Creation:**
1. Enter Edit mode on any workspace
2. Access creation through sidebar options

---

### Issue 2: Cannot Save Workspace Customizations

**Symptom:** Changes don't persist after clicking Save.

**Possible causes:**

1. **Missing Workspace Manager role** (for public workspaces)
   - Solution: Get role assigned by administrator

2. **Browser cache issue**
   - Solution: Hard refresh (Ctrl+Shift+R) or clear cache

3. **JavaScript errors**
   - Solution: Check browser console (F12), report to support

4. **Permission restrictions**
   - Solution: Verify user permissions on workspace DocType

---

### Issue 3: Blocks Not Appearing After Adding from Settings

**Symptom:** Added shortcuts/cards in Settings panel but they don't show on workspace.

**Explanation from docs:** "Adding new blocks from the workspace document will not work as the new workspace doesn't know exactly where to add that block."

**Solution:** Use Edit mode on the workspace page, not the Settings panel.

**Correct workflow:**
1. Go to workspace → Click **Edit**
2. Use **+** to add blocks
3. Position blocks visually
4. Click **Save**

---

### Issue 4: Shortcut Shows Wrong Record Count

**Symptom:** Count pill displays incorrect number.

**Causes and solutions:**

| Cause | Solution |
|-------|----------|
| Invalid JSON in filters | Verify JSON syntax |
| Wrong field names | Check DocType field names |
| Cache delay | Wait or refresh page |
| Permission limits | User may only see subset of records |

**Debug steps:**
1. Open shortcut target directly
2. Apply same filters manually
3. Compare counts
4. Adjust filter JSON as needed

---

### Issue 5: Workspace Not Visible to User

**Symptom:** User reports workspace is missing from sidebar.

**Checklist:**

| Check | How |
|-------|-----|
| Public vs Private | Private workspaces only visible to owner |
| Module access | User needs module enabled in profile |
| Role restrictions | Workspace may require specific role |
| Hidden status | Workspace might be hidden |

**Resolution:**
1. Open workspace settings
2. Check if it's public
3. Review Roles tab
4. Check user's module access
5. Verify workspace isn't hidden

---

### Issue 6: Cannot Delete or Edit Workspace

**Symptom:** Options are grayed out or missing.

**Causes:**

| Cause | Solution |
|-------|----------|
| Not Workspace Manager | Need role for public workspaces |
| Standard workspace | Some system workspaces are protected |
| Not the owner | Private workspaces only editable by owner |

---

### Issue 7: Blocks Merge or Disappear on Save

**Historical bug:** In some v14 beta versions, blocks merged unexpectedly.

**If experiencing:**
1. Update to latest Frappe version
2. Clear browser cache
3. Try different browser
4. Report to Frappe GitHub if persists

---

## Settings Panel Limitations (Recap)

The blue banner in your screenshot explains the limitation:

> "This document allows you to edit limited fields. For all kinds of workspace customization, use the Edit button located on the workspace page"

**What Settings CAN do:**
- Define shortcut/card/number card items
- Set workspace metadata (title, icon)
- Configure role access

**What Settings CANNOT do:**
- Position blocks on page
- Set block sizes
- Arrange visual layout

---

## Required Permissions Summary

| Action | Required |
|--------|----------|
| Create private workspace | Any user |
| Edit private workspace | Owner only |
| Create public workspace | Workspace Manager role |
| Edit public workspace | Workspace Manager role |
| Delete workspace | Owner (private) or Workspace Manager (public) |
| Hide public workspace | Workspace Manager role |

---

## Browser Troubleshooting

### Clear Cache Steps
1. Open browser settings
2. Find "Clear browsing data"
3. Select "Cached images and files"
4. Clear for the site

### Check Console for Errors
1. Press F12 to open Developer Tools
2. Click **Console** tab
3. Look for red error messages
4. Report errors to support with screenshot

### Try Incognito Mode
If issues persist:
1. Open incognito/private window
2. Log into Frappe
3. Test workspace functionality
4. If it works in incognito, clear regular browser cache

---

## Getting Help

### Community Forum
- https://discuss.frappe.io
- Search for workspace issues
- Post with Frappe version details

### GitHub Issues
- https://github.com/frappe/frappe/issues
- Check existing issues first
- Include version, steps to reproduce

### Required Information for Support
- Frappe Framework version
- ERPNext version (if applicable)
- Browser and version
- Steps to reproduce
- Screenshots
- Console errors

---

## Quick Reference: Edit Mode vs Settings

| Task | Use Edit Mode | Use Settings |
|------|---------------|--------------|
| Add block to page | ✓ | ✗ |
| Position blocks | ✓ | ✗ |
| Resize blocks | ✓ | ✗ |
| Define shortcut items | Both work | ✓ |
| Set workspace title | ✗ | ✓ |
| Configure roles | ✗ | ✓ |
| Change icon | ✗ | ✓ |

**Remember:** For visual customization, always use Edit mode on the workspace page.
