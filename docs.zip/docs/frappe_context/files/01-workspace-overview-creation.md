# Frappe Workspace: Overview & Creation

**Source:** Official Frappe Framework Documentation  
**Verified:** December 2024

---

## What is a Workspace?

A Workspace is the first page you see when you log into Frappe Desk. It serves as a customizable landing page with navigation tools organized in a sidebar.

**Key characteristics:**
- Tool to build user-specific pages
- Has a dedicated sidebar for navigation
- Supports drag-and-drop positioning
- Built using configurable "blocks"

---

## Workspace Types

### PUBLIC Workspaces
- Standard workspaces visible to all users
- Listed in the PUBLIC section of the sidebar
- Require **Workspace Manager** role to create, edit, or delete

### MY WORKSPACES (Private)
- Only visible to the logged-in user who created them
- Listed in the MY WORKSPACES section
- Any user can create private workspaces for themselves

---

## How to Create a New Workspace

### Step 1: Access Creation
Navigate to any workspace, then use one of these methods:

**Method A - Via URL (most reliable):**
```
/app/workspace/new-workspace-1
```
Type this directly in your browser after your site domain.

**Method B - Via Edit Mode:**
1. Click the **Edit** button on any existing workspace
2. The Create Workspace option appears in the sidebar

### Step 2: Enter Basic Details
1. Enter a **Title** for your workspace
2. Click **Create**

### Step 3: Configure in Settings Panel
The Settings panel (shown in your screenshot) has these tabs:

| Tab | Purpose |
|-----|---------|
| Details | Title, icon, module, parent workspace |
| Number Cards | Add metric cards |
| Dashboards | Add dashboard visualizations |
| Shortcuts | Quick navigation links |
| Link Cards | Grouped navigation links |
| Quick Lists | Recent records display |
| Custom Blocks | Custom HTML/content |
| Roles | Access control |

---

## Creating a Child Workspace

To create a workspace nested under another:

1. Click **Create Workspace**
2. Enter a Title
3. In the **Parent** field, select the parent workspace (e.g., "Home")
4. Click **Create**

Child workspaces appear indented under their parent in the sidebar.

---

## The Settings Panel vs. Edit Mode

**Important distinction from your screenshot:**

The blue banner states: *"This document allows you to edit limited fields. For all kinds of workspace customization, use the Edit button located on the workspace page"*

This means:

| Settings Panel | Edit Mode (Workspace Builder) |
|----------------|-------------------------------|
| Edit basic metadata | Full block customization |
| Add items to tabs | Position blocks visually |
| Configure role access | Resize and rearrange blocks |
| Limited functionality | Full drag-and-drop builder |

**Best practice:** Use the visual Edit mode on the workspace page for most customization tasks, not the Settings panel.

---

## Required Role

To create or edit **public** workspaces, your user account needs the **Workspace Manager** role assigned.

Private workspaces can be created by any user without special roles.

---

## Next Document
Continue to **02-workspace-blocks-reference.md** for details on each block type you can add to your workspace.
