# Frappe Workspace: Access & Permissions

**Source:** Official Frappe Framework Documentation  
**Verified:** December 2024

---

## Access Control Overview

Workspaces can be restricted based on two mechanisms:
1. **Module access**
2. **Role restrictions**

Both work together to control who sees what.

---

## Module-Based Access

### How It Works
- Users have specific modules enabled in their profile
- Standard workspaces are tied to modules
- If a user loses module access, they lose workspace visibility

### Example
| User | Module Access | Sees Workspace? |
|------|---------------|-----------------|
| John | Website module enabled | Yes - Website workspace visible |
| John | Website module removed | No - Website workspace hidden |

### Configure Module Access
1. Go to **User** doctype
2. Open user record
3. Find **Allow Modules** section
4. Check/uncheck modules

---

## Role-Based Access

### When to Use
Use roles when you want to:
- Show workspace to users WITH a specific role
- Hide workspace from users WITHOUT a specific role
- Fine-tune access beyond module settings

### How It Works
Even if a user has module access, you can add role requirements.

### Example Configuration
**Scenario:** Only users with "Website Manager" role should see Website Workspace

**Setup:**
1. Open Workspace settings
2. Go to **Roles** tab
3. Add role: "Website Manager"
4. Save

**Result:**
| User | Module Access | Role | Sees Workspace? |
|------|---------------|------|-----------------|
| Jane | Website ✓ | No Website Manager role | No |
| John | Website ✓ | Website Manager ✓ | Yes |

---

## The Roles Tab in Settings

From your screenshot, the **Roles** tab allows you to:

1. **Add allowed roles** - Only users with these roles see the workspace
2. **Remove roles** - Anyone with module access can see it

### Configuring Roles
1. Open workspace settings
2. Click **Roles** tab
3. Add row
4. Select role from dropdown
5. Save

---

## Workspace Manager Role

**Critical role for workspace administration**

### Capabilities
- Create public workspaces
- Edit public workspaces
- Delete public workspaces
- Hide public workspaces

### Without Workspace Manager
- Can only create private workspaces
- Can only edit own private workspaces
- Cannot modify public workspaces

### Assigning the Role
1. Go to **User** doctype
2. Open user record
3. Go to **Roles** section
4. Add "Workspace Manager"
5. Save

---

## Default Workspace Setting

### What It Does
Sets which workspace appears when user first logs in.

### Default Behavior
Without configuration, users see the workspace they were last viewing.

### Configure Default Workspace
1. Click avatar → **My Settings**
2. Find **Default Workspace** field
3. Select preferred workspace
4. Save

---

## PUBLIC vs MY WORKSPACES (Recap)

| Section | Visibility | Who Can Create | Who Can Edit |
|---------|------------|----------------|--------------|
| PUBLIC | All users (with access) | Workspace Manager | Workspace Manager |
| MY WORKSPACES | Only owner | Any user | Owner only |

---

## Access Control Decision Tree

```
User tries to access workspace
         │
         ▼
    Is it PUBLIC?
    ┌────┴────┐
   Yes       No (Private)
    │         │
    ▼         ▼
Module     Is user the owner?
enabled?   ┌────┴────┐
    │     Yes       No
    ▼      │         │
Role      Show    Hide
required?  workspace
    │
    ▼
Has role?
┌───┴───┐
Yes    No
 │      │
Show  Hide
```

---

## Common Access Scenarios

### Scenario 1: Department-Specific Workspace
**Goal:** Only HR department sees HR Dashboard workspace

**Solution:**
1. Create workspace
2. Set module to HR (if applicable)
3. Add "HR Manager" or "HR User" role in Roles tab

### Scenario 2: Manager-Only Workspace
**Goal:** Only managers see performance metrics

**Solution:**
1. Create workspace with Number Cards and Charts
2. Add manager-level roles in Roles tab
3. Standard users won't see it

### Scenario 3: User-Specific Personal Dashboard
**Goal:** User has own customized workspace

**Solution:**
1. User creates workspace (goes to MY WORKSPACES)
2. Only that user can see it
3. No role configuration needed

---

## Next Document
Continue to **05-workspace-shortcuts-configuration.md** for detailed shortcut setup procedures.
