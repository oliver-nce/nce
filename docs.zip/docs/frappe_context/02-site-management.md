# Frappe Cloud: Site Management

## Overview

Sites are the fundamental unit in Frappe Cloud. Each site is a complete Frappe installation with its own database, configuration, and set of installed apps. This document covers site creation, configuration, and common management tasks through the Frappe Cloud dashboard.

## Creating a New Site

### Via the Dashboard

1. Navigate to the **Sites** tab in the dashboard
2. Click the **New Site** button
3. Select the apps to install (e.g., ERPNext, Wiki, CRM)
4. Choose the **site version** (Frappe Framework version)
5. Select the **region** for deployment
6. Choose a **plan** appropriate for your needs
7. Enter a unique **hostname** (5-32 characters, lowercase letters, numbers, hyphens only; cannot start or end with hyphens)
8. Click **Create**

Site creation takes a few seconds to a few minutes depending on the selected apps. All sites are provisioned with HTTPS automatically.

### After Creation

After the site is created:

1. Click **Visit Site** to access it
2. Log in and complete the **setup wizard**
3. Analytics collection begins only after setup is complete

## Site Dashboard Sections

Each site has a dashboard with multiple tabs:

### Overview Tab

Displays site status, current plan, resource usage (CPU, database size, storage), and quick actions.

### Apps Tab

Lists installed apps with their versions. From here you can:

- View app details
- Uninstall apps (via Actions menu)

### Backups Tab

Shows backup history. Actions available:

- View list of database, public files, and private files backups
- **Schedule Backup** — Trigger a manual backup
- Download offsite backups (USD 25+ plans)

Automated backups run every 24 hours for sites on USD 25+ plans.

### Site Config Tab

Edit site configuration values:

1. Navigate to Site Dashboard > Site Config
2. Enter values in the configuration fields
3. Click **Update Configuration**

Common configuration options include:

- Email account settings
- Encryption keys
- Custom environment variables

**Note:** Developer mode cannot be enabled on Frappe Cloud directly. Custom development must be done in a custom app.

### Monitoring Tab

View site metrics including:

- Request counts and response times
- CPU usage
- Error rates
- Background job status

Available for sites on USD 25+ plans.

### Activity Tab

Shows recent operations performed on the site, including backups, updates, and configuration changes.

### Jobs Tab

Lists scheduled and background jobs with their status.

## Common Site Operations

### Changing Site Plan

1. Go to Site Dashboard
2. Navigate to **Actions** (dropdown or menu)
3. Select **Change Plan**
4. Choose the new plan
5. Confirm the change

Plan changes are instantaneous with no downtime.

### Adding Custom Domains

1. Create DNS records with your domain provider:
   - **Subdomain**: Add a CNAME record pointing to `yoursite.frappe.cloud`
   - **Root domain**: Add an A record to the provided IP address
2. Go to Site Dashboard > **Domains**
3. Click **Add Domain**
4. Enter the domain name
5. Wait for SSL certificate provisioning (automatic)

You can:

- Set a **primary domain** for redirects
- Enable **redirection** for domains you want to hide
- Configure multiple domains per site (unlimited)

### Version Upgrade

To upgrade to a newer Frappe Framework version:

1. Go to Site Dashboard > Actions > **Version Upgrade**
2. Review available versions
3. Click **Upgrade** if an update is available

For sites on private benches, version upgrades are controlled at the bench group level.

### Installing/Uninstalling Apps

**Installing** (on private benches):

1. Add the app to your bench group first
2. Deploy the bench
3. Go to Site Dashboard > Apps > Install App

**Uninstalling**:

1. Go to Site Dashboard > Actions > **Uninstall App**
2. Select the app to remove
3. Confirm the operation

### Deleting a Site

1. Go to Site Dashboard > Actions > **Drop Site** or **Delete Site**
2. Confirm the deletion
3. Site is marked for deletion

Deleted sites cannot be recovered. Download backups before deletion.

## Moving Sites

### Move to Private Bench Group

1. Go to Site Dashboard > Actions > **Change Bench Group**
2. If no compatible private bench exists, click **Clone current Bench Group**
3. Select the target bench group
4. Click **Change Bench Group**

### Move Across Regions

1. Go to Site Dashboard > Actions > **Move Site**
2. Select the target region
3. Confirm the migration

Site will experience brief downtime during migration.

### Move Across Servers

For dedicated server customers:

1. Go to Site Dashboard > Actions > **Move Site**
2. Select the target server
3. Confirm the operation

## Disabling Auto-Updates

By default, sites auto-update when their bench group is updated. To disable:

1. Go to Site Dashboard
2. Navigate to Settings or Actions menu
3. Disable the **Auto-Update** toggle

This gives you control over when updates are applied to production sites.

## Related Concepts

- **Benches and Bench Groups** — Sites run on benches; see bench management documentation
- **Backups** — Automated offsite backups available on USD 25+ plans
- **Custom Domains** — Unlimited domains with automatic SSL
- **Version Upgrades** — Controlled via site or bench group settings
