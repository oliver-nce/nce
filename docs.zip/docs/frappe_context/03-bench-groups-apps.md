# Frappe Cloud: Bench Groups and App Management

## Overview

Bench Groups are templates that define what apps and configurations are deployed to your sites. Private Bench Groups give you control over custom apps, update schedules, SSH access, and advanced features. This document covers creating and managing bench groups and working with apps.

## Public vs Private Bench Groups

### Public Bench Groups

Sites created via the standard **New Site** flow are placed on public (managed) bench groups:

- Managed by Frappe
- Updated on a regular schedule (usually following Frappe/ERPNext releases)
- No custom app support
- No SSH access
- No control over update timing

Sites on public benches appear under the **Sites** section in the dashboard.

### Private Bench Groups

Available for sites on USD 25+ plans with a payment method on file:

- Full control over installed apps
- Add custom apps from GitHub
- Control when updates are deployed
- SSH access to the bench environment
- Server scripts support (v15+)
- Custom dependency versions

Private bench groups appear under the **Bench Groups** section in the dashboard.

## Creating a Private Bench Group

### Prerequisites

- USD 25+ plan (or payment method added)
- GitHub account (for custom apps)

### Steps

1. Click the **+ New** button from the dashboard home
2. Select **Bench Group**
3. Choose the **Version** (Frappe Framework version)
4. Select the **Region** for deployment
5. Enter a **name** for the bench group
6. Click **Create Bench Group**

The bench group is created but not yet deployed. You must add apps and deploy.

## Managing Apps in a Bench Group

### Adding Marketplace Apps

1. Go to your Bench Group dashboard
2. Click the **Apps** tab
3. Click **Add App**
4. Search for apps in the marketplace
5. Select the app and confirm

### Adding Custom Apps from GitHub

1. Go to Bench Group dashboard > Apps tab
2. Click **Add App**
3. Click **Add from GitHub** at the bottom
4. Click **Connect To GitHub** (first time only)
5. Complete GitHub OAuth flow to grant Frappe Cloud access
6. Select the **organization** containing your repository
7. Select the **app repository**
8. Choose the **branch** to deploy from the dropdown
9. Click **Validate App** to check compatibility
10. Click **Add App** to confirm

The app is added but not yet deployed. You must trigger a deploy.

### Changing a GitHub Repository URL

If you need to update the source repository:

1. Go through the Add App flow again
2. Select the new repository/branch
3. The dialog will show a banner indicating the update
4. Click **Update App** instead of Add App

### Removing Apps

Apps can be removed during the update process:

1. Go to Bench Group > Apps tab
2. Click **Show Updates** or the menu for the app
3. Deselect apps to remove
4. Deploy the changes

**Note:** You cannot remove the Frappe Framework if ERPNext or dependent apps are installed.

## Deploying and Updating a Bench

### Initial Deploy

After creating a bench group and adding apps:

1. Go to the Bench Group dashboard
2. Click **Deploy**
3. Monitor the deploy progress in the **Deploys** tab

The deploy process:

1. Builds a Docker image with your apps
2. Initializes the bench container
3. Makes the bench ready for sites

### Updating Apps

When updates are available (new commits on configured branches):

1. An **Update Available** banner appears on the bench group dashboard
2. Click **Show Updates** to see what changed
3. Select/deselect apps to include in the update
4. Click **Deploy**

You can monitor deploy progress and:

- View each build stage
- **Fail Build** to stop a running build
- View app versions after completion

### Selective App Updates

Frappe Cloud supports updating only specific apps:

1. Open the update dialog
2. Deselect apps you don't want to update
3. Click Deploy

**Important:** You cannot deselect Frappe Framework when updating ERPNext.

### Automatic Site Updates

After a bench is updated:

- Sites with auto-update enabled are updated during non-working hours (1 AM - 4 AM)
- You can trigger immediate updates from the site dashboard

## Bench Configuration

### Bench Config

Access via Bench Group > Settings or Config tab:

- **Common Site Config** — Configuration applied to all sites on the bench
- **Dependency Versions** — Python, Node.js versions

### Editing Dependency Versions

1. Go to Bench Group > Settings
2. Navigate to Dependencies section
3. Modify Python or Node.js versions as needed
4. Save and redeploy

### Process Status

View running processes for the bench:

1. Go to Bench Group > Process Status tab
2. See web workers, scheduler, and background job status

## SSH Access

SSH access is available for private bench groups (USD 25+ plans).

### Setup

1. Go to **Settings** in the FC dashboard
2. Scroll to **SSH Key** section
3. Click **New SSH Key**
4. Paste your public key (use `cat ~/.ssh/id_rsa.pub | pbcopy` or similar)
5. Save the key

### Connecting

1. Go to Bench Group dashboard
2. Click the three-dot menu > **SSH Access**
3. Copy the provided certificate to your `.ssh` directory
4. Use the provided SSH command:

```bash
ssh <bench-name>@nx-region.frappe.cloud -p 2222
```

### Limitations

- No root access (install dependencies via your app's requirements)
- No `scp` support (use wget or site's `/files/` directory for file transfer)
- VS Code Remote SSH not supported

## App Patches

For applying quick fixes without full deploys:

1. Go to Bench Group > App Patches
2. Create a patch with the required changes
3. Apply the patch

Patches are temporary fixes; proper commits should follow.

## Managing Bench Group Ownership

### Change Team of Bench Group

1. Go to Bench Group > Settings or Actions
2. Select **Change Team**
3. Choose the target team
4. Confirm the transfer

### Dropping a Bench Group

1. Ensure all sites are deleted or moved
2. Go to Bench Group > Actions > **Drop Bench Group**
3. Confirm deletion

## Related Concepts

- **Sites** — Sites run on benches within bench groups
- **GitHub Integration** — Custom apps require GitHub connection
- **SSH Access** — Available for private benches on USD 25+ plans
- **Deploys** — Build process creates new bench versions
