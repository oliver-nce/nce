# Frappe Cloud: Quick Reference and Known Limitations

## Quick Reference: Common UI Paths

### Site Operations

| Task | Navigation Path |
|------|-----------------|
| Create site | Dashboard > Sites > New Site |
| Change plan | Site Dashboard > Actions > Change Plan |
| Add domain | Site Dashboard > Domains > Add Domain |
| Trigger backup | Site Dashboard > Backups > Schedule Backup |
| Download backup | Site Dashboard > Backups > (offsite backup) > Download |
| Install app | Site Dashboard > Apps > Install App |
| Uninstall app | Site Dashboard > Actions > Uninstall App |
| Update site | Site Dashboard > Actions > Update |
| Delete site | Site Dashboard > Actions > Drop Site |
| View logs | Site Dashboard > Logs / Dev Tools > Log Browser |
| Site config | Site Dashboard > Site Config |
| Version upgrade | Site Dashboard > Actions > Version Upgrade |
| Move to private bench | Site Dashboard > Actions > Change Bench Group |

### Bench Group Operations

| Task | Navigation Path |
|------|-----------------|
| Create bench group | Dashboard > + New > Bench Group |
| Add marketplace app | Bench Group > Apps > Add App |
| Add GitHub app | Bench Group > Apps > Add App > Add from GitHub |
| Deploy bench | Bench Group > Deploy / Show Updates > Deploy |
| View deploys | Bench Group > Deploys tab |
| SSH access | Bench Group > ⋮ menu > SSH Access |
| Bench config | Bench Group > Settings / Config |
| Drop bench group | Bench Group > Actions > Drop Bench Group |

### Account & Team Operations

| Task | Navigation Path |
|------|-----------------|
| Add team member | Settings > Profile & Team > Manage Members > Add Member |
| Configure roles | Settings > Role Permissions |
| View billing | Settings > Billing |
| Add payment method | Settings > Billing > Payment Methods > Add Card |
| View invoices | Settings > Billing > Invoices |
| Add SSH key | Settings > SSH Key > New SSH Key |
| Create API token | Settings > API > Create Access Token |
| Switch team | Team selector (header) > Select team |
| Configure notifications | Settings > Notifications |

### Server Operations

| Task | Navigation Path |
|------|-----------------|
| Create server | Dashboard > + New > Server |
| Change server plan | Server Dashboard > Change Plan |
| Add storage | Server Dashboard > Storage > + |
| Create bench on server | Server Dashboard > Bench Groups > New Bench Group |
| View storage breakdown | Server Dashboard > Storage Breakdown |
| Server snapshot | Server Dashboard > Server Snapshot |
| Delete server | Server Dashboard > Delete |

## Feature Availability by Plan

| Feature | Tiny ($5) | Basic ($10) | Standard ($25) | Pro ($50+) | Dedicated |
|---------|-----------|-------------|----------------|------------|-----------|
| Site creation | ✓ | ✓ | ✓ | ✓ | ✓ |
| Custom domains | ✓ | ✓ | ✓ | ✓ | ✓ |
| Free SSL | ✓ | ✓ | ✓ | ✓ | ✓ |
| Automated backups | — | — | ✓ | ✓ | ✓ |
| Offsite backups | — | — | ✓ | ✓ | ✓ |
| Private benches | — | — | ✓ | ✓ | ✓ |
| Custom apps | — | — | ✓ | ✓ | ✓ |
| SSH access | — | — | ✓ | ✓ | ✓ |
| Server scripts | — | — | ✓ (v15+) | ✓ | ✓ |
| Monitoring | — | — | ✓ | ✓ | ✓ |
| Database access | — | — | — | ✓ | ✓ |
| Static IP | Available | Available | Available | Available | Included |

## Documentation Gaps and Limitations

The following areas have limited public documentation or require verification through direct UI interaction:

### Unclear or Undocumented

1. **Exact monitoring metrics** — The specific metrics available in the monitoring tab are not fully documented
2. **Notification event types** — Complete list of notification triggers is not exhaustively documented
3. **API endpoint coverage** — Not all dashboard operations have documented API equivalents
4. **Error message catalog** — No comprehensive list of error messages and resolutions
5. **Rate limits** — API and operation rate limits are not publicly documented
6. **Webhook payload formats** — Exact payload structures for webhook events

### UI Elements Not Fully Documented

1. **Dashboard layout changes** — UI may differ from screenshots in documentation
2. **Action menu locations** — Some actions may be under different menus than documented
3. **Settings organization** — Settings sections may be reorganized over time
4. **Regional availability** — Not all features available in all regions

### Known Limitations

1. **Developer mode** — Cannot be enabled on Frappe Cloud; use custom apps instead
2. **Root access** — Not available, even with SSH access
3. **SCP/SFTP** — Not supported; use wget or site files directory
4. **VS Code Remote** — Not supported for SSH connections
5. **Custom APT packages** — Limited; must be declared in app dependencies
6. **Timezone for MariaDB** — system-time-zone variable may not match site timezone
7. **Backup scheduling** — No user-defined schedule; round-robin timing

### Pricing Considerations

1. **Plan limits change** — Check current pricing page for accurate limits
2. **Marketplace apps** — May have additional costs
3. **Server pricing** — Varies by region and specifications
4. **Storage add-ons** — Additional cost beyond base plan

## Troubleshooting Quick Reference

### Common Issues

| Issue | Likely Cause | Resolution |
|-------|--------------|------------|
| GitHub fetch fails | Lost repository access | Reconfigure GitHub App permissions |
| Build fails | App compatibility | Check logs, test locally |
| Site not accessible | DNS not propagated | Wait or check DNS configuration |
| SSL certificate error | Domain verification pending | Verify DNS records |
| Update not appearing | Branch not tracked | Check configured branch |
| Permission denied (SSH) | Key mismatch | Verify SSH key matches dashboard |

### Where to Get Help

1. **Documentation** — https://docs.frappe.io/cloud
2. **Support Portal** — https://support.frappe.io
3. **Community Forum** — https://discuss.frappe.io/c/frappe-cloud
4. **Telegram Group** — https://t.me/frappecloud

## API Quick Reference

### Authentication

```
Authorization: Token <api-key>:<api-secret>
X-Press-Team: <team-name>
```

### Base URL

```
https://frappecloud.com/api/method/press.api.*
```

### Common Endpoints

| Operation | Endpoint |
|-----------|----------|
| List sites | `press.api.site.get_list` |
| Site details | `press.api.site.get` |
| Billing summary | `press.api.billing.get_summary` |
| List invoices | `press.api.billing.get_invoices` |

See API documentation for complete reference.

## Glossary

| Term | Definition |
|------|------------|
| Agent | Flask app on servers that executes Press commands |
| Bench | Runtime environment with apps and sites |
| Bench Group | Template and collection of benches |
| Deploy | Build process creating a new bench |
| Offsite backup | Backup stored on separate server (AWS S3) |
| Press | Open-source orchestration system powering Frappe Cloud |
| Private bench | User-controlled bench for custom apps |
| Public bench | Frappe-managed bench for standard hosting |
| Site | Single Frappe installation with its database |
| Team | Account unit owning resources and billing |

## Version History Note

This documentation was compiled from official Frappe Cloud documentation as of late 2024. The UI and features may change. Always verify current behavior through the dashboard or official documentation.

## Source References

Primary sources used:

- https://docs.frappe.io/cloud/
- https://frappecloud.com/docs/
- https://frappecloud.com/

For the most current information, refer to the official documentation.
