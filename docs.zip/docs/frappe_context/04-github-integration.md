# Frappe Cloud: GitHub Integration and Custom Apps

## Overview

Frappe Cloud integrates with GitHub to enable deployment of custom Frappe apps. Custom apps can only be deployed on private bench groups (USD 25+ plans). This document covers connecting GitHub, adding custom apps, managing updates, and troubleshooting common issues.

## Connecting GitHub to Frappe Cloud

### Initial Setup

1. Navigate to your Bench Group dashboard
2. Go to the **Apps** tab
3. Click **Add App** > **Add from GitHub**
4. Click **Connect To GitHub**
5. Complete the GitHub OAuth authentication flow
6. Grant Frappe Cloud access to your repositories

Frappe Cloud uses a GitHub App for repository access. You can grant access to:

- Specific repositories only
- All repositories in an organization
- Personal repositories

### Managing GitHub Permissions

If you need to modify access:

1. Go to GitHub > Settings > Applications > Installed GitHub Apps
2. Find **Frappe Cloud** in the list
3. Click **Configure**
4. Modify repository access as needed

The installation URL pattern is:
`https://github.com/settings/installations/<unique_number>`

## Adding a Custom App

### Prerequisites

Your Frappe app repository must:

- Be a valid Frappe app structure
- Have a proper `pyproject.toml` or `setup.py`
- Be compatible with the target Frappe version
- List all dependencies correctly

### Process

1. Go to Bench Group > Apps tab
2. Click **Add App**
3. Click **Add from GitHub**
4. Select the **organization** containing your repository
5. Select the **repository**
6. Choose the **branch** to deploy (e.g., `main`, `version-15`, `develop`)
7. Click **Validate App**
   - Frappe Cloud checks app structure and compatibility
   - Any issues are reported before deployment
8. Click **Add App** to confirm

The app is added to the bench group configuration but not yet deployed.

### Deploying the App

After adding apps:

1. Click **Show Updates** or **Deploy** on the bench group dashboard
2. Review the changes
3. Click **Deploy**
4. Monitor the build in the Deploys tab

The deploy creates a new bench with your app installed.

### Installing on a Site

After the bench is deployed:

1. Go to your Site dashboard
2. Navigate to Apps tab
3. Click **Install App**
4. Select your custom app
5. Confirm installation

This runs the app's install hooks and patches.

## Updating Custom Apps

### Automatic Detection

Frappe Cloud monitors your GitHub repository for changes:

- When new commits are pushed to the configured branch
- An **Update Available** banner appears on the bench group dashboard

### Deploying Updates

1. Click **Show Updates** on the bench group
2. Review which apps have updates
3. Select/deselect apps to include
4. Click **Deploy**

After the bench updates, sites update automatically during non-working hours (if auto-update is enabled).

### Changing the Source Branch

To deploy from a different branch:

1. Go through the Add App flow again
2. Select the same repository but different branch
3. Click **Update App** (not Add App)
4. Deploy the bench

## Private Repositories

Frappe Cloud supports private GitHub repositories:

1. Ensure the Frappe Cloud GitHub App has access to the private repo
2. Add the app using the same process as public repos
3. The repository code is fetched during build

**Security Note:** Users with SSH access to private benches can view your private repository code. Consider this when granting bench access.

## Dependencies and Requirements

### Python Dependencies

Add Python dependencies in your app's configuration:

**For `pyproject.toml`:**
```toml
[project]
dependencies = [
    "pandas>=1.5.0",
    "requests>=2.28.0"
]
```

**For `setup.py`:**
```python
install_requires=[
    "pandas>=1.5.0",
    "requests>=2.28.0"
]
```

Do not use `pip install` directly—dependencies must be declared in the app.

### Node.js Dependencies

Frontend dependencies go in the app's `package.json`.

### APT Dependencies

For system-level dependencies, see the Frappe Cloud documentation on installing APT dependencies. Some common packages may require support assistance.

## Troubleshooting Common Issues

### "Unable to fetch latest updates from GitHub"

The Frappe Cloud GitHub App may have lost access:

1. Go to https://github.com/settings/installations/
2. Click **Configure** next to Frappe Cloud
3. Verify repository access is granted
4. If issues persist, note the installation number and contact support

### Invalid pyproject.toml

Common causes:

- Missing required fields
- Incorrect TOML syntax
- Invalid version specifiers

Validate your `pyproject.toml` locally before pushing.

### Incompatible Node Version

Your app may require a specific Node.js version:

1. Check your app's `.nvmrc` or engine requirements
2. Update bench dependency versions if needed
3. Redeploy

### Incompatible Dependency Version

Conflicts between app dependencies:

1. Check error logs for specific conflicts
2. Update your dependency versions to compatible ranges
3. Test locally before redeploying

### Required App Not Found

Your app depends on another app not installed on the bench:

1. Verify all required apps are listed in `pyproject.toml`
2. Add missing apps to the bench group
3. Redeploy

### Build Failures

General build issues:

1. Check the deploy logs for specific errors
2. Test your app locally in a similar environment
3. Fix issues in your repository
4. Push fixes and redeploy

### Vite Not Found

For apps using Vite for frontend builds:

1. Ensure Vite is in your app's dependencies
2. Check that build scripts are correct
3. Verify Node.js version compatibility

## App Development Workflow

### Recommended Workflow

1. **Local Development** — Develop and test locally using `bench`
2. **Push to Branch** — Push changes to your configured branch
3. **Deploy to Staging** — Create a staging bench group for testing
4. **Test on Staging Site** — Verify all functionality
5. **Deploy to Production** — Update your production bench group
6. **Monitor** — Check deploy logs and site activity

### Using Staging Environments

Create separate bench groups for:

- Development/testing
- Staging/QA
- Production

Each can point to different branches of your repository.

## Marketplace Publishing

Custom apps can be published to the Frappe Cloud Marketplace:

1. Ensure your app meets marketplace guidelines
2. Go to Marketplace > **Publish App**
3. Configure pricing (free or paid plans)
4. Submit for review

Published apps can be installed by other Frappe Cloud users.

## Related Concepts

- **Private Bench Groups** — Required for custom apps
- **Deploys** — Build process for bench updates
- **SSH Access** — Debug apps directly on the bench
- **Site Updates** — Install apps on individual sites after bench deploy
