# Frappe Cloud: Servers and Dedicated Infrastructure

## Overview

Frappe Cloud offers dedicated server options for users needing isolated infrastructure, higher performance, or specific compliance requirements. This document covers server creation, management, scaling, and the hybrid cloud option.

## Hosting Options

### Shared Hosting

Default for standard plans:

- Multiple sites share server resources
- Each site has a dedicated database
- Cost-effective for small to medium projects
- Limited customization

### Private Benches (on Shared Infrastructure)

For USD 25+ plans:

- Isolated bench environment
- Custom apps support
- SSH access
- Runs on Frappe-managed servers

### Dedicated Servers

Full server ownership:

- Exclusive server resources
- Multiple bench groups and sites
- Full control over resource allocation
- Higher performance and security

## Creating a Dedicated Server

### Server Types

You need two servers for a complete setup:

1. **Application Server** — Runs benches and serves sites
2. **Database Server** — Hosts MariaDB for your sites

### Creation Process

1. Click **+ New** from the dashboard
2. Select **Server**
3. Choose server specifications:
   - Region
   - Server plan (CPU, RAM, storage)
   - Server type (Application or Database)
4. Confirm and create

Initial setup takes several minutes.

### Choosing a Server Plan

Consider:

- **CPU cores** — For concurrent request handling
- **RAM** — For database bufferpool and application memory
- **Storage** — For database, files, and backups

Guidelines:

- Start with smaller plans and scale up
- Monitor resource usage before upgrading
- Database servers often need more RAM than application servers

## Server Dashboard

### Overview Tab

Displays:

- Server status
- Current plan
- Resource usage (CPU, memory, disk)
- Connected benches and sites

### Actions Available

- **Change Plan** — Upgrade or downgrade
- **Restart** — Restart server services
- **Delete** — Remove the server

## Server Plan Changes

### Upgrading/Downgrading

1. Go to Server Dashboard
2. Click **Change Plan**
3. Select the new plan
4. Confirm the change

**Important:** Server plan changes involve downtime. The underlying virtual machine is replaced.

### Storage Add-ons

Increase storage without changing plans:

1. Go to Server Overview
2. Click **+** next to Storage
3. Select additional storage amount
4. Confirm the purchase

## Creating Benches on Dedicated Servers

### From Server Dashboard

1. Go to your Server Dashboard
2. Navigate to **Bench Groups**
3. Click **New Bench Group**
4. Choose version, enter title
5. Click **Create Bench Group**
6. Add apps and deploy

### Bench Configuration

Same process as regular private benches:

- Add apps (marketplace or GitHub)
- Configure dependencies
- Deploy
- Create sites

## Resource Allocation

### Controlling Site Resources

For granular control:

1. Go to Server Dashboard > **Control Resources**
2. Allocate CPU and memory per site
3. Set limits based on site importance

### Monitoring Resources

- Server-level metrics in Server Dashboard
- Site-level metrics in Site Dashboard
- Historical data for capacity planning

## Server Storage Breakdown

View storage usage:

1. Go to Server Dashboard > **Storage Breakdown**
2. See usage by:
   - Databases
   - Files
   - Backups
   - System

Use this to identify storage optimization opportunities.

## Database Server Actions

For dedicated database servers:

### Available Actions

- View connection status
- Restart MariaDB
- Access performance metrics

### Accessing

1. Go to Database Server Dashboard
2. Navigate to **Actions** or **Database Server Actions**
3. Select the desired action

## Server Snapshots

Create point-in-time server images:

1. Go to Server Dashboard
2. Click **Server Snapshot**
3. Wait for snapshot completion

Use for:

- Before major changes
- Disaster recovery
- Creating server templates

## Horizontal Scaling

### Application Server Scaling

For high-traffic sites:

1. Go to Server Dashboard
2. Navigate to **Horizontal Scaling**
3. Add application server instances
4. Configure load balancing

Distributes requests across multiple servers.

## Hybrid Cloud / Self-Hosted Servers

### What is Hybrid Cloud?

Bring your own infrastructure while using Frappe Cloud management:

- Your servers (on-premise or third-party cloud)
- Frappe Cloud orchestration and management
- Single dashboard for all resources

### Architecture

Single-server setup (both app and database):

- Agent installed for Frappe Cloud communication
- Ansible playbooks for configuration
- Docker containers for benches

### Benefits

- **Control** — Your infrastructure, your data center
- **Security** — Meet specific compliance requirements
- **Cost** — Use existing infrastructure investments
- **Flexibility** — Mix cloud and on-premise

### Folder Structure

On self-hosted servers:

```
/home/frappe/
├── agent/          # Frappe Cloud Agent
├── benches/        # Active benches (Docker containers)
└── archived/       # Archived benches
```

### Setting Up Hybrid Cloud

1. Prepare your server (Ubuntu, Docker)
2. Go to Frappe Cloud Dashboard
3. Select **Create Self-Hosted Server**
4. Follow the setup wizard
5. Install the Agent on your server
6. Complete the connection

### Limitations

- Maintenance is your responsibility
- Server health monitoring required
- Network configuration needed for Agent communication

## Server Ownership Transfer

### Changing Ownership

1. Go to Server Dashboard
2. Navigate to Actions > **Change Ownership**
3. Select the target team
4. Confirm transfer

All associated resources move with the server.

## Deleting Servers

### Prerequisites

Before deletion:

- Move or delete all sites
- Remove all bench groups
- Download needed backups

### Process

1. Go to Server Dashboard
2. Click **Delete** or **Delete Server**
3. Confirm deletion
4. Wait for deprovisioning

Deletion is permanent—all data is lost.

## Notifications for Servers

### Configuring Alerts

1. Go to Server Dashboard > **Notification Configuration**
2. Set up alerts for:
   - High resource usage
   - Server downtime
   - Maintenance events
3. Specify notification channels

## Bench Analytics

View performance metrics for benches on dedicated servers:

1. Go to Server Dashboard > **Bench Analytics**
2. See request volumes
3. Monitor response times
4. Track resource usage by bench

## Best Practices

### Server Sizing

- Start with recommendations from Frappe Cloud
- Monitor actual usage before scaling
- Leave headroom for traffic spikes

### Security

- Keep systems updated
- Use strong SSH keys
- Limit access through role permissions

### Maintenance

- Schedule updates during low-traffic periods
- Test changes in staging first
- Maintain recent backups before changes

## Related Concepts

- **Bench Groups** — Benches run on application servers
- **Database Access** — Connect to database servers
- **Storage** — Managed across servers
- **Hybrid Cloud** — Self-hosted server integration
