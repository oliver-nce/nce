# 13. DocType Customization: Property Setters, Custom Fields & Layout Editor

**Context**: Understanding how Frappe allows customization of DocTypes without modifying base files, and how to build tools that work with these customizations.

**Status**: ✅ Core concepts validated through Layout Editor implementation  
**Last Updated**: January 3, 2026

---

## Overview

Frappe provides a powerful system for customizing DocTypes without touching the base JSON files. This is crucial for:
- Customizing standard Frappe DocTypes (User, Customer, Item, etc.)
- Tailoring third-party app DocTypes to your needs
- Making site-specific adjustments
- Maintaining upgradability (customizations don't break on updates)

There are three layers that combine to create the final DocType you see:

```
┌─────────────────────────────────────────────────────────────┐
│                    Final DocType (in UI)                     │
│                                                               │
│            What frappe.get_meta() returns                     │
└─────────────────────────────────────────────────────────────┘
                              ▲
                              │
                              │ Merged from:
            ┌─────────────────┼─────────────────┐
            │                 │                 │
            │                 │                 │
    ┌───────▼───────┐  ┌──────▼──────┐  ┌──────▼──────┐
    │  Base JSON    │  │   Custom    │  │  Property   │
    │    File       │  │   Fields    │  │   Setters   │
    │               │  │             │  │             │
    │  (in repo)    │  │ (in DB)     │  │  (in DB)    │
    │  Read-only    │  │ New fields  │  │  Overrides  │
    └───────────────┘  └─────────────┘  └─────────────┘
```

---

## 1. Base DocType JSON Files

### What They Are
- The `*.json` files in your app's `doctype` folder
- Example: `nce_frappe_app/nce/wp_sync/doctype/layout_editor/layout_editor.json`
- Define the default structure, fields, and properties of a DocType
- Stored in repository, version controlled

### Structure Example
```json
{
 "actions": [],
 "allow_rename": 1,
 "creation": "2025-01-02 12:34:56.789012",
 "doctype": "DocType",
 "engine": "InnoDB",
 "field_order": [
  "doctype_name",
  "json_editor"
 ],
 "fields": [
  {
   "fieldname": "doctype_name",
   "fieldtype": "Link",
   "label": "DocType Name",
   "options": "DocType",
   "reqd": 1
  },
  {
   "fieldname": "json_editor",
   "fieldtype": "Code",
   "label": "Layout JSON",
   "options": "JSON"
  }
 ],
 "index_web_pages_for_search": 1,
 "links": [],
 "modified": "2025-01-03 09:15:23.456789",
 "name": "Layout Editor",
 "owner": "Administrator",
 "permissions": [...],
 "sort_field": "creation",
 "sort_order": "DESC"
}
```

### Key Points
- **Read-only in production**: Don't edit these files on live sites
- **Modified via Desk for your own DocTypes**: Use Frappe's DocType builder
- **Never edit for standard DocTypes**: Use Property Setters instead

---

## 2. Custom Fields

### What They Are
- Add NEW fields to existing DocTypes
- Stored in database table: `tabCustom Field`
- Each custom field = one database record
- Ideal for adding app-specific data to standard DocTypes

### When to Use
- Adding fields to standard Frappe DocTypes (Customer, Sales Order, etc.)
- Extending third-party app DocTypes
- Site-specific data requirements
- Fields that don't belong in the base DocType

### Creating Custom Fields

**Via UI**:
1. Go to "Customize Form"
2. Select your DocType
3. Click "Add Custom Field"
4. Fill in properties
5. Save

**Via API**:
```python
custom_field = frappe.get_doc({
    "doctype": "Custom Field",
    "dt": "Customer",           # Target DocType
    "fieldname": "tax_id",
    "label": "Tax ID",
    "fieldtype": "Data",
    "insert_after": "customer_name",
    "reqd": 0
})
custom_field.insert()
```

### Custom Field Properties
- `dt`: Target DocType name
- `fieldname`: Unique field identifier
- `fieldtype`: Type of field (Data, Link, Select, etc.)
- `label`: Display name
- `insert_after`: Place after this field
- `options`: For Select/Link fields
- All standard field properties available

### Exporting Custom Fields
```bash
# Add to hooks.py
fixtures = [
    {
        "dt": "Custom Field",
        "filters": [
            ["dt", "in", ["Customer", "Sales Order"]]
        ]
    }
]

# Export
bench --site sitename export-fixtures
```

Result: `fixtures/custom_field.json` in your app

---

## 3. Property Setters

### What They Are
- Override or modify properties of EXISTING fields or DocType properties
- Stored in database table: `tabProperty Setter`
- Each property change = one database record
- The mechanism the "Customize Form" UI uses under the hood

### When to Use
- Changing field labels
- Hiding standard fields
- Making fields required/read-only
- Adjusting field widths, heights, descriptions
- Changing DocType properties (title_field, search_fields, etc.)

### Property Setter Structure

Each Property Setter record contains:
```python
{
    "doctype": "Property Setter",
    "doc_type": "Customer",           # The DocType being customized
    "field_name": "customer_name",    # The field being modified (or None for DocType properties)
    "property": "label",              # Which property is being changed
    "value": "Client Name",           # The new value
    "property_type": "Data",          # Data type of the value
    "doctype_or_field": "DocField"    # "DocField" for field changes, "DocType" for DocType changes
}
```

### Critical Fields Explained

#### `doctype_or_field`
**⚠️ MOST IMPORTANT FIELD**

This field specifies what kind of customization this is:
- `"DocField"` - Modifying a field property (most common)
- `"DocType"` - Modifying a DocType property

**Common Mistake**: Using `"applied_on"` - this field doesn't exist and causes errors!

**Example - Field Property**:
```python
{
    "doc_type": "Customer",
    "field_name": "customer_name",
    "property": "label",
    "value": "Client Name",
    "doctype_or_field": "DocField"  # ✅ Correct
}
```

**Example - DocType Property**:
```python
{
    "doc_type": "Customer",
    "field_name": None,              # No field, it's a DocType property
    "property": "title_field",
    "value": "customer_name",
    "doctype_or_field": "DocType"   # ✅ Modifying DocType itself
}
```

#### `doc_type`
- The name of the DocType you're customizing
- Examples: "Customer", "Sales Order", "User"

#### `field_name`
- The fieldname being modified (for field-level changes)
- Set to `None` for DocType-level changes
- Must exactly match the field's `fieldname` property

#### `property`
- The name of the property you're changing
- Common field properties: `label`, `hidden`, `reqd`, `read_only`, `bold`, `description`, `rows`, `columns`, `default`, `options`
- Common DocType properties: `title_field`, `search_fields`, `sort_field`, `sort_order`

#### `value`
- The new value for the property
- **Always stored as a string** (even for numbers and booleans)
- Frappe converts it based on `property_type`

#### `property_type`
- Indicates the data type of the value
- Common types: `"Data"`, `"Check"`, `"Int"`, `"Text"`, `"Select"`
- Helps Frappe validate and convert the value correctly

### Creating Property Setters Programmatically

**The Correct Way**:
```python
@frappe.whitelist()
def update_properties(doctype_name, json_str):
    """Apply JSON edits as Property Setters"""
    edited_fields = json.loads(json_str)
    base_meta = frappe.get_meta(doctype_name)
    
    for edited_field in edited_fields:
        fieldname = edited_field.get("fieldname")
        base_field = next((f for f in base_meta.fields if f.fieldname == fieldname), None)
        
        if not base_field:
            continue
        
        base_dict = base_field.as_dict()
        
        # Compare each property
        for prop, value in edited_field.items():
            if prop in ["fieldname", "fieldtype"]:  # Don't create setters for these
                continue
            
            base_value = base_dict.get(prop)
            
            if value != base_value:
                # Check if Property Setter already exists
                existing = frappe.db.exists("Property Setter", {
                    "doc_type": doctype_name,
                    "field_name": fieldname,
                    "property": prop
                })
                
                if existing:
                    # Update existing
                    ps = frappe.get_doc("Property Setter", existing)
                    ps.value = str(value)
                    ps.save()
                else:
                    # Create new
                    frappe.get_doc({
                        "doctype": "Property Setter",
                        "doc_type": doctype_name,
                        "field_name": fieldname,
                        "property": prop,
                        "value": str(value),
                        "property_type": get_property_type(value),
                        "doctype_or_field": "DocField"  # ✅ Critical!
                    }).insert()
    
    frappe.db.commit()

def get_property_type(value):
    """Determine property_type from value"""
    if isinstance(value, bool) or value in [0, 1]:
        return "Check"
    elif isinstance(value, int):
        return "Int"
    elif isinstance(value, str) and len(value) > 140:
        return "Text"
    else:
        return "Data"
```

### Common Property Changes

**Hide a field**:
```python
{
    "doc_type": "Customer",
    "field_name": "tax_id",
    "property": "hidden",
    "value": "1",
    "property_type": "Check",
    "doctype_or_field": "DocField"
}
```

**Change label**:
```python
{
    "doc_type": "Customer",
    "field_name": "customer_name",
    "property": "label",
    "value": "Client Name",
    "property_type": "Data",
    "doctype_or_field": "DocField"
}
```

**Set text field height**:
```python
{
    "doc_type": "Customer",
    "field_name": "notes",
    "property": "rows",
    "value": "5",
    "property_type": "Int",
    "doctype_or_field": "DocField"
}
```

**Make field required**:
```python
{
    "doc_type": "Customer",
    "field_name": "email",
    "property": "reqd",
    "value": "1",
    "property_type": "Check",
    "doctype_or_field": "DocField"
}
```

### Exporting Property Setters
```bash
# Add to hooks.py
fixtures = [
    {
        "dt": "Property Setter",
        "filters": [
            ["doc_type", "in", ["Customer", "Sales Order"]]
        ]
    }
]

# Export
bench --site sitename export-fixtures
```

Result: `fixtures/property_setter.json` in your app

---

## 4. How Frappe Merges Everything: `frappe.get_meta()`

### The Merge Process

When you call `frappe.get_meta("Customer")`, Frappe:

1. **Loads base JSON** from the DocType file
2. **Applies Property Setters** to override properties
3. **Inserts Custom Fields** at their specified positions
4. **Returns merged metadata object**

### Code Example
```python
# Get the complete, customized metadata
meta = frappe.get_meta("Customer")

# Access fields (includes Custom Fields)
for field in meta.fields:
    # field properties already include Property Setter overrides
    print(f"{field.fieldname}: {field.label}")

# Get all properties of a field (including those set by Property Setters)
field_dict = meta.get_field("customer_name").as_dict()
print(field_dict)  # Shows ALL properties, including customized ones
```

### What `as_dict()` Returns

This is crucial for tools like Layout Editor:

```python
field = meta.get_field("notes")
field_dict = field.as_dict()

# Returns complete dictionary including:
{
    "fieldname": "notes",
    "fieldtype": "Text",
    "label": "Notes",
    "description": "Additional customer notes",
    "rows": 5,           # ← From Property Setter
    "hidden": 0,
    "reqd": 0,
    "read_only": 0,
    "bold": 0,
    "columns": 0,
    "width": "",
    "default": "",
    "options": "",
    # ... many more properties
}
```

**Key Point**: `as_dict()` includes Property Setter overrides, so you're seeing the LIVE state.

---

## 5. Layout Editor: Practical Implementation

### Purpose
Allow power users to customize standard Frappe DocTypes beyond what "Customize Form" UI provides:
- Set field heights (`rows`)
- Set column widths (`columns`)
- Edit descriptions
- Hide fields
- Rename section labels
- All via JSON editing with validation

### Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    Layout Editor UI                       │
│                                                            │
│  1. Select DocType                                        │
│  2. Click "Load JSON" → Shows full field JSON             │
│  3. Edit JSON (with syntax highlighting)                  │
│  4. Click "Validate" → Check for errors                   │
│  5. Click "Update Properties" → Apply as Property Setters │
└──────────────────────────────────────────────────────────┘
                           │
                           │ Calls backend methods
                           ▼
┌──────────────────────────────────────────────────────────┐
│              Layout Editor Backend (Python)               │
│                                                            │
│  • load_doctype_json(doctype_name)                        │
│    → Uses frappe.get_meta() + as_dict()                   │
│    → Returns complete JSON with all customizations        │
│                                                            │
│  • validate_json_for_customizations(doctype_name, json)   │
│    → Validates JSON syntax                                │
│    → Checks for required fields                           │
│    → Prevents core field deletion                         │
│    → Returns ALL errors at once                           │
│                                                            │
│  • update_properties(doctype_name, json)                  │
│    → Compares edited JSON to base                         │
│    → Creates Property Setter for each change              │
│    → Returns success/error with details                   │
└──────────────────────────────────────────────────────────┘
                           │
                           │ Creates/updates records
                           ▼
┌──────────────────────────────────────────────────────────┐
│           Database: tabProperty Setter                    │
│                                                            │
│  One record per property change:                          │
│  • doc_type: "Customer"                                   │
│  • field_name: "notes"                                    │
│  • property: "rows"                                       │
│  • value: "5"                                             │
│  • doctype_or_field: "DocField"                           │
└──────────────────────────────────────────────────────────┘
```

### Key Implementation Details

#### Loading Live JSON
```python
@frappe.whitelist()
def load_doctype_json(doctype_name):
    """Load LIVE DocType JSON including all Property Setters"""
    meta = frappe.get_meta(doctype_name)
    fields = []
    
    for field in meta.fields:
        # Get ALL properties (including from Property Setters)
        field_dict = field.as_dict()
        
        # Clean up metadata fields not needed for editing
        for key in ["modified", "modified_by", "owner", "creation", "docstatus", "idx", "parent", "parentfield", "parenttype", "name"]:
            field_dict.pop(key, None)
        
        fields.append(field_dict)
    
    return json.dumps(fields, indent=2, default=str)
```

#### Validating Changes
```python
@frappe.whitelist()
def validate_json_for_customizations(doctype_name, fields_json):
    """Comprehensive validation before applying changes"""
    errors = []
    
    # Parse JSON
    try:
        fields = json.loads(fields_json)
    except json.JSONDecodeError as e:
        return {
            "valid": False,
            "errors": [f"Invalid JSON: {str(e)}"]
        }
    
    # Check structure
    if not isinstance(fields, list):
        return {
            "valid": False,
            "errors": ["JSON must be an array of field objects"]
        }
    
    # Validate each field
    seen_fieldnames = set()
    base_meta = frappe.get_meta(doctype_name)
    base_fieldnames = {f.fieldname for f in base_meta.fields}
    
    for idx, field in enumerate(fields):
        # Check required properties
        if "fieldname" not in field:
            errors.append(f"Field {idx}: Missing 'fieldname'")
            continue
        
        fieldname = field["fieldname"]
        
        # Check for duplicates
        if fieldname in seen_fieldnames:
            errors.append(f"Duplicate fieldname: {fieldname}")
        seen_fieldnames.add(fieldname)
        
        # Check required fieldtype
        if "fieldtype" not in field:
            errors.append(f"Field '{fieldname}': Missing 'fieldtype'")
    
    # Check for deletions (field in base but not in edited JSON)
    edited_fieldnames = {f.get("fieldname") for f in fields if "fieldname" in f}
    deleted_fields = base_fieldnames - edited_fieldnames
    
    if deleted_fields:
        errors.append(
            f"Cannot delete core fields: {', '.join(deleted_fields)}. "
            f"To hide them, set 'hidden': 1 instead."
        )
    
    # Return results
    if errors:
        return {
            "valid": False,
            "errors": errors,
            "message": f"Found {len(errors)} validation error(s)"
        }
    
    return {
        "valid": True,
        "message": "JSON is valid and ready to apply"
    }
```

#### Applying Changes as Property Setters
```python
@frappe.whitelist()
def update_properties(doctype_name, json_str):
    """Apply validated JSON changes as Property Setters"""
    edited_fields = json.loads(json_str)
    base_meta = frappe.get_meta(doctype_name)
    
    created_count = 0
    updated_count = 0
    
    for edited_field in edited_fields:
        fieldname = edited_field.get("fieldname")
        base_field = next(
            (f for f in base_meta.fields if f.fieldname == fieldname),
            None
        )
        
        if not base_field:
            continue
        
        base_dict = base_field.as_dict()
        
        # Compare each property
        for prop, value in edited_field.items():
            # Skip immutable properties
            if prop in ["fieldname", "fieldtype"]:
                continue
            
            base_value = base_dict.get(prop)
            
            # Only create Property Setter if value changed
            if value != base_value:
                existing = frappe.db.exists("Property Setter", {
                    "doc_type": doctype_name,
                    "field_name": fieldname,
                    "property": prop
                })
                
                if existing:
                    ps = frappe.get_doc("Property Setter", existing)
                    ps.value = str(value)
                    ps.save()
                    updated_count += 1
                else:
                    frappe.get_doc({
                        "doctype": "Property Setter",
                        "doc_type": doctype_name,
                        "field_name": fieldname,
                        "property": prop,
                        "value": str(value),
                        "property_type": get_property_type(value),
                        "doctype_or_field": "DocField"
                    }).insert()
                    created_count += 1
    
    frappe.db.commit()
    
    return {
        "success": True,
        "message": f"Updated properties: {created_count} created, {updated_count} updated",
        "details": {
            "created": created_count,
            "updated": updated_count
        }
    }
```

#### Frontend Button Logic
```javascript
refresh(frm) {
    // Load JSON button
    frm.add_custom_button(__('Load DocType JSON'), function() {
        // Load and display JSON...
    });
    
    // Validate button
    frm.add_custom_button(__('Validate JSON'), function() {
        frappe.call({
            method: 'nce.wp_sync.doctype.layout_editor.layout_editor.validate_json_for_customizations',
            args: {
                doctype_name: frm.doc.doctype_name,
                fields_json: frm.doc.json_editor
            },
            callback: function(r) {
                if (r.message.valid) {
                    frappe.show_alert({
                        message: __('Validation passed! You can now update properties.'),
                        indicator: 'green'
                    });
                    frm.doc.__validated = true;
                    frm.doc.__json_changed = false;
                    frm.refresh();  // Show Update button
                } else {
                    // Show all errors
                    let error_html = '<ul>';
                    r.message.errors.forEach(err => {
                        error_html += `<li>${err}</li>`;
                    });
                    error_html += '</ul>';
                    
                    frappe.msgprint({
                        title: __('Validation Failed'),
                        message: error_html,
                        indicator: 'red'
                    });
                }
            }
        });
    });
    
    // Update Properties button (only show when validated)
    if (frm.doc.__validated && !frm.doc.__json_changed) {
        frm.add_custom_button(__('Update Properties'), function() {
            frappe.confirm(
                'Apply these changes as Property Setters?',
                function() {
                    frappe.call({
                        method: 'nce.wp_sync.doctype.layout_editor.layout_editor.update_properties',
                        args: {
                            doctype_name: frm.doc.doctype_name,
                            json_str: frm.doc.json_editor
                        },
                        callback: function(r) {
                            if (r.message.success) {
                                frappe.show_alert({
                                    message: __(r.message.message),
                                    indicator: 'green'
                                });
                                frm.doc.__validated = false;
                                frm.refresh();
                            }
                        }
                    });
                }
            );
        }, __('Actions')).css({'background-color': '#28a745', 'color': 'white'});
    }
}

// Detect JSON changes
frappe.ui.form.on('Layout Editor', {
    json_editor: function(frm) {
        frm.doc.__json_changed = true;
        frm.doc.__validated = false;
        frm.refresh();  // Hide Update button
    }
});
```

---

## 6. Customization Workflow & Deployment Strategy

### Site-First Approach (Recommended for Standard DocTypes)

**Workflow**:
1. **Customize on site** using Layout Editor or "Customize Form"
2. **Test thoroughly** on staging/dev site
3. **Export to fixtures**: `bench --site sitename export-fixtures`
4. **Commit to repository**: Add `fixtures/*.json` files
5. **Deploy to production**: Git push → Frappe Cloud auto-deploy
6. **Migrate**: `bench migrate` applies fixtures to production database

**Benefits**:
- Property Setters become part of your app
- Other sites get customizations automatically
- Version controlled
- Upgradable (doesn't break on Frappe updates)

### Setting Up Fixtures Export

**In `hooks.py`**:
```python
fixtures = [
    {
        "dt": "Property Setter",
        "filters": [
            ["doc_type", "in", [
                "Customer",
                "Sales Order",
                "Item"
            ]]
        ]
    },
    {
        "dt": "Custom Field",
        "filters": [
            ["dt", "in", [
                "Customer",
                "Sales Order"
            ]]
        ]
    }
]
```

### Clearing Local Customizations

To revert to fixture state:

**Custom Bench Command** (add to your app):
```python
# nce/commands.py
import click
import frappe

@click.command('clear-customizations')
@click.argument('doctype')
def clear_customizations(doctype):
    """Clear all local Property Setters and Custom Fields for a DocType"""
    frappe.init(site=frappe.local.site)
    frappe.connect()
    
    # Delete Property Setters
    ps_count = frappe.db.count("Property Setter", {"doc_type": doctype})
    frappe.db.delete("Property Setter", {"doc_type": doctype})
    
    # Delete Custom Fields
    cf_count = frappe.db.count("Custom Field", {"dt": doctype})
    frappe.db.delete("Custom Field", {"dt": doctype})
    
    frappe.db.commit()
    
    click.echo(f"Cleared {ps_count} Property Setters and {cf_count} Custom Fields for {doctype}")
    click.echo("Run 'bench migrate' to restore from fixtures")

# Register in hooks.py
commands = [
    'nce.commands.clear_customizations'
]
```

**Usage**:
```bash
bench --site sitename clear-customizations "Customer"
bench --site sitename migrate  # Restore from fixtures
```

---

## 7. Multi-Site Considerations

### Scenario: Multiple Sites on Same Bench

**Site-Specific Customizations**:
- Property Setters are per-site (stored in site's database)
- Each site can have different customizations
- Layout Editor loads and saves to current site's database

**App-Wide Customizations** (via fixtures):
- Exported to `fixtures/*.json` in app
- Applied to all sites on `bench migrate`
- Becomes the "base" customizations
- Sites can extend these with additional local Property Setters

### Copying Customizations Between Sites

**Future Feature Idea**:
```python
@frappe.whitelist()
def copy_customizations_from_site(source_site, doctype_name):
    """Copy Property Setters from another site on the same bench"""
    # Would require bench-level command or Frappe API extensions
    # Not currently implemented
    pass
```

**Manual Workaround**:
1. On source site: Copy Property Setter records (from DB or export to fixtures)
2. On target site: Import Property Setter JSON via Layout Editor or Data Import
3. Or: Export from source site fixtures, commit, deploy to target site

---

## 8. Common Pitfalls & Solutions

### ❌ Pitfall 1: Using `applied_on` Instead of `doctype_or_field`
**Error**: "Value missing for Property Setter: Applied On"  
**Solution**: Use `"doctype_or_field": "DocField"` or `"doctype_or_field": "DocType"`

### ❌ Pitfall 2: Not Converting Value to String
**Error**: Type mismatch errors  
**Solution**: Always use `str(value)` when setting Property Setter value

### ❌ Pitfall 3: Loading Base JSON Instead of Live Metadata
**Problem**: Property Setters not reflected in editor  
**Solution**: Use `frappe.get_meta()` and `field.as_dict()`, not file reading

### ❌ Pitfall 4: Deleting Core Fields
**Problem**: Breaks DocType functionality  
**Solution**: Set `hidden: 1` instead of deleting from JSON

### ❌ Pitfall 5: Not Exporting to Fixtures
**Problem**: Customizations lost on app reinstall  
**Solution**: Always export Property Setters to fixtures for important customizations

### ❌ Pitfall 6: Editing Base JSON for Standard DocTypes
**Problem**: Changes lost on Frappe update  
**Solution**: Use Property Setters exclusively for standard Frappe DocTypes

---

## 9. Testing Your Customizations

### Validation Checklist

- [ ] Load DocType in UI - does it show correctly?
- [ ] Check field heights/widths - do they match settings?
- [ ] Verify hidden fields are actually hidden
- [ ] Test required fields - do validations work?
- [ ] Check labels and descriptions - correct text?
- [ ] Save a record - does it work without errors?
- [ ] Check Property Setter table - records created correctly?
- [ ] Export fixtures - files generated successfully?
- [ ] Migrate on fresh site - customizations apply?

### Debugging Tools

**Check Property Setters**:
```python
frappe.db.sql("""
    SELECT field_name, property, value 
    FROM `tabProperty Setter` 
    WHERE doc_type = 'Customer'
""", as_dict=True)
```

**Compare Base vs Live**:
```python
# Base field from JSON
base_field = frappe.get_meta("Customer").get_field("customer_name")

# All properties (including Property Setters)
all_props = base_field.as_dict()
print(json.dumps(all_props, indent=2))
```

**Check Fixtures Export**:
```bash
bench --site sitename export-fixtures
cat apps/your_app/your_app/fixtures/property_setter.json
```

---

## 10. Advanced: Property Setter for DocType Properties

Not just field-level changes - you can customize the DocType itself:

### Change Title Field
```python
frappe.get_doc({
    "doctype": "Property Setter",
    "doc_type": "Customer",
    "field_name": None,                  # ← No field_name for DocType properties
    "property": "title_field",
    "value": "customer_name",
    "property_type": "Data",
    "doctype_or_field": "DocType"       # ← Note: "DocType" not "DocField"
}).insert()
```

### Change Default Sort
```python
frappe.get_doc({
    "doctype": "Property Setter",
    "doc_type": "Customer",
    "field_name": None,
    "property": "sort_field",
    "value": "customer_name",
    "property_type": "Data",
    "doctype_or_field": "DocType"
}).insert()

frappe.get_doc({
    "doctype": "Property Setter",
    "doc_type": "Customer",
    "field_name": None,
    "property": "sort_order",
    "value": "ASC",
    "property_type": "Data",
    "doctype_or_field": "DocType"
}).insert()
```

---

## 11. Summary & Best Practices

### When to Use What

| Scenario | Solution |
|----------|----------|
| Add new field to existing DocType | Custom Field |
| Change field label | Property Setter |
| Hide standard field | Property Setter |
| Change field height/width | Property Setter |
| Make field required | Property Setter |
| Change DocType title field | Property Setter (DocType-level) |
| Create entirely new DocType | Base JSON via DocType builder |

### Golden Rules

1. **Never edit base JSON files for standard Frappe DocTypes** - use Property Setters
2. **Always use `frappe.get_meta()`** to get live metadata (with customizations)
3. **Use `field.as_dict()`** to get all field properties including Property Setter overrides
4. **Set `doctype_or_field` correctly** - "DocField" for fields, "DocType" for DocType properties
5. **Convert values to strings** when creating Property Setters
6. **Export to fixtures** for version control and multi-site deployment
7. **Test on staging** before deploying customizations to production
8. **Don't delete core fields** - hide them instead
9. **Validate comprehensively** - collect all errors before rejecting
10. **Document your customizations** - future developers will thank you

---

## 12. References & Related Documentation

- Frappe Meta API: `frappe.get_meta()`
- Property Setter DocType structure
- Custom Field DocType structure
- Fixtures: `bench export-fixtures` command
- Layout Editor implementation (see `SESSION-HANDOFF-2026-01-03.md`)

---

**Last Validated**: January 3, 2026  
**Implementation**: Layout Editor v1.0.33  
**Status**: ✅ Production-ready, all concepts validated through real-world use





