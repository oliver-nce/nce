# Frappe Database Architecture: Shared Tables Across Apps

## Overview

This document explains how multiple Frappe apps share database tables within a single site. Understanding this architecture is crucial for custom app development, data querying, and troubleshooting on Frappe Cloud.

## Single Database Model

### One Site, One Database

Each Frappe site corresponds to exactly one MariaDB/MySQL database. All apps installed on that site write to this shared database. There is no database-level isolation between apps.

**Site Configuration** (`site_config.json`):
```json
{
  "db_name": "abc123_sitename",
  "db_password": "auto_generated"
}
```

### Table Creation

When you install an app, Frappe creates tables for each non-virtual DocType defined in that app. The table naming convention:

- DocType "Sales Order" → Table `tabSales Order`
- DocType "My Custom Widget" → Table `tabMy Custom Widget`
- Child DocType "Sales Order Item" → Table `tabSales Order Item`

All tables share the same database regardless of which app defined them.

## Standard Table Structure

### Automatic Columns

Every DocType table includes these columns automatically:

| Column | Type | Purpose |
|--------|------|---------|
| `name` | VARCHAR(140) | Primary key (document ID) |
| `creation` | DATETIME | Record creation timestamp |
| `modified` | DATETIME | Last modification timestamp |
| `modified_by` | VARCHAR(140) | User who last modified |
| `owner` | VARCHAR(140) | User who created record |
| `docstatus` | INT | Workflow state (0=Draft, 1=Submitted, 2=Cancelled) |
| `idx` | INT | Sort order index |

### Child Table Columns

Child DocTypes (Is Child Table = Yes) add these columns:

| Column | Type | Purpose |
|--------|------|---------|
| `parent` | VARCHAR(140) | Parent document name |
| `parenttype` | VARCHAR(140) | Parent DocType name |
| `parentfield` | VARCHAR(140) | Field name in parent |

### Field-to-Column Mapping

DocType fields become table columns with mapped types:

| Frappe Fieldtype | MySQL Type |
|------------------|------------|
| Data | VARCHAR(140) |
| Link | VARCHAR(140) |
| Select | VARCHAR(140) |
| Text | TEXT |
| Long Text | LONGTEXT |
| Int | INT |
| Float | DECIMAL(18,6) |
| Currency | DECIMAL(18,6) |
| Percent | DECIMAL(18,6) |
| Check | INT(1) |
| Date | DATE |
| Datetime | DATETIME |
| Time | TIME |
| Password | TEXT (encrypted) |

## Cross-App Table Access

### Querying Any Table

From any app's Python code, you can query tables defined by other apps:

```python
import frappe

# Query ERPNext's Customer table from custom app
customers = frappe.db.get_all("Customer",
    filters={"disabled": 0},
    fields=["name", "customer_name", "territory"]
)

# Direct SQL works on any table
results = frappe.db.sql("""
    SELECT name, customer_name 
    FROM `tabCustomer` 
    WHERE territory = %s
""", ("United States",), as_dict=True)
```

### Link Fields Create Relationships

When your custom DocType has a Link field to another app's DocType:

```json
{
  "fieldname": "customer",
  "fieldtype": "Link",
  "options": "Customer"
}
```

The `customer` column stores the `name` value from `tabCustomer`. This is a logical foreign key—no database-level constraint exists.

### Joining Tables

Query across app boundaries with JOINs:

```python
data = frappe.db.sql("""
    SELECT 
        mo.name as order_name,
        c.customer_name,
        c.territory
    FROM `tabMy Order` mo
    JOIN `tabCustomer` c ON mo.customer = c.name
    WHERE mo.docstatus = 1
""", as_dict=True)
```

## Special Table Types

### Single DocTypes

DocTypes marked as "Is Single" don't get their own table. Instead, values store in `tabSingles`:

```sql
SELECT * FROM tabSingles 
WHERE doctype = 'System Settings';
```

Returns rows like:
```
doctype          | field           | value
System Settings  | date_format     | dd-mm-yyyy
System Settings  | time_format     | HH:mm:ss
```

### Virtual DocTypes

DocTypes marked as "Is Virtual" create no database table. They exist only as metadata for code that provides data through other means (external APIs, computed values).

### Custom Fields Table

Custom Fields added via UI or fixtures store in `tabCustom Field` and `tabProperty Setter`, not by altering the original DocType's table. The field values still store in the DocType's table column.

```sql
-- Custom Field definition
SELECT * FROM `tabCustom Field` 
WHERE dt = 'Customer';

-- The actual data is in the Customer table
SELECT name, custom_field_name FROM `tabCustomer`;
```

## Data Integrity Considerations

### No Foreign Key Constraints

Frappe does not create database-level foreign keys. Link field relationships are enforced by application logic:

- Deletion protection checks for linked documents
- Link validation occurs in Python, not SQL
- Orphan prevention is application-side

### Soft Deletion Pattern

Frappe typically uses "Cancel" (docstatus=2) rather than DELETE for transactional documents. Some DocTypes allow actual deletion for master data.

### Transaction Handling

Frappe auto-commits after each web request. For explicit transaction control:

```python
frappe.db.begin()
try:
    # Multiple operations
    frappe.db.sql("UPDATE ...")
    frappe.db.sql("INSERT ...")
    frappe.db.commit()
except Exception:
    frappe.db.rollback()
    raise
```

## Querying Best Practices

### Use the ORM When Possible

```python
# Preferred: Uses permissions, triggers events
doc = frappe.get_doc("Customer", "CUST-001")
doc.territory = "Europe"
doc.save()

# Avoid unless necessary: Bypasses application logic
frappe.db.set_value("Customer", "CUST-001", "territory", "Europe")
```

### Escaping and Security

```python
# Safe: Parameterized query
results = frappe.db.sql(
    "SELECT * FROM `tabCustomer` WHERE name = %s",
    (customer_name,)
)

# Unsafe: SQL injection risk
results = frappe.db.sql(
    f"SELECT * FROM `tabCustomer` WHERE name = '{customer_name}'"
)
```

### Performance Considerations

```python
# Efficient: Fetch only needed fields
names = frappe.get_all("Customer", 
    filters={"disabled": 0},
    pluck="name"  # Returns list of names only
)

# Inefficient: Loads full documents
all_docs = [frappe.get_doc("Customer", n) for n in names]
```

## Multi-App Scenarios

### App A Creates DocType

When App A defines `tabWidget`:
- App B can query `tabWidget` directly
- App B can Link to Widget DocType
- App B can extend Widget via Custom Fields

### Shared Dependencies

If multiple apps need common functionality, consider:

1. **Explicit dependency**: One app requires the other via `required_apps`
2. **Frappe core**: Use built-in DocTypes when suitable
3. **Optional integration**: Check app presence at runtime

### Namespace Collisions

DocType names must be unique across all apps. If App A defines "Task" and App B also defines "Task", installation fails. Use app-specific prefixes for custom DocTypes to avoid collisions.

## Related Documentation

- Frappe Migrations and Schema Auto-Deployment (#09)
- Code vs Data Deployment Concepts (#10)
- Frappe App Integration Patterns (#11)

## Sources

- https://docs.frappe.io/framework/user/en/basics/doctypes
- https://docs.frappe.io/framework/user/en/api/database
- https://docs.frappe.io/framework/user/en/basics/doctypes/fieldtypes
- https://docs.frappe.io/framework/user/en/tutorial/create-a-doctype
