# Frappe Cloud: Core Concepts and Architecture

## Overview

Frappe Cloud (accessed at cloud.frappe.io or frappecloud.com) is a managed hosting platform for the Frappe Framework stack. It provides a web-based dashboard for deploying, managing, and scaling Frappe applications such as ERPNext, Frappe HR, CRM, and custom apps.

The platform is built on AWS and OCI infrastructure with data centers in multiple regions worldwide. It is powered by an open-source orchestration system called Press, which uses Ansible for server setup and a Flask-based Agent for site-level operations.

## Key Terminology

Understanding these core concepts is essential for working with Frappe Cloud:

### Sites

A **Site** is a single Frappe installation with its own database, users, and configuration. Each site:

- Has a unique subdomain (e.g., `yourcompany.frappe.cloud`)
- Contains one or more installed Frappe apps
- Runs on a shared or dedicated infrastructure
- Is accessible only via HTTPS

Sites are the primary billing unit—you are charged based on the number of active sites.

### Benches

A **Bench** is a runtime environment containing:

- A collection of Frappe apps at specific versions
- One or more sites that share those app versions
- Configuration settings (dependencies, common site config)

All sites on a Bench share the same app versions. When apps are updated, a new Bench is created, and sites are migrated to it.

### Bench Groups

A **Bench Group** is a template and collection of Benches. It defines:

- Which apps to install
- What version of dependencies to use (Python, Node.js, MariaDB)
- Common site configuration flags

There are two types:

1. **Public Bench Groups** — Managed by Frappe, shared across users. You cannot add custom apps or control update timing.

2. **Private Bench Groups** — Under your control. You can add custom apps, control update schedules, access SSH, and enable server scripts. Available for sites on USD 25+ plans.

### Servers

For dedicated hosting, you can provision your own servers:

- **Application Server** — Runs your benches and sites
- **Database Server** — Hosts MariaDB for your sites

Servers are available in various plans based on CPU, RAM, and storage requirements.

## Resource Hierarchy

```
Team (Account)
├── Sites (on Public Benches)
├── Bench Groups (Private)
│   ├── Benches (deployed versions)
│   │   └── Sites
│   └── Apps (from GitHub or Marketplace)
└── Servers (Dedicated)
    └── Bench Groups
        └── Sites
```

## How Deployments Work

When you deploy or update a Bench Group:

1. A **Deploy** job is created
2. A Docker image is built with your apps installed via `frappe/bench` CLI
3. The new **Bench** is initialized as a container
4. Sites are either created on or migrated to the new Bench
5. Old Benches are archived after successful migration

Site updates happen during non-working hours (1 AM - 4 AM) if auto-update is enabled.

## Infrastructure and Security

Frappe Cloud provides:

- **Free SSL certificates** for all domains (Let's Encrypt)
- **HTTP/2 protocol** for all sites
- **Automated offsite backups** stored on AWS S3
- **SOC 2 Type II** attestation and **ISO 27001:2022** certification

All communications use HTTPS. Backup encryption is optional and configurable via site config.

## Plan Tiers and Features

Feature availability depends on your plan:

| Feature | Tiny ($5) | Basic ($10) | Standard ($25+) | Dedicated |
|---------|-----------|-------------|-----------------|-----------|
| Site Creation | ✓ | ✓ | ✓ | ✓ |
| Custom Domains | ✓ | ✓ | ✓ | ✓ |
| Automated Backups | — | — | ✓ | ✓ |
| Private Benches | — | — | ✓ | ✓ |
| SSH Access | — | — | ✓ | ✓ |
| Server Scripts | — | — | ✓ (v15+) | ✓ |
| Database Access | — | — | ✓ ($50+) | ✓ |

## Related Concepts

The following documentation chunks cover specific UI workflows:

- **02-site-management.md** — Creating, configuring, and managing sites
- **03-bench-groups-apps.md** — Working with private benches and custom apps
- **04-github-integration.md** — Connecting repositories and deploying custom apps
- **05-team-billing-account.md** — Account management, teams, and billing
- **06-operations-devtools.md** — Monitoring, backups, and developer tools
