# Code vs Data: Deployment Fundamentals

## Overview

This document clarifies a fundamental principle in software deployment that applies to Frappe applications on Frappe Cloud: **code deploys separately from data**. Understanding this distinction prevents common misconceptions about what happens when you push updates.

## The Separation Principle

### What Deploys as "Code"

When you push changes to your GitHub repository and trigger a Frappe Cloud deployment, the following elements travel with your code:

**DocType Definitions (Schema)**
- Field structures stored in JSON files
- Naming rules and configurations
- Permission definitions
- Form layouts and UI metadata

**Application Logic**
- Python controllers and API endpoints
- JavaScript form scripts and client logic
- Server scripts and scheduled tasks
- Jinja templates for reports and prints

**Static Assets**
- CSS stylesheets
- JavaScript libraries
- Images and icons bundled with the app

**Fixtures (Predefined Data)**
- Records explicitly exported via the fixtures hook
- Custom Fields, Property Setters, Translations
- Configuration records defined by the developer

### What Stays as "Data"

Data remains on the site's database and does NOT transfer through code deployment:

**User-Created Documents**
- All records created through the application UI
- Sales Orders, Invoices, Customers, Items—everything users enter

**Site-Specific Configurations**
- System Settings modified by administrators
- User accounts and role assignments
- Custom Print Formats created in the UI
- Workspace customizations

**File Attachments**
- Uploaded documents and images
- Generated PDFs and reports

**Audit Trails**
- Version history of documents
- Activity logs and comments
- Communication records

## Why This Matters

### Development Environment Isolation

Your local development site contains test data that should never reach production. The code/data separation ensures:

- Test customers don't appear in live systems
- Sample transactions don't pollute real books
- Development user accounts stay local

### Multi-Tenant Architecture

On Frappe Cloud (and any multi-site Frappe installation), multiple sites share the same codebase. Each site maintains its own database. Deploying code updates all sites simultaneously while preserving each site's unique data.

### Continuous Deployment Safety

You can deploy code changes frequently without risk of overwriting user data. The migration process:

1. Applies schema changes (adds columns, creates tables)
2. Runs data patches (transforms existing records)
3. Never deletes or replaces user-created documents

## Handling Data Requirements

### Fixtures for Seeded Data

If your application requires baseline data (categories, default settings, reference tables), use the fixtures system:

**hooks.py**
```python
fixtures = [
    "Custom Field",
    {"dt": "Role", "filters": [["role_name", "like", "My App%"]]},
    "Currency"
]
```

Running `bench export-fixtures` captures specified records into JSON files. These import automatically during app installation and migration.

### Patches for Data Transformations

When schema changes require modifying existing data, write migration patches:

```python
# patches/v14_0/set_default_currency.py
import frappe

def execute():
    # Update existing records to work with new field
    frappe.db.sql("""
        UPDATE `tabCustomer`
        SET default_currency = 'USD'
        WHERE default_currency IS NULL
    """)
```

### Data Import for Initial Setup

For bulk data loading (product catalogs, customer lists), use:

- Data Import Tool in the UI
- REST API calls from external systems
- Custom scripts executed post-installation

These methods work with data, not code, and run after deployment.

## Common Misconceptions

### "My test data will go to production"

**False**. Data stays in your local database. Only code files (Python, JavaScript, JSON definitions) deploy.

### "Deleting a field removes the data"

**Partially true**. Removing a field from DocType JSON hides it from the UI but retains the database column. Data persists until explicitly deleted via patch or direct database command.

### "I need to recreate my configuration on each site"

**Depends**. If configuration is defined in fixtures, it deploys with code. If users created it through the UI, it's site-specific data and must be recreated or migrated separately.

### "Database backups include my code changes"

**False**. Database backups contain only data. Code exists in the Git repository. A complete disaster recovery requires both:

1. Database backup (data)
2. Git repository access (code)

## Practical Workflow

### Local Development

1. Write code and modify DocTypes in Developer Mode
2. Create test data for validation
3. Export fixtures for any required seed data
4. Write patches for data transformations
5. Commit code changes to Git

### Deployment to Frappe Cloud

1. Push to GitHub repository
2. Frappe Cloud pulls code and runs build
3. Migration applies schema changes via DocType JSONs
4. Fixtures import predefined records
5. Patches transform existing data
6. Application serves updated code with preserved user data

### Data Migration Between Environments

For moving data (not code) between sites:

- Use `bench backup` and `bench restore`
- Export/import via Data Import Tool
- Utilize REST API for selective synchronization
- Consider Frappe's Data Migration Tool for complex scenarios

## Related Documentation

- Frappe Migrations and Schema Auto-Deployment (#09)
- Frappe Cloud: Bench Groups and Apps (#03)
- Frappe Cloud: Operations and Dev Tools (#06)

## Sources

- https://docs.frappe.io/framework/user/en/database-migrations
- https://docs.frappe.io/framework/user/en/python-api/hooks#fixtures
- https://docs.frappe.io/framework/user/en/basics/apps
