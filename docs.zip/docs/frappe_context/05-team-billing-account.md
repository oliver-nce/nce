# Frappe Cloud: Team Management, Billing, and Account Settings

## Overview

Frappe Cloud organizes resources under Teams. When you sign up, a default team is created for you. This document covers account management, team members, role permissions, billing configuration, and notification settings.

## Account Structure

### Teams

A Team is the organizational unit that owns:

- Sites
- Bench Groups
- Servers
- Billing and payment methods

You can belong to multiple teams and switch between them.

### Accessing Settings

Navigate to **Settings** in the Frappe Cloud dashboard to access:

- Profile & Team settings
- Billing configuration
- SSH keys
- API tokens
- Notification preferences

## Managing Team Members

### Adding Members

1. Go to **Settings** > **Profile & Team**
2. Click **Manage Members** under Team Members section
3. Click **Add Member**
4. Enter the email address
5. Click **Send Invitation**

The invited user receives an email to join the team.

### Removing Members

1. Go to Settings > Profile & Team > Manage Members
2. Find the member in the list
3. Click **Remove** next to their name
4. Confirm the removal

### Team Member Access

Team members can access resources on your behalf. By default, new members have unrestricted access unless assigned to a role with specific permissions.

## Role-Based Permissions

Frappe Cloud provides granular permission control for team members.

### Available Permission Types

Permissions can be configured for:

- **Sites** — Access to specific sites
- **Bench Groups** — Access to specific bench groups
- **Servers** — Access to specific servers

### Configuring Roles

Only Team owners and admins can configure roles:

1. Go to Settings > **Role Permissions**
2. Create or select a role
3. Click **Add** to add permissions
4. Select the resource type (Site, Bench Group, Server)
5. Choose specific resources to grant access
6. Save the role

### Assigning Roles

1. When inviting a new member, assign them to a role
2. Existing members can be updated through the team management interface

### Permission Notes

- Members without a role have **unrestricted access**
- Enabling creation permissions (Site/Bench Group/Server) grants access to newly created resources
- Roles are team-specific

## Switching Between Teams

If you belong to multiple teams:

1. Click on the team selector in the dashboard header
2. Select the team you want to work with
3. The dashboard updates to show that team's resources

## Billing Overview

### Billing Model

Frappe Cloud uses compute-based pricing:

- Charged based on the number of **active sites**
- No per-user fees
- Daily usage tracking with monthly billing cycle

### Viewing Usage

1. Go to **Settings** > **Billing**
2. View current usage amount
3. See breakdown by site and resource type

Usage is updated daily.

### Billing Cycle

- Usage is tracked daily based on active sites
- Invoices are generated monthly
- Payment is automatically charged to your payment method

## Payment Methods

### Adding a Card

1. Go to Settings > Billing
2. Navigate to **Payment Methods**
3. Click **Add Card**
4. Enter card details
5. Save the payment method

### Payment Options

Frappe Cloud accepts:

- Credit/debit cards (via Stripe)
- Wallet credits
- Additional regional payment options may be available

### Adding Credits

You can add wallet credits to your account:

1. Go to Settings > Billing
2. Add credits via the Credits section
3. Credits are applied to future invoices

New accounts receive $10 in free credits.

## Invoices

### Viewing Invoices

1. Go to Settings > Billing
2. Navigate to the Invoices section
3. View invoice history with status (Paid/Unpaid)

Each invoice includes:

- Period covered
- Line items (site charges, marketplace apps)
- Payment status
- Total amount

### Invoice Contents

Invoices itemize:

- Site charges by plan
- Marketplace app subscriptions
- Server costs (if applicable)
- Any credits applied

## Managing Plan Changes

### Site Plans

Change site plans without downtime:

1. Go to Site Dashboard
2. Navigate to **Change Plan** (via Actions menu)
3. Select new plan
4. Confirm the change

Changes take effect immediately.

### Server Plans

Changing server plans involves downtime:

1. Go to Server Dashboard
2. Select **Change Plan**
3. Review the impact
4. Confirm the change

The server VM is replaced, causing brief downtime.

## Notification Settings

### Team Notifications

Configure where notifications are sent:

1. Go to Settings > **Notifications** or **Notification Configuration**
2. Set the notification email for the team
3. Configure notification preferences

### Site-Level Notifications

Sites can have individual notification settings:

1. Go to Site Dashboard > Actions > **Notification Configuration**
2. Configure alerts for:
   - Site status changes
   - Backup completion
   - Update availability
   - Error thresholds

### Server-Level Notifications

For dedicated servers:

1. Go to Server Dashboard > **Notification Configuration**
2. Set up alerts for:
   - Resource usage
   - Server health
   - Maintenance events

## Account Cancellation

### Disabling Account

To cancel your Frappe Cloud subscription:

1. Go to Settings > Billing
2. Click **Disable Account** or **Cancel Subscription**
3. Confirm the cancellation

### Before Cancellation

- Download all backups you need
- Delete sites or migrate them elsewhere
- Settle any outstanding invoices

### After Cancellation

- Sites are deactivated
- Data may be retained for a limited period
- Outstanding charges are processed

## Two-Factor Authentication (2FA)

Frappe Cloud supports 2FA for enhanced security:

1. Go to Settings > Security or Profile
2. Enable Two-Factor Authentication
3. Set up your authenticator app
4. Verify the setup

## API Access

For programmatic access to Frappe Cloud:

### Creating Access Tokens

1. Go to Settings > **API**
2. Click **Create Access Token**
3. Note the API key and secret (shown only once)

### Authentication

API requests require:

```
Authorization: Token <api-key>:<api-secret>
X-Press-Team: <team-name>
```

See the API documentation for available endpoints.

## Related Concepts

- **Sites** — Primary billing unit
- **Role Permissions** — Granular access control
- **Notifications** — Alerts for site and server events
- **API** — Programmatic access to Frappe Cloud resources
