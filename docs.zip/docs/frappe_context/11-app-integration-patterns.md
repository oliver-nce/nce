# Frappe App Integration Patterns

## Overview

Frappe applications on the same site share a single database and can integrate deeply with each other. This document covers the technical patterns for building apps that extend, customize, or interact with other Frappe apps—essential knowledge for custom development on Frappe Cloud.

## Shared Database Architecture

### Single Database Per Site

All apps installed on a Frappe site share one MariaDB/MySQL database. This architecture enables:

- Direct SQL queries across app boundaries
- Link fields referencing any installed DocType
- Shared user and permission systems
- Unified document workflow

### Table Namespace

Every DocType creates a table prefixed with `tab`. Tables from different apps coexist:

```
tabUser (frappe core)
tabSales Order (erpnext)
tabCustom Widget (your_app)
```

Apps can query any table regardless of which app defined it.

## Integration via Link Fields

### Basic Link Field

The simplest integration pattern: reference documents from another app's DocType.

```json
{
  "fieldname": "customer",
  "fieldtype": "Link",
  "options": "Customer",
  "label": "Customer"
}
```

This creates a foreign-key-style relationship. The field stores the `name` (primary key) of the linked Customer document.

### Dynamic Link Fields

When the target DocType varies, use Dynamic Link:

```json
{
  "fieldname": "reference_doctype",
  "fieldtype": "Link",
  "options": "DocType",
  "label": "Reference Type"
},
{
  "fieldname": "reference_name",
  "fieldtype": "Dynamic Link",
  "options": "reference_doctype",
  "label": "Reference Document"
}
```

This pattern appears throughout ERPNext for generic document references.

### Table (Child) DocTypes

Embed repeating data structures using Table fields:

```json
{
  "fieldname": "items",
  "fieldtype": "Table",
  "options": "Sales Order Item",
  "label": "Items"
}
```

Child DocTypes store rows in their own table (`tabSales Order Item`) with `parent` and `parenttype` columns linking back to the parent document.

## Hooks-Based Extension

### Extending Other App's DocTypes

Add fields to DocTypes from other apps using Custom Fields (via fixtures):

**hooks.py**
```python
fixtures = [
    {
        "dt": "Custom Field",
        "filters": [["module", "=", "My App"]]
    }
]
```

Custom Fields modify another DocType without changing its source files. The field definitions store in the database and export via fixtures.

### Document Event Hooks

React to CRUD operations on any DocType:

**hooks.py**
```python
doc_events = {
    "Sales Order": {
        "on_submit": "myapp.events.sales_order_submitted",
        "before_save": "myapp.events.validate_custom_rules"
    },
    "*": {
        "after_insert": "myapp.events.log_all_inserts"
    }
}
```

**events.py**
```python
def sales_order_submitted(doc, method):
    # doc is the Sales Order document
    # Perform custom logic after submission
    create_related_record(doc)
```

### Extending DocType Classes

Override or extend controller behavior:

**hooks.py**
```python
override_doctype_class = {
    "Sales Order": "myapp.overrides.CustomSalesOrder"
}
```

**overrides.py**
```python
from erpnext.selling.doctype.sales_order.sales_order import SalesOrder

class CustomSalesOrder(SalesOrder):
    def validate(self):
        super().validate()
        self.custom_validation()
    
    def custom_validation(self):
        # Additional validation logic
        pass
```

### Form Script Extensions

Extend client-side behavior:

**hooks.py**
```python
doctype_js = {
    "Sales Order": "public/js/sales_order.js"
}
```

**public/js/sales_order.js**
```javascript
frappe.ui.form.on('Sales Order', {
    refresh: function(frm) {
        // Add custom button
        frm.add_custom_button(__('Custom Action'), function() {
            // Handle click
        });
    }
});
```

## Cross-App Queries

### Using the ORM

Query documents from any installed app:

```python
import frappe

# Get documents from ERPNext
customers = frappe.get_all("Customer",
    filters={"territory": "United States"},
    fields=["name", "customer_name", "outstanding_amount"]
)

# Get single document
so = frappe.get_doc("Sales Order", "SO-00001")
print(so.customer, so.grand_total)
```

### Direct SQL Queries

For complex queries spanning multiple DocTypes:

```python
data = frappe.db.sql("""
    SELECT 
        so.name,
        so.customer,
        c.customer_group,
        SUM(soi.amount) as total
    FROM `tabSales Order` so
    JOIN `tabCustomer` c ON so.customer = c.name
    JOIN `tabSales Order Item` soi ON soi.parent = so.name
    WHERE so.docstatus = 1
    GROUP BY so.name
""", as_dict=True)
```

## App Dependencies

### Declaring Required Apps

If your app depends on another app:

**hooks.py**
```python
required_apps = ["erpnext"]
```

This ensures ERPNext installs before your app, guaranteeing required DocTypes exist.

### Conditional Features

Check for app presence at runtime:

```python
if "hrms" in frappe.get_installed_apps():
    # Use HRMS features
    from hrms.api import get_employee_details
else:
    # Fallback behavior
    pass
```

## Dashboard Connections

### Document Links

Define relationships shown in document dashboards:

**[doctype]_dashboard.py**
```python
def get_data():
    return {
        "fieldname": "sales_order",
        "transactions": [
            {
                "label": "Fulfillment",
                "items": ["Delivery Note", "Sales Invoice"]
            }
        ]
    }
```

This creates clickable links showing related documents.

## Permission Integration

### Checking Permissions

Respect the permission system when querying:

```python
# Applies user permissions automatically
docs = frappe.get_list("Customer")

# Bypasses permissions (use carefully)
docs = frappe.get_all("Customer")
```

### Custom Permission Logic

Add permission conditions via hooks:

**hooks.py**
```python
permission_query_conditions = {
    "Customer": "myapp.permissions.customer_query"
}

has_permission = {
    "Customer": "myapp.permissions.customer_permission"
}
```

## Best Practices

### Avoid Direct Table Modifications

Never ALTER TABLE manually. Define schema through DocTypes and let migrations handle database changes.

### Use Hooks Over Source Modification

Extend via hooks rather than modifying other apps' source files. This preserves upgrade compatibility.

### Document Dependencies

Clearly document which apps your integration requires and any version constraints.

### Test Cross-App Scenarios

Integration tests should include scenarios with and without optional dependent apps installed.

## Related Documentation

- Frappe Migrations and Schema Auto-Deployment (#09)
- Code vs Data Deployment Concepts (#10)
- Frappe Cloud: Bench Groups and Apps (#03)

## Sources

- https://docs.frappe.io/framework/user/en/python-api/hooks
- https://docs.frappe.io/framework/user/en/basics/doctypes
- https://docs.frappe.io/framework/user/en/basics/apps
- https://docs.frappe.io/framework/user/en/basics/doctypes/controllers
