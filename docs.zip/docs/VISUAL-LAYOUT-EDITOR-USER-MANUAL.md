# Visual Layout Editor - User Manual

**Version**: 2.0 (Proposed)  
**Date**: January 3, 2026  
**Status**: Design Document

---

## Overview

The Visual Layout Editor is an intuitive, drag-and-drop interface for customizing Frappe DocType forms. It provides two synchronized views for editing form layouts:

1. **Visual Panel** - See your form structure with drag-and-drop capabilities
2. **Properties Panel** - Edit detailed field properties

All changes are saved as Property Setters (database customizations) that can be exported to fixtures and deployed across sites.

---

## Interface Layout

```
┌─────────────────────────────────────────────────────────────────────────┐
│ [NCE] Layout Editor                                [Validate] [Save]     │
├─────────────────────────────────────────────────────────────────────────┤
│ DocType: [WP Zoho Registration          ▼]  [Load DocType]              │
├──────────────────────────────────────┬──────────────────────────────────┤
│                                      │                                  │
│  VISUAL STRUCTURE                    │  PROPERTIES EDITOR               │
│                                      │                                  │
│  [Tab: Details] [Tab: System]       │  Selected Element:               │
│  ┌────────────────────────────────┐ │  ┌────────────────────────────┐ │
│  │ 📋 Section: Basic Information │ │  │ Type: Section Break        │ │
│  │ [☰] [✏️] [👁️] [🗑️]             │ │  │ Fieldname: basic_section  │ │
│  │                                │ │  │ Label: Basic Information   │ │
│  │  ┌─────────┬─────────────────┐│ │  │ Collapsible: ☑            │ │
│  │  │ Col 1   │ Col 2 (66%)     ││ │  └────────────────────────────┘ │
│  │  │         │                 ││ │                                  │
│  │  │ 📝 Name │ 📧 Email        ││ │  [Update Property]               │
│  │  │         │ 📱 Phone        ││ │                                  │
│  │  │         │                 ││ │  Quick Actions:                  │
│  │  └─────────┴─────────────────┘│ │  • Hide field                    │
│  │                                │ │  • Make required                 │
│  │  + Add Field                   │ │  • Make read-only                │
│  └────────────────────────────────┘ │  • Delete field                  │
│                                      │                                  │
│  📋 Section: Address Details         │  Recent Changes:                 │
│  [☰] [✏️] [👁️] [🗑️]                  │  • Email: label changed          │
│  ┌──────────────────────────────┐   │  • Phone: added to form          │
│  │ 📍 Street Address (100%)     │   │                                  │
│  │ 🏙️ City   🏛️ State  📮 ZIP   │   │  [Export to Fixtures]            │
│  └──────────────────────────────┘   │  [Clear All Customizations]      │
│                                      │                                  │
│  + Add Section                       │                                  │
│  + Add Column Break                  │                                  │
│                                      │                                  │
└──────────────────────────────────────┴──────────────────────────────────┘
```

---

## Key Features

### 1. Visual Structure Panel (Left Side)

#### Tab Navigation
- **Tab Pills** at the top show all form tabs
- Click to switch between tabs
- Drag tabs to reorder them
- Right-click for tab options (rename, delete, add new)

#### Section Blocks
Each section displays as a collapsible card with:
- **Section Icon** (📋) and label
- **Control Icons**:
  - ☰ (Drag handle) - Reorder section
  - ✏️ (Edit) - Rename section
  - 👁️ (Visibility) - Show/hide section
  - 🗑️ (Delete) - Remove section

#### Column Layout
Sections show their column structure visually:
```
┌─────────┬─────────────────┐
│ Col 1   │ Col 2 (66%)     │  ← Column width shown as percentage
│ (33%)   │                 │
│         │                 │
└─────────┴─────────────────┘
```

#### Field Display
Each field shown with:
- **Icon** indicating field type:
  - 📝 Data/Text fields
  - 📧 Email
  - 📱 Phone
  - 🔗 Link
  - ☑️ Checkbox
  - 📅 Date/Datetime
  - 💰 Currency
  - #️⃣ Numbers
  - 📊 Table/Child Table
  - 📄 Text Editor
  - 🔽 Select/Dropdown
- **Field Label** (user-facing name)
- **Required indicator** (red asterisk if required)
- **Hidden indicator** (👁️‍🗨️ if field is hidden)

---

## How to Use

### A. Loading a DocType for Editing

1. Open **Layout Editor** from workspace or search
2. Select DocType from dropdown (auto-suggests as you type)
3. Click **[Load DocType]** button
4. Visual structure loads in left panel
5. All tabs, sections, and fields appear

**Result**: You see the complete form structure with all current customizations already applied.

---

### B. Editing Individual Field Properties

#### Method 1: Click to Edit
1. Click any field in the Visual Panel
2. Field highlights with blue border
3. Properties Panel shows all editable properties
4. Edit properties (label, description, rows, columns, etc.)
5. Click **[Update Property]** to save
6. Visual Panel updates immediately

#### Method 2: Quick Actions
1. Right-click any field
2. Context menu appears:
   ```
   ┌─────────────────────────┐
   │ Edit Properties         │
   │ ─────────────────────── │
   │ ☑️ Make Required        │
   │ 👁️ Hide Field           │
   │ 🔒 Make Read-Only       │
   │ ─────────────────────── │
   │ ⬆️ Move Up              │
   │ ⬇️ Move Down            │
   │ ⬅️ Move to Left Column  │
   │ ➡️ Move to Right Column │
   │ ─────────────────────── │
   │ 📋 Duplicate Field      │
   │ 🗑️ Delete Field         │
   └─────────────────────────┘
   ```
3. Click action → change applies immediately

#### Common Property Edits

**Change Field Label**:
1. Click field
2. Properties Panel → Label field
3. Type new label
4. Update → Label changes in form

**Adjust Text Area Height**:
1. Click text field
2. Properties Panel → Rows
3. Set number (1-10)
4. Update → Field expands/contracts

**Change Column Width**:
1. Click field
2. Properties Panel → Columns
3. Select: 1-12 (Bootstrap grid)
4. Update → Field resizes

**Hide/Show Field**:
1. Click field
2. Properties Panel → Hidden checkbox
3. Check to hide, uncheck to show
4. Update → Field visibility changes

---

### C. Managing Sections

#### Create New Section
1. Click **[+ Add Section]** at bottom of tab
2. Modal appears:
   ```
   ┌─────────────────────────────────┐
   │  Add New Section                │
   ├─────────────────────────────────┤
   │  Label: [Basic Information   ] │
   │                                 │
   │  Collapsible: ☑️                │
   │  Initially Collapsed: ☐         │
   │                                 │
   │  Columns: ⚪ 1  ⚫ 2  ⚪ 3       │
   │                                 │
   │        [Cancel]  [Create]       │
   └─────────────────────────────────┘
   ```
3. Enter label and options
4. Click **[Create]**
5. New section appears in Visual Panel

#### Reorder Sections
1. Hover over section
2. Drag handle (☰) appears
3. Click and drag section up/down
4. Drop in new position
5. Section reorders
6. All fields within section move together

#### Edit Section Properties
1. Click section header (not fields within)
2. Properties Panel shows section properties:
   - Label
   - Collapsible (yes/no)
   - Collapsed by default
   - Column count
3. Edit and update
4. Section updates in Visual Panel

#### Delete Section
1. Click delete icon (🗑️) on section
2. Confirmation dialog:
   ```
   ┌─────────────────────────────────────┐
   │  Delete Section?                    │
   ├─────────────────────────────────────┤
   │  This will delete:                  │
   │  • Section Break: "Address Details" │
   │  • Column Break(s) within section   │
   │                                     │
   │  Fields will move to previous       │
   │  section.                           │
   │                                     │
   │  ⚠️ This cannot be undone.          │
   │                                     │
   │       [Cancel]  [Delete]            │
   └─────────────────────────────────────┘
   ```
3. Click **[Delete]** to confirm
4. Section removed, fields preserved

---

### D. Managing Columns

#### Add Column Break
1. Select section
2. Click **[+ Add Column Break]**
3. New column appears
4. Fields after break move to new column

#### Adjust Column Widths
Two methods:

**Method 1: Visual Slider**
1. Hover between columns in Visual Panel
2. Resize handle appears: `|`
3. Click and drag left/right
4. Column widths adjust in real-time
5. Percentages shown: `Col 1 (33%) | Col 2 (67%)`

**Method 2: Properties Panel**
1. Click column break element
2. Properties Panel shows:
   ```
   Column Width: [4    ▼] (Bootstrap grid: 1-12)
   
   Preview: 33% width
   
   Available: 1-2 columns, 3 columns, 4 columns
   ```
3. Select width
4. Update → Column resizes

#### Move Fields Between Columns
1. Drag field by its icon
2. Drag left or right
3. Drop zone highlights when hovering over column
4. Drop → Field moves to new column

---

### E. Managing Tabs

#### View Tabs
- All tabs shown as pills at top of Visual Panel
- Active tab highlighted
- Click to switch tabs

#### Reorder Tabs
1. Drag tab pill left or right
2. Other tabs shift to make space
3. Drop → Tab order changes
4. Form navigation updates

#### Add New Tab
1. Click **[+ Add Tab]** button
2. Modal appears:
   ```
   ┌─────────────────────────────────┐
   │  Add New Tab                    │
   ├─────────────────────────────────┤
   │  Label: [Additional Info     ]  │
   │                                 │
   │  Position:                      │
   │  ⚪ At end                       │
   │  ⚪ After: [Details        ▼]   │
   │  ⚪ Before: [System        ▼]   │
   │                                 │
   │        [Cancel]  [Create]       │
   └─────────────────────────────────┘
   ```
3. Enter label and position
4. Create → New tab appears

#### Move Section Between Tabs
1. Drag section by handle (☰)
2. Drag up to tab pills area
3. Hover over target tab (tab highlights)
4. Drop → Section moves to that tab

---

### F. Reordering Fields

#### Within Same Section
1. Hover over field
2. Drag handle appears (⠿)
3. Drag up or down
4. Drop → Field reorders
5. Other fields shift automatically

#### To Different Section
1. Drag field up/down
2. Continue past section boundary
3. Next section highlights
4. Drop → Field moves to new section

#### To Different Tab
1. Drag field to tab pills area
2. Hover over destination tab
3. Tab highlights
4. Drop → Field moves to that tab's first section

---

### G. Adding New Fields

**Note**: This creates Custom Fields (new fields), not Property Setters (modifications).

1. Click **[+ Add Field]** in any section
2. Field Creation dialog opens:
   ```
   ┌─────────────────────────────────────────┐
   │  Add Custom Field                       │
   ├─────────────────────────────────────────┤
   │  Field Type: [Data              ▼]      │
   │  Label:      [Customer Name        ]    │
   │  Fieldname:  [custom_customer_name ]    │
   │              (auto-generated)           │
   │                                         │
   │  ☑️ Required                            │
   │  ☐ Read Only                            │
   │  ☐ Hidden                               │
   │                                         │
   │  Position:                              │
   │  ⚫ After: [email             ▼]        │
   │  ⚪ Before: [phone            ▼]        │
   │  ⚪ At end of section                    │
   │                                         │
   │         [Cancel]  [Create]              │
   └─────────────────────────────────────────┘
   ```
3. Fill in details
4. Click **[Create]**
5. New field appears in form
6. Custom Field created in database

---

### H. Validation and Saving

#### Validation Process
1. Make your changes in Visual or Properties Panel
2. Click **[Validate]** button (top right)
3. System checks:
   - All required fields present
   - No duplicate fieldnames
   - No orphaned column breaks
   - Valid field types
   - Proper section structure
   - No core field deletions
4. Results appear:

**If Valid** ✅:
```
┌─────────────────────────────────────┐
│  ✅ Validation Successful           │
├─────────────────────────────────────┤
│  All changes are valid.             │
│                                     │
│  Summary:                           │
│  • 12 properties modified           │
│  • 2 fields reordered               │
│  • 1 section renamed                │
│                                     │
│  [Save] button is now enabled.      │
└─────────────────────────────────────┘
```

**If Invalid** ❌:
```
┌─────────────────────────────────────┐
│  ❌ Validation Failed               │
├─────────────────────────────────────┤
│  Please fix these issues:           │
│                                     │
│  1. Section "Details": Field "name" │
│     is required and cannot be       │
│     deleted. Consider hiding it.    │
│                                     │
│  2. Field "custom_email": Label     │
│     cannot be empty.                │
│                                     │
│  3. Tab "Details": Must have at     │
│     least one section.              │
│                                     │
│  [Save] button remains disabled.    │
└─────────────────────────────────────┘
```

#### Saving Changes
1. After successful validation
2. **[Save]** button becomes active and green
3. Click **[Save]**
4. Progress indicator appears
5. System creates/updates Property Setters
6. Success message:
   ```
   ┌─────────────────────────────────────┐
   │  ✅ Layout Saved Successfully       │
   ├─────────────────────────────────────┤
   │  12 Property Setters created        │
   │  3 Property Setters updated         │
   │                                     │
   │  Changes are now live on this site. │
   │                                     │
   │  Next steps:                        │
   │  • Test the updated form            │
   │  • Export to fixtures               │
   │  • Deploy to other sites            │
   │                                     │
   │         [View Form]  [OK]           │
   └─────────────────────────────────────┘
   ```

---

### I. Exporting to Fixtures

Once you've customized and tested your layout:

1. Click **[Export to Fixtures]** button (Properties Panel)
2. Export dialog appears:
   ```
   ┌─────────────────────────────────────┐
   │  Export to Fixtures                 │
   ├─────────────────────────────────────┤
   │  DocType: WP Zoho Registration      │
   │                                     │
   │  This will export:                  │
   │  • 15 Property Setters              │
   │                                     │
   │  Export to:                         │
   │  ⚫ This app's fixtures directory    │
   │  ⚪ Custom path                      │
   │                                     │
   │        [Cancel]  [Export]           │
   └─────────────────────────────────────┘
   ```
3. Click **[Export]**
4. Fixtures file created/updated
5. Confirmation:
   ```
   ✅ Exported to:
   nce/fixtures/property_setter.json
   
   Next: Commit and push to repository
   ```

---

### J. Deployment Workflow

**Full Customization Workflow:**

```
┌─────────────────┐
│ 1. Customize    │ ← Use Visual Layout Editor on dev/staging site
│    on Site      │   Make all your changes visually
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 2. Test         │ ← Open actual DocType form
│    Changes      │   Verify layout looks correct
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 3. Export       │ ← Click "Export to Fixtures"
│    to Fixtures  │   Creates fixtures/property_setter.json
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 4. Commit to    │ ← git add, commit, push
│    Repository   │   Push fixtures to GitHub
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 5. Deploy to    │ ← Frappe Cloud auto-deploys
│    Production   │   bench migrate applies fixtures
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ 6. Other Sites  │ ← Update app on other sites
│    Get Updates  │   Customizations apply automatically
└─────────────────┘
```

---

## Branding

The Layout Editor uses the NCE brand identity:

**Logo**: NCE logo appears in the header  
**Colors**: NCE brand palette (Citron #D7DF23, Charcoal #231F20)  
**Font**: Poppins

**Visual Design**:
- **Selected fields**: Citron (#D7DF23) border with glow
- **Section headers**: Charcoal (#231F20) background, white text
- **Drag handles**: Citron accent color
- **Drop zones**: Citron dashed border with light fill
- **Buttons**: Citron background, Charcoal text

---

## Visual Elements Reference

### Field Type Icons

| Icon | Field Type | Example |
|------|------------|---------|
| 📝 | Data, Small Text | Name, Title |
| 📄 | Text, Text Editor | Description, Notes |
| 📧 | Email | Email Address |
| 📱 | Phone | Phone Number |
| 🔗 | Link | Customer, Item |
| ↔️ | Dynamic Link | Reference Document |
| ☑️ | Check | Enabled, Active |
| 🔽 | Select | Status, Type |
| 📅 | Date | Birth Date |
| 🕒 | Datetime | Created At |
| ⏰ | Time | Start Time |
| 💰 | Currency | Amount, Price |
| #️⃣ | Int, Float, Percent | Quantity, Rate |
| 📊 | Table | Items, Details |
| 📎 | Attach, Attach Image | File Upload |
| 💾 | JSON | Configuration Data |
| 🔐 | Password | User Password |
| 🎨 | Color | Brand Color |
| 🌐 | HTML | Custom HTML Block |
| 🔢 | Barcode | Product Code |
| ⚙️ | Button | Action Buttons |

### Section Icons

| Icon | Meaning |
|------|---------|
| 📋 | Regular Section |
| 🔒 | Collapsed Section |
| 👁️ | Visible Section |
| 👁️‍🗨️ | Hidden Section |

### Control Icons

| Icon | Action | Location |
|------|--------|----------|
| ☰ | Drag handle | Sections, Fields |
| ✏️ | Edit/Rename | Sections, Tabs |
| 👁️ | Toggle visibility | Sections, Fields |
| 🗑️ | Delete | Sections, Fields |
| ⚙️ | Settings | Tabs |
| ➕ | Add new | Everywhere |

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl/Cmd + S` | Validate and Save |
| `Ctrl/Cmd + E` | Export to Fixtures |
| `Ctrl/Cmd + Z` | Undo last change |
| `Ctrl/Cmd + Y` | Redo |
| `Delete` | Delete selected field/section |
| `Ctrl/Cmd + D` | Duplicate selected field |
| `↑` / `↓` | Move field up/down |
| `Tab` | Next tab |
| `Shift + Tab` | Previous tab |
| `Esc` | Deselect / Cancel |

---

## Common Workflows

### Workflow 1: Make Text Field Bigger

**Scenario**: Description field is too small (1 row), want to make it 5 rows tall.

**Steps**:
1. Load DocType
2. Find "Description" field in Visual Panel
3. Click on it
4. Properties Panel → Rows: `5`
5. Click **[Update Property]**
6. Field expands in Visual Panel
7. Click **[Validate]** → **[Save]**
8. Done!

**Before**:
```
┌────────────────────────┐
│ Description: [       ] │ ← 1 row
└────────────────────────┘
```

**After**:
```
┌────────────────────────┐
│ Description:           │
│ [                    ] │
│ [                    ] │
│ [                    ] │ ← 5 rows
│ [                    ] │
│ [                    ] │
└────────────────────────┘
```

---

### Workflow 2: Reorganize Form Sections

**Scenario**: Want to move "Address Details" section before "Contact Details" section.

**Steps**:
1. Load DocType
2. Find "Address Details" section
3. Hover → drag handle (☰) appears
4. Click and drag upward
5. Drag over "Contact Details"
6. Drop zone highlights
7. Release → Section moves up
8. **[Validate]** → **[Save]**
9. Done!

---

### Workflow 3: Change Field to Two-Column Layout

**Scenario**: Form has too much vertical scrolling. Want to put Email and Phone side-by-side.

**Steps**:
1. Load DocType
2. Navigate to section with Email and Phone
3. Click between Email and Phone fields
4. Click **[+ Add Column Break]**
5. Phone moves to right column
6. Adjust column widths if needed (drag the `|` handle)
7. **[Validate]** → **[Save]**

**Before**:
```
┌─────────────────┐
│ Email: [...... ]│
│ Phone: [...... ]│
└─────────────────┘
```

**After**:
```
┌─────────┬───────┐
│ Email:  │ Phone:│
│ [....]  │ [...]  │
└─────────┴───────┘
```

---

### Workflow 4: Hide Unused Fields

**Scenario**: DocType has 20 fields, but you only use 10. Want to hide the others.

**Steps**:
1. Load DocType
2. Right-click first unused field
3. Select "Hide Field" from context menu
4. Field dims in Visual Panel (👁️‍🗨️ icon appears)
5. Repeat for other unused fields
6. **[Validate]** → **[Save]**

**Result**: Hidden fields don't appear in form, but data is preserved.

---

## Tips and Best Practices

### 💡 Design Tips

1. **Group Related Fields**: Keep related information in the same section
2. **Use Two Columns for Short Fields**: Email, Phone, City, State work well side-by-side
3. **Keep Important Fields at Top**: Users see them first
4. **Hide Rarely-Used Fields**: Reduces clutter, improves UX
5. **Use Collapsible Sections**: For advanced/optional sections
6. **Logical Tab Organization**: "Details" → "Additional Info" → "System"

### ⚠️ Things to Avoid

1. **Don't Delete Core Fields**: Hide them instead
2. **Don't Create Too Many Tabs**: 3-5 tabs max for usability
3. **Don't Make Everything Required**: Only truly mandatory fields
4. **Don't Use 1-Column for Everything**: Wastes screen space
5. **Don't Forget to Validate**: Always validate before saving

### 🔍 Troubleshooting

**Q: Changes not appearing in actual form?**  
A: Hard refresh the form page (Cmd+Shift+R / Ctrl+F5)

**Q: Can't save - button stays disabled?**  
A: Click **[Validate]** first. Fix any errors shown.

**Q: Changes lost after site update?**  
A: You didn't export to fixtures. Property Setters in DB only are site-specific.

**Q: Dragging doesn't work?**  
A: Make sure you're grabbing the drag handle (☰), not the label.

**Q: Field disappeared?**  
A: Check if it's hidden (👁️‍🗨️ icon). Click visibility icon to show.

---

## Advanced Features

### Undo/Redo

- All changes tracked in session
- Click **Undo** (Ctrl+Z) to revert last change
- Click **Redo** (Ctrl+Y) to reapply
- History preserved until you save or reload

### Change History

Properties Panel shows recent changes:
```
Recent Changes:
• 2 minutes ago: Email label changed
• 5 minutes ago: Phone moved to column 2
• 8 minutes ago: Address section renamed
```

Click any change to see details or revert.

### Copy/Paste Fields

1. Right-click field → Copy
2. Navigate to target section
3. Right-click → Paste
4. Field duplicated with `_copy` suffix
5. Rename as needed

### Bulk Operations

Select multiple fields:
1. Hold `Shift` and click multiple fields
2. Fields highlight
3. Right-click → Bulk actions menu:
   - Hide all selected
   - Make all required
   - Move all to section
   - Delete all selected

---

## Comparison: Old vs New Editor

### Old JSON Editor (v1.0)

```
Pros:
✅ Full control over JSON
✅ Can edit any property
✅ Works for advanced users

Cons:
❌ Requires JSON knowledge
❌ Easy to make syntax errors
❌ No visual feedback
❌ Hard to understand structure
❌ Can't see form layout
❌ Manual field counting for order
```

### New Visual Editor (v2.0)

```
Pros:
✅ Intuitive drag-and-drop
✅ Visual representation
✅ No JSON knowledge needed
✅ Real-time preview
✅ Prevents common errors
✅ Faster for most tasks
✅ Better UX for non-developers
✅ Context menus for quick actions
✅ Undo/redo support

Cons:
❌ May be slower for JSON experts
❌ More complex interface
```

**Recommendation**: Use Visual Editor for most tasks. Switch to JSON editor (still available) for advanced/bulk edits.

---

## Future Enhancements (Planned)

### Phase 2 (Next Version)
- [ ] WYSIWYG preview (see actual Frappe form rendering)
- [ ] Template library (save/load common layouts)
- [ ] Diff view (compare before/after)
- [ ] Auto-suggest field names
- [ ] Bulk import fields from CSV

### Phase 3 (Future)
- [ ] Collaboration (multiple users editing)
- [ ] Version control (rollback to previous layout)
- [ ] Copy layout between DocTypes
- [ ] AI suggestions ("optimize this layout")
- [ ] Mobile layout preview

---

## Getting Help

### Documentation
- This manual
- Frappe documentation: https://frappeframework.com/docs
- Property Setters guide: `/docs/frappe_context/13-doctype-customization-property-setters.md`

### Support
- Ask in Layout Editor discussion forum
- Report bugs in GitHub issues
- Watch video tutorials (coming soon)

---

## Appendix: Technical Details

### How It Works

1. **Load**: `frappe.get_meta(doctype)` returns merged DocType metadata
2. **Display**: JavaScript renders visual tree from field structure
3. **Edit**: Changes tracked in memory (not saved to DB yet)
4. **Validate**: Python function checks for errors
5. **Save**: Creates/updates Property Setter records for each change
6. **Export**: Exports Property Setters to JSON fixtures file

### Property Setter Mapping

| Visual Action | Property Setter Created |
|---------------|------------------------|
| Rename field label | `property: "label"` |
| Resize text field | `property: "rows"` |
| Change column width | `property: "columns"` |
| Hide/show field | `property: "hidden"` |
| Reorder field | `property: "idx"` |
| Make required | `property: "reqd"` |

### Browser Compatibility

- Chrome 90+ ✅
- Firefox 88+ ✅
- Safari 14+ ✅
- Edge 90+ ✅

Requires HTML5 Drag and Drop API support.

---

---

## Logo and Brand Assets

### NCE Logo Location

**Web URL**: `/assets/nce/images/nce_logo.png`  
**File Path**: `nce/public/images/nce_logo.png`

The NCE logo is automatically included in the Layout Editor header.

### Brand Palette Reference

See complete brand guidelines: `nce/public/css/NCE_BRAND_PALETTE.md`

---

**End of User Manual**

*For developers: See `VISUAL-LAYOUT-EDITOR-TECHNICAL-SPEC.md` for implementation details.*

