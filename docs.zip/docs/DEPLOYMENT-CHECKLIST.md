# Deployment Checklist - REST API Version (v0.0.2)

Quick reference guide for deploying the REST API version of the NCE Frappe App.

---

## Pre-Deployment

### WordPress Side

- [ ] **Upload Plugin**
  - File: `custom-sql-endpoint/custom-sql-endpoint.php`
  - Location: `wp-content/plugins/custom-sql-endpoint/`
  - Status: Activated

- [ ] **Create Application Password**
  - Navigate: Users → Your Profile → Application Passwords
  - Name: "Frappe Sync"
  - **Save the password** (you won't see it again!)

- [ ] **Test Plugin (Optional)**
  ```bash
  curl -X POST https://yoursite.com/wp-json/custom/v1/sql-query \
    -u "username:app_password" \
    -H "Content-Type: application/json" \
    -d '{"sql":"SELECT 1 as test"}'
  ```
  Expected: `{"result":[{"test":"1"}]}`

### Frappe Cloud Side

- [ ] **Commit Code to GitHub**
  ```bash
  cd /path/to/nce_frappe_app
  git add .
  git commit -m "Migrate to REST API (v0.0.2)"
  git push origin main
  ```

- [ ] **Verify Repository**
  - Check GitHub repo shows latest commit
  - Verify all files are present

---

## Deployment

### Step 1: Deploy to Frappe Cloud

- [ ] Log in to Frappe Cloud dashboard
- [ ] Navigate to your bench
- [ ] Click "Deploy" or trigger deploy
- [ ] Wait for deployment to complete (check status)
- [ ] Verify no errors in deployment logs

### Step 2: Run Migrations (if needed)

If prompted or if new fields don't show up:

```bash
# Via Frappe Cloud console or SSH
bench --site your-site.frappe.cloud migrate
```

### Step 3: Configure WP Sync Settings

- [ ] Open Frappe site
- [ ] Navigate to: **WP Sync Settings**
- [ ] Fill in new fields:
  - **WordPress Site URL**: `https://yoursite.com` (no trailing slash)
  - **WordPress Username**: Your WP admin username
  - **Application Password**: Paste the password from Pre-Deployment step
- [ ] Click **Save**

### Step 4: Test Connection

- [ ] Click **Test Connection** button
- [ ] Verify message: "Connected Successfully"
- [ ] Check **Connection Status** field shows success

**If connection fails:**
- Verify URL has no trailing slash
- Check username is correct (case-sensitive)
- Regenerate Application Password if needed
- Ensure plugin is activated on WordPress

---

## Post-Deployment Testing

### Test 1: Manual Sync

- [ ] Navigate to: **WP Sync Task**
- [ ] Find your existing task (e.g., "Sync Zoho Registrations")
- [ ] Run the task manually (use API or button if available)
  ```python
  # Via Console
  frappe.call("nce.wp_sync.api.run_task", task_name="YOUR_TASK_NAME")
  ```

### Test 2: Verify Data

- [ ] Navigate to target DocType (e.g., **WP Zoho Registration**)
- [ ] Check if records are present
- [ ] Verify data looks correct
- [ ] Check timestamps (`synced_at` field)

### Test 3: Check Logs

- [ ] Navigate to: **WP Sync Log**
- [ ] Find the latest log entry
- [ ] Verify status is "Success"
- [ ] Check counts (processed, inserted, updated)
- [ ] Review any error messages

### Test 4: Enable Scheduled Sync

- [ ] Go back to: **WP Sync Settings**
- [ ] Check: **Enable Scheduled Sync**
- [ ] Save
- [ ] Wait 5 minutes (or configured interval)
- [ ] Check **WP Sync Log** for automatic sync entry

---

## Monitoring (First 24 Hours)

### Things to Watch

- [ ] **Sync Logs**: Check for any failures
- [ ] **Error Log**: Look for Python exceptions
- [ ] **WordPress Logs**: Check for PHP errors
- [ ] **Data Accuracy**: Spot-check synced records
- [ ] **Performance**: Monitor sync execution times

### Where to Check

1. **Frappe Side:**
   - WP Sync Log (all sync attempts)
   - Error Log (Python exceptions)
   - System Console (live errors)

2. **WordPress Side:**
   - Debug log (if WP_DEBUG enabled)
   - Error log (PHP errors)
   - Server logs (if accessible)

---

## Troubleshooting

### Issue: "Connection test failed"

**Possible causes:**
- Wrong URL or credentials
- Plugin not activated
- WordPress site unreachable
- Security plugin blocking API

**Solutions:**
1. Double-check all credentials
2. Verify plugin is active in WP admin
3. Test endpoint manually with curl
4. Check WordPress security plugins settings

### Issue: "401 Unauthorized"

**Cause:** Authentication failure

**Solutions:**
1. Regenerate Application Password
2. Ensure username matches WordPress account
3. Check for spaces in copied password
4. Try a different user (with admin role)

### Issue: "Table not found"

**Cause:** Wrong table name in sync task

**Solutions:**
1. Check table name includes prefix (usually `wp_`)
2. Verify table exists in WordPress database
3. Test query manually via API endpoint

### Issue: "Sync runs but no data appears"

**Possible causes:**
- WHERE clause filters out all rows
- Field mapping mismatch
- Target DocType permissions issue
- Data type conversion errors

**Solutions:**
1. Check sync log for row counts
2. Review field mapping in task
3. Check raw_data field for original data
4. Review error log for row-level errors

### Issue: "Timeout errors"

**Cause:** Query takes too long

**Solutions:**
1. Add WHERE clause to limit rows
2. Increase timeout in code (default: 30s)
3. Optimize WordPress database indexes
4. Break into multiple smaller tasks

---

## Rollback Plan

If something goes wrong and you need to rollback:

### Option 1: Revert Deployment

```bash
# Via Frappe Cloud console
bench --site your-site.frappe.cloud backup
bench --site your-site.frappe.cloud restore backup_file.sql
```

### Option 2: Rollback to v0.0.1

```bash
# In your nce repo
git checkout v0.0.1
git push origin main --force

# Then redeploy via Frappe Cloud
```

**Note:** v0.0.1 uses MySQL, so you'll need to reconfigure database credentials.

---

## Success Criteria

✅ Deployment is successful if:

1. **Connection test passes** in WP Sync Settings
2. **Manual sync completes** without errors
3. **Data appears** in target DocType
4. **Scheduled sync runs** automatically every 5 minutes
5. **No errors** in Frappe Error Log
6. **No errors** in WordPress logs

---

## Post-Deployment Tasks

### Immediate

- [ ] Inform team of deployment
- [ ] Document any issues encountered
- [ ] Update version number in tracking sheet
- [ ] Monitor for 24 hours

### Within 1 Week

- [ ] Review sync performance metrics
- [ ] Optimize WHERE clauses if needed
- [ ] Adjust sync interval if needed
- [ ] Create additional sync tasks (if planned)

### Ongoing

- [ ] Monitor sync logs weekly
- [ ] Rotate Application Passwords quarterly
- [ ] Review error logs monthly
- [ ] Plan for next features (bidirectional sync, etc.)

---

## Key Contacts

- **Frappe Cloud Support**: support@frappe.cloud
- **GitHub Repository**: https://github.com/oliver-nce/nce
- **Frappe Cloud Dashboard**: https://cloud.frappe.io/dashboard/groups/bench-29150

---

## Quick Reference

### Important URLs

| Resource | URL |
|----------|-----|
| Frappe Cloud Bench | https://cloud.frappe.io/dashboard/groups/bench-29150 |
| GitHub Repo | https://github.com/oliver-nce/nce |
| WP REST Endpoint | `https://[your-site]/wp-json/custom/v1/sql-query` |

### Important Files

| File | Purpose |
|------|---------|
| `wp_sync_settings.py` | API connection logic |
| `tasks.py` | Sync logic |
| `custom-sql-endpoint.php` | WordPress plugin |
| `requirements.txt` | Python dependencies |

### Important Commands

```bash
# Test sync manually
frappe.call("nce.wp_sync.api.run_task", task_name="YOUR_TASK_NAME")

# Check sync status
frappe.call("nce.wp_sync.api.get_sync_status")

# Test connection
frappe.call("nce.wp_sync.api.test_wp_connection")

# Run all tasks
frappe.call("nce.wp_sync.api.run_all_tasks")
```

---

**Deployment Date:** ________________

**Deployed By:** ________________

**Status:** ⬜ Successful  ⬜ Issues (document below)

**Notes:**
```
[Add any deployment notes here]
```

---

*Last updated: 2025-12-28*

