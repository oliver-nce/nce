# Session Handoff - 2025-12-28

## Project: NCE Frappe App (WordPress to Frappe Data Sync)

---

## Summary

Built a Frappe app to sync data from WordPress database to Frappe DocTypes. The app is deployed on Frappe Cloud but needs modification to use REST API instead of direct MySQL (due to WP Engine restrictions).

---

## What Was Built

### Frappe App Structure

```
nce/
├── nce/
│   ├── __init__.py              # Version 0.0.1
│   ├── hooks.py                 # Scheduler (every 5 min)
│   ├── modules.txt              # "WP Sync" module
│   ├── patches.txt
│   │
│   └── wp_sync/                 # Main module
│       ├── api.py               # REST API endpoints
│       ├── tasks.py             # Sync logic
│       │
│       └── doctype/
│           ├── wp_sync_settings/    # Config (DB credentials)
│           ├── wp_sync_task/        # Task definitions
│           ├── wp_sync_log/         # Execution logs
│           └── wp_zoho_registration/ # Mirror table
│
├── setup.py
├── requirements.txt
├── MANIFEST.in
├── license.txt
├── .gitignore
└── README.md
```

### DocTypes Created

| DocType | Purpose |
|---------|---------|
| **WP Sync Settings** | Global config (was DB credentials, needs to be REST API config) |
| **WP Sync Task** | Task definitions with field mappings |
| **WP Sync Log** | Execution history |
| **WP Zoho Registration** | Mirror of `wp_zoho_registrations_new_site` |

---

## Deployment Status

| Item | Status |
|------|--------|
| GitHub Repo | ✅ `https://github.com/oliver-nce/nce` (branch: `main`) |
| Frappe Cloud | ✅ Deployed on `NCESoccer - Application / NCE Group` |
| App Installed | ✅ `nce` app deployed |
| DocTypes Available | ✅ Should be accessible in Frappe site |

---

## What Needs to Change

### Problem
WP Engine (shared hosting) doesn't allow direct MySQL connections. Requires SSH tunnel.

### Solution
User has a **Custom SQL Endpoint** WordPress plugin that exposes:
```
POST https://[site]/wp-json/custom/v1/sql-query
```

This allows SELECT queries via REST API.

### Changes Required

1. **Update `WP Sync Settings` DocType:**
   - Remove: `wp_db_host`, `wp_db_port`, `wp_db_name`, `wp_db_user`, `wp_db_password`
   - Add: `wp_api_url`, `wp_api_key` (or other auth method)

2. **Update `wp_sync_settings.py`:**
   - Replace `get_wp_connection()` (MySQL) with `call_wp_api()` (HTTP)

3. **Update `tasks.py`:**
   - Change `sync_wp_to_frappe()` to use REST API instead of direct SQL

---

## Information Still Needed

### About the Custom SQL Endpoint Plugin

1. **Full endpoint URL:**
   ```
   https://[yoursite].com/wp-json/custom/v1/sql-query
   ```

2. **Authentication method:**
   - API key in header?
   - WordPress application password?
   - No auth (restricted by IP)?

3. **Request format:**
   ```json
   POST /wp-json/custom/v1/sql-query
   {
     "query": "SELECT * FROM wp_zoho_registrations_new_site"
   }
   ```

4. **Response format:**
   ```json
   {
     "success": true,
     "data": [...]
   }
   ```

5. **Plugin PHP code location:**
   ```
   wp-content/plugins/custom-sql-endpoint/
   ```

### About the Target Table

Need schema for `wp_zoho_registrations_new_site`:
```sql
DESCRIBE wp_zoho_registrations_new_site;
```

---

## Files Location

### New Project Folder
User moved the project to a new folder. The Frappe app code should be cloned from:
```
git clone https://github.com/oliver-nce/nce.git
```

### Old Location (files deleted)
```
/Users/oliver2/Documents/Code Projects/_Nce_Projects/Frappe/nce_frappe_app/
```

---

## Next Steps

1. **Clone the repo** to the new project folder:
   ```bash
   git clone https://github.com/oliver-nce/nce.git
   cd nce
   ```

2. **Get the Custom SQL Endpoint plugin code** to understand:
   - Authentication method
   - Request/response format

3. **Update the Frappe app** to use REST API:
   - Modify `WP Sync Settings` fields
   - Modify sync logic in `tasks.py`

4. **Get table schema** for `wp_zoho_registrations_new_site`

5. **Update `WP Zoho Registration` DocType** with correct fields

6. **Push changes** to GitHub

7. **Redeploy** on Frappe Cloud

---

## Key URLs

| Resource | URL |
|----------|-----|
| GitHub Repo | https://github.com/oliver-nce/nce |
| Frappe Cloud Bench | https://cloud.frappe.io/dashboard/groups/bench-29150 |
| WP REST Endpoint | `https://[site]/wp-json/custom/v1/sql-query` |

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                     FRAPPE CLOUD (nce app)                      │
├─────────────────────────────────────────────────────────────────┤
│  WP Sync Settings → stores API URL + auth key                  │
│  WP Sync Task → defines which tables to sync                   │
│  WP Zoho Registration → stores synced data                     │
│                                                                 │
│  Scheduled Job (every 5 min):                                   │
│  1. Read enabled tasks                                          │
│  2. For each task, call WP REST API                             │
│  3. Parse JSON response                                         │
│  4. Upsert into Frappe DocTypes                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ HTTP POST (with API key)
┌─────────────────────────────────────────────────────────────────┐
│              WORDPRESS (WP Engine)                              │
├─────────────────────────────────────────────────────────────────┤
│  Custom SQL Endpoint Plugin                                     │
│  POST /wp-json/custom/v1/sql-query                              │
│  Body: {"query": "SELECT * FROM table"}                         │
│  Response: {"success": true, "data": [...]}                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ Local MySQL connection
┌─────────────────────────────────────────────────────────────────┐
│              WORDPRESS DATABASE (MariaDB)                       │
├─────────────────────────────────────────────────────────────────┤
│  wp_zoho_registrations_new_site                                 │
│  (other tables to sync later)                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Context Documents

These files in the original Frappe folder contain Klaviyo API documentation that may be useful for reference but are not related to the Frappe app:
- `/context/` - Klaviyo API chunks
- `/docs/` - Klaviyo integration docs

---

*Last updated: 2025-12-28*

