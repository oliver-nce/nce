# Architecture Documentation - REST API Sync

Visual documentation of how the NCE Frappe App syncs data from WordPress to Frappe using REST API.

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           FRAPPE CLOUD                                  │
│                     (NCE Soccer Application)                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │                     Frappe Scheduler                          │      │
│  │                    (Every 5 minutes)                          │      │
│  └────────────────────┬──────────────────────────────────────────┘      │
│                       │                                                 │
│                       ▼                                                 │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │              run_scheduled_sync()                             │      │
│  │              (tasks.py)                                       │      │
│  └────────────────────┬──────────────────────────────────────────┘      │
│                       │                                                 │
│                       ▼                                                 │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │           For each enabled WP Sync Task:                      │      │
│  │                                                               │      │
│  │  1. Build SQL query from task config                         │      │
│  │  2. Call execute_wp_query(sql)                               │      │
│  │  3. Parse JSON response                                       │      │
│  │  4. Map fields (WP → Frappe)                                 │      │
│  │  5. Upsert into DocType                                       │      │
│  │  6. Log results                                               │      │
│  └────────────────────┬──────────────────────────────────────────┘      │
│                       │                                                 │
│                       ▼                                                 │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │          execute_wp_query(sql)                                │      │
│  │          (wp_sync_settings.py)                                │      │
│  │                                                               │      │
│  │  • Reads WP Sync Settings (URL, username, password)          │      │
│  │  • Constructs POST request                                    │      │
│  │  • Adds HTTP Basic Auth                                       │      │
│  │  • Sends to WordPress REST API                                │      │
│  │  • Returns result array                                       │      │
│  └────────────────────┬──────────────────────────────────────────┘      │
│                       │                                                 │
└───────────────────────┼─────────────────────────────────────────────────┘
                        │
                        │ HTTPS POST (Application Password Auth)
                        │
                        ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                       WORDPRESS (WP Engine)                             │
│                      https://yoursite.com                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │           WordPress REST API                                  │      │
│  │           /wp-json/custom/v1/sql-query                        │      │
│  │                                                               │      │
│  │  1. Validate authentication (Application Password)            │      │
│  │  2. Check user permissions (must have 'read' capability)      │      │
│  │  3. Route to plugin callback                                  │      │
│  └────────────────────┬──────────────────────────────────────────┘      │
│                       │                                                 │
│                       ▼                                                 │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │      Custom SQL Endpoint Plugin                               │      │
│  │      (custom-sql-endpoint.php)                                │      │
│  │                                                               │      │
│  │  1. Extract 'sql' parameter from request                      │      │
│  │  2. Validate query (must start with SELECT or CALL)           │      │
│  │  3. Execute query using $wpdb                                 │      │
│  │  4. Format results as associative array                       │      │
│  │  5. Return JSON response                                       │      │
│  └────────────────────┬──────────────────────────────────────────┘      │
│                       │                                                 │
│                       ▼                                                 │
│  ┌──────────────────────────────────────────────────────────────┐      │
│  │              WordPress Database (MySQL/MariaDB)               │      │
│  │                                                               │      │
│  │  • wp_zoho_registrations_new_site                            │      │
│  │  • wp_posts                                                   │      │
│  │  • wp_users                                                   │      │
│  │  • (other WordPress tables)                                   │      │
│  └──────────────────────────────────────────────────────────────┘      │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Request/Response Flow

### 1. Frappe Initiates Sync

```python
# Frappe: tasks.py
query = "SELECT * FROM wp_zoho_registrations_new_site WHERE created_at > '2025-01-01'"
rows = execute_wp_query(query)
```

### 2. API Call Details

```http
POST https://yoursite.com/wp-json/custom/v1/sql-query HTTP/1.1
Host: yoursite.com
Content-Type: application/json
Authorization: Basic dXNlcm5hbWU6YXBwbGljYXRpb25fcGFzc3dvcmQ=

{
  "sql": "SELECT * FROM wp_zoho_registrations_new_site WHERE created_at > '2025-01-01'"
}
```

### 3. WordPress Processing

```php
// WordPress: custom-sql-endpoint.php
function execute_sql_query($request) {
    global $wpdb;
    
    // Get query from request
    $params = $request->get_json_params();
    $query = $params['sql'];
    
    // Validate query type
    if (stripos($query, 'SELECT') !== 0 && stripos($query, 'CALL') !== 0) {
        return new WP_Error('invalid_query', 'Only SELECT or CALL queries allowed');
    }
    
    // Execute query
    $results = $wpdb->get_results($query, ARRAY_A);
    
    // Return results
    return new WP_REST_Response(['result' => $results], 200);
}
```

### 4. API Response

```json
{
  "result": [
    {
      "id": "123",
      "first_name": "John",
      "last_name": "Doe",
      "email": "john@example.com",
      "phone": "555-1234",
      "program_name": "Summer Camp 2025",
      "amount": "499.00",
      "status": "paid",
      "created_at": "2025-01-15 10:30:00",
      "updated_at": "2025-01-15 10:30:00"
    },
    {
      "id": "124",
      "first_name": "Jane",
      "last_name": "Smith",
      "email": "jane@example.com",
      "phone": "555-5678",
      "program_name": "Winter Training",
      "amount": "299.00",
      "status": "pending",
      "created_at": "2025-01-16 14:20:00",
      "updated_at": "2025-01-16 14:20:00"
    }
  ]
}
```

### 5. Frappe Processing

```python
# Frappe: tasks.py
for row in rows:
    source_id = row['id']
    
    # Check if exists
    existing = frappe.db.exists("WP Zoho Registration", {"wp_source_id": source_id})
    
    # Build values based on field mapping
    values = {
        "wp_source_id": row['id'],
        "first_name": row['first_name'],
        "last_name": row['last_name'],
        "email": row['email'],
        "phone": row['phone'],
        "program_name": row['program_name'],
        "amount": row['amount'],
        "status": row['status'],
        "wp_created_at": row['created_at'],
        "wp_updated_at": row['updated_at'],
        "raw_data": json.dumps(row),
        "synced_at": now_datetime()
    }
    
    if existing:
        # Update existing record
        doc = frappe.get_doc("WP Zoho Registration", existing)
        for field, value in values.items():
            if field != "wp_source_id":
                setattr(doc, field, value)
        doc.save(ignore_permissions=True)
    else:
        # Insert new record
        values["doctype"] = "WP Zoho Registration"
        doc = frappe.get_doc(values)
        doc.insert(ignore_permissions=True)
```

---

## Data Flow Diagram

```
WordPress DB                    REST API                    Frappe DB
─────────────                  ──────────                  ──────────

wp_zoho_registrations          Custom SQL                  WP Zoho Registration
┌─────────────────┐            Endpoint                    ┌──────────────────┐
│ id: 123         │                                         │ name: "REG-001"  │
│ first_name: "J" │────────┐                               │ wp_source_id: 123│
│ last_name: "D"  │        │   HTTP POST                   │ first_name: "J"  │
│ email: "j@..."  │        └──► /wp-json/.../sql-query ───►│ last_name: "D"   │
│ phone: "555..." │            (with auth)                  │ email: "j@..."   │
│ created_at: ... │                                         │ phone: "555..."  │
│ ...             │            JSON Response                │ synced_at: ...   │
└─────────────────┘        ◄───────────────────────────────│ raw_data: {...}  │
                                                            └──────────────────┘
                           Field Mapping:
                           ─────────────────
                           id → wp_source_id
                           first_name → first_name
                           last_name → last_name
                           email → email
                           phone → phone
                           (auto-store raw_data)
                           (auto-set synced_at)
```

---

## Component Interactions

### DocTypes Involved

```
┌────────────────────────┐
│  WP Sync Settings      │  ← Stores API credentials
│  (Single DocType)      │
└───────────┬────────────┘
            │ reads
            ▼
┌────────────────────────┐
│  WP Sync Task          │  ← Defines sync tasks
│  (Multiple records)    │
│                        │
│  - source_table        │
│  - target_doctype      │
│  - field_mapping       │
│  - where_clause        │
│  - enabled             │
└───────────┬────────────┘
            │ executes
            ▼
┌────────────────────────┐
│  WP Sync Log           │  ← Records execution history
│  (Auto-created)        │
│                        │
│  - started_at          │
│  - completed_at        │
│  - status              │
│  - rows_processed      │
│  - error_message       │
└────────────────────────┘

            │ syncs to
            ▼
┌────────────────────────┐
│  WP Zoho Registration  │  ← Mirror of WordPress table
│  (Synced records)      │
│                        │
│  - wp_source_id        │
│  - first_name          │
│  - last_name           │
│  - email               │
│  - raw_data            │
│  - synced_at           │
└────────────────────────┘
```

---

## Authentication Flow

```
┌─────────────────────────────────────────────────────────────┐
│ Step 1: Create Application Password in WordPress           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  WordPress Admin → Users → Profile                          │
│                                                             │
│  Application Name: "Frappe Sync"                            │
│  Generated Password: "abcd efgh ijkl mnop qrst uvwx"        │
│  (24 characters, space-separated)                           │
│                                                             │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      │ Store credentials
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 2: Store in Frappe WP Sync Settings                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  wp_site_url: "https://yoursite.com"                        │
│  wp_username: "admin"                                       │
│  wp_app_password: "abcd efgh ijkl mnop qrst uvwx"          │
│  (Frappe encrypts the password)                             │
│                                                             │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      │ Use for API calls
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 3: HTTP Basic Authentication                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Username: admin                                            │
│  Password: abcdefghijklmnopqrstuvwx (spaces removed)        │
│                                                             │
│  Base64: dXNlcm5hbWU6cGFzc3dvcmQ=                           │
│                                                             │
│  Header: Authorization: Basic dXNlcm5hbWU6cGFzc3dvcmQ=     │
│                                                             │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      │ Validate
                      ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 4: WordPress Validates                                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  WordPress REST API Framework:                              │
│  1. Extracts credentials from header                        │
│  2. Validates against wp_usermeta table                     │
│  3. Checks user capabilities (needs 'read')                 │
│  4. If valid: Proceed to endpoint                           │
│  5. If invalid: Return 401 Unauthorized                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Error Handling

```
┌──────────────────────────────────────────────────────────────┐
│                    Frappe Side                               │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  try:                                                        │
│      response = requests.post(endpoint, ...)                 │
│      response.raise_for_status()  # Check HTTP status        │
│      data = response.json()       # Parse JSON               │
│                                                              │
│      if "code" in data:           # WordPress error format   │
│          raise Exception(data["message"])                    │
│                                                              │
│      return data["result"]                                   │
│                                                              │
│  except requests.exceptions.RequestException as e:           │
│      frappe.throw(f"API request failed: {e}")               │
│                                                              │
│  except ValueError as e:                                     │
│      frappe.throw(f"Failed to parse response: {e}")         │
│                                                              │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                  WordPress Side                              │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  // Validate query type                                      │
│  if (stripos($query, 'SELECT') !== 0) {                      │
│      return new WP_Error(                                    │
│          'invalid_query',                                    │
│          'Only SELECT or CALL queries allowed',              │
│          ['status' => 400]                                   │
│      );                                                      │
│  }                                                           │
│                                                              │
│  // Execute query                                            │
│  $results = $wpdb->get_results($query, ARRAY_A);            │
│                                                              │
│  // Check for database errors                                │
│  if ($wpdb->last_error) {                                    │
│      return new WP_Error(                                    │
│          'query_error',                                      │
│          $wpdb->last_error,                                  │
│          ['status' => 500]                                   │
│      );                                                      │
│  }                                                           │
│                                                              │
└──────────────────────────────────────────────────────────────┘

Common Error Responses:
─────────────────────────

400 Bad Request:
{"code": "invalid_query", "message": "Only SELECT or CALL queries allowed"}

401 Unauthorized:
{"code": "rest_forbidden", "message": "Sorry, you are not allowed to do that"}

500 Internal Server Error:
{"code": "query_error", "message": "Table 'wp_invalid' doesn't exist"}
```

---

## Performance Considerations

### Bottlenecks

```
Frappe ──────► WordPress ──────► MySQL ──────► WordPress ──────► Frappe
        (1)            (2)            (3)            (4)

(1) Network latency: 10-50ms
(2) WordPress processing: 5-10ms
(3) MySQL query: 10-100ms (depends on query/indexes)
(4) JSON encoding: 5-10ms
(5) Network latency: 10-50ms

Total: ~40-220ms per request
```

### Optimization Strategies

1. **Limit Result Sets**
   ```sql
   SELECT * FROM wp_table 
   WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
   LIMIT 1000
   ```

2. **Use Indexes**
   ```sql
   ALTER TABLE wp_zoho_registrations_new_site 
   ADD INDEX idx_created_at (created_at);
   ```

3. **Batch Processing**
   - Sync in chunks of 100-1000 rows
   - Use multiple sync tasks with different WHERE clauses

4. **Cache Results** (future enhancement)
   - Cache frequent queries
   - Use ETags for conditional requests

---

## Security Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Security Layers                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Layer 1: Transport Security                                │
│  ─────────────────────────                                  │
│  • HTTPS/TLS encryption for all API calls                   │
│  • Prevents man-in-the-middle attacks                       │
│  • Certificate validation                                   │
│                                                             │
│  Layer 2: Authentication                                    │
│  ────────────────────────                                   │
│  • WordPress Application Passwords                          │
│  • HTTP Basic Auth (Base64 encoded)                         │
│  • No exposure of main WordPress password                   │
│  • Passwords stored encrypted in Frappe                     │
│                                                             │
│  Layer 3: Authorization                                     │
│  ───────────────────────                                    │
│  • WordPress user capabilities check ('read' permission)    │
│  • Plugin permission_callback enforced                      │
│  • User must be authenticated WordPress user                │
│                                                             │
│  Layer 4: Query Validation                                  │
│  ──────────────────────                                     │
│  • Only SELECT and CALL queries allowed                     │
│  • Blocks INSERT, UPDATE, DELETE, DROP, etc.                │
│  • Prevents data modification                               │
│                                                             │
│  Layer 5: WordPress Security                                │
│  ────────────────────────────                               │
│  • WordPress nonce validation (built-in)                    │
│  • Rate limiting (if configured)                            │
│  • Security plugins (if installed)                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Comparison: Old vs New Architecture

### Old (v0.0.1): Direct MySQL

```
Frappe ──────────────────► MySQL (WordPress DB)
        Direct TCP
        Port 3306

Pros:
✓ Faster (no HTTP overhead)
✓ Direct database access

Cons:
✗ Requires external MySQL access
✗ Complex firewall configuration
✗ IP whitelisting needed
✗ Not supported on WP Engine
✗ Security risk (exposed database)
```

### New (v0.0.2): REST API

```
Frappe ────► WordPress ────► MySQL
       HTTPS      Local

Pros:
✓ Works everywhere (WP Engine, shared hosting)
✓ Simpler configuration
✓ WordPress handles security
✓ No firewall changes needed
✓ Application Passwords (revocable)
✓ WordPress security plugins protect endpoint

Cons:
✗ Slightly slower (HTTP overhead)
✗ Depends on WordPress availability
```

---

## Future Enhancements

### Planned Features

1. **Pagination Support**
   ```python
   def execute_wp_query_paginated(sql, page_size=100):
       offset = 0
       while True:
           query = f"{sql} LIMIT {page_size} OFFSET {offset}"
           rows = execute_wp_query(query)
           if not rows:
               break
           yield rows
           offset += page_size
   ```

2. **Query Caching**
   ```python
   @frappe.cache(ttl=300)  # 5 minute cache
   def execute_wp_query_cached(sql):
       return execute_wp_query(sql)
   ```

3. **Retry Logic**
   ```python
   @retry(max_attempts=3, backoff=2)
   def execute_wp_query_with_retry(sql):
       return execute_wp_query(sql)
   ```

4. **Bidirectional Sync** (Frappe → WordPress)
   - Requires different plugin endpoint (POST data to WP)
   - Conflict resolution strategy
   - Last-write-wins or manual resolution

---

*Last updated: 2025-12-28*

