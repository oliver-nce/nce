# Session Handoff - 2025-12-29

## Project: NCE Frappe App (WordPress to Frappe Data Sync)

---

## Current Status: ⚠️ BLOCKED - WordPress Site Down

**Blocker:** WordPress site (ncesoccer.com) is currently down due to DNS server migration. Cannot test connection until site is back online.

---

## What Was Accomplished This Session

### 1. ✅ Created JavaScript Handler for Test Connection Button

**Problem:** Test Connection button on WP Sync Settings page did nothing when clicked.

**Root Cause:** 
- The DocType JSON defined a Button field (`test_connection_button`)
- But there was no JavaScript to handle clicks on that button
- Initial fix attempt tried to add a SECOND button (wrong approach)
- Correct fix: Handle the existing button field's click event

**Solution Implemented:**
- Created `wp_sync_settings.js` with proper event handler
- File location: `nce/wp_sync/doctype/wp_sync_settings/wp_sync_settings.js`
- Uses `test_connection_button: function(frm)` to handle button clicks
- Validates required fields before making API call
- Shows loading/success/error messages appropriately

**Commits:**
1. `2fd8488` - Initial JS file (wrong approach - added duplicate button)
2. `454997e` - Fixed JS file (correct approach - handles existing button)

**Deployment:** 
- Successfully deployed to Frappe Cloud Bench Group
- Verified in deployment logs that build completed successfully
- Button now triggers and makes API call correctly

### 2. ✅ Fixed Deployment Issues

**Problems Encountered:**
- Initially tried to deploy from wrong git repository (parent Frappe folder instead of nce_frappe_app subfolder)
- GitHub remote was not configured in parent folder
- VS Code was open to wrong directory

**Solution:**
- Identified correct repository: `/Users/oliver2/Library/Mobile Documents/com~apple~CloudDocs/_NCE_projects/Frappe/nce_frappe_app/`
- GitHub remote: `https://github.com/oliver-nce/nce.git`
- Pushed commits successfully from terminal

### 3. ✅ Learned Frappe Cloud Deployment Process

**Correct Process (Verified from Documentation):**

1. **Push code to GitHub**
2. **Fetch updates in Frappe Cloud:**
   - Go to Bench Groups → NCE Group → Apps tab
   - Click three-dot menu (⋮) next to NCE app
   - Click "Fetch Latest Updates"
   - Status changes to "Update Available"
3. **Deploy:**
   - Go to Deploys tab or click "Deploy" when available
   - Select which apps to update
   - Click "Deploy and update site"
4. **Wait for completion:**
   - Deployment takes 2-5 minutes
   - Rebuilds ALL apps on the bench (not just changed apps)
   - Check Deploys tab for "Success" status

**Important Notes:**
- Deploying a bench rebuilds ALL apps (Frappe, ERPNext, custom apps)
- No verified way to update only custom apps without rebuilding everything
- This makes rapid iteration slow (2-5 min per deploy)
- For faster development: work locally, deploy to cloud less frequently

---

## Current Configuration

### Frappe Cloud Setup

**Site:** `nce-sync.v.frappe.cloud` (previously ncesoccer.v.frappe.cloud, recreated)
**Bench Group:** NCE Group
**Region:** N. Virginia, USA
**Plan:** Unlimited - Supported

**Apps Installed:**
- Frappe Framework (required)
- ERPNext (not needed for this project, but installed)
- Frappe CRM
- Frappe Insights
- Frappe HR
- Sheets
- **NCE** (custom app from GitHub)

**GitHub Integration:**
- Repository: `https://github.com/oliver-nce/nce`
- Branch: `main`
- Current Commit: `454997e` (Fix: Handle button click event correctly)

### WordPress Configuration

**Site URL:** `https://ncesoccer.com`
**Username:** `oreid@firstgm.com`
**Application Password:** Configured in Frappe (VH0J XVL9 P9Fk 6B9n IP0h An6y)

**Plugin Status:** ⚠️ **UNKNOWN** - Site down, cannot verify
- Plugin file exists: `custom-sql-endpoint/custom-sql-endpoint.php`
- Needs to be uploaded to: `wp-content/plugins/custom-sql-endpoint/`
- Must be activated in WordPress admin

### Site Login

**Admin User Email:** Setup was attempted with multiple emails:
- `gcloud@fmpconnect.com` (from initial site creation)
- `oliver@fmpconnect.com` (Frappe Cloud account)

**Login Method:** Email link login (no password set)
- Go to site URL → Click "Login with Email Link"
- Enter email → Check inbox → Click link

---

## Current Issue: WordPress Site Down

### Error Observed

When clicking Test Connection button in Frappe:
```
API request failed: ('Connection aborted.', HTTPException('got more than 100 headers'))
```

When testing with curl:
- Connection established to server
- SSL handshake successful
- Request sent
- **Server never responds** (hangs indefinitely)

WordPress admin also returns 502 Bad Gateway errors.

### Root Cause

User confirmed: **DNS server migration in progress** for ncesoccer.com

### What This Means

- The WordPress REST API endpoint cannot be reached
- Cannot verify if Custom SQL Endpoint plugin is installed/activated
- Cannot test the Frappe sync functionality
- **BLOCKER:** Must wait for DNS propagation and site restoration

---

## Next Steps (When WordPress Site is Back Online)

### 1. Verify WordPress Site is Working

```bash
# Test basic connectivity
curl -I https://ncesoccer.com

# Should return 200 OK, not 502
```

### 2. Verify Plugin is Installed

1. Log into WordPress admin: `https://ncesoccer.com/wp-admin`
2. Go to: Plugins → Installed Plugins
3. Look for: "Custom SQL Endpoint"
4. If not there:
   - Upload file: `custom-sql-endpoint/custom-sql-endpoint.php`
   - Place in: `wp-content/plugins/custom-sql-endpoint/`
   - Activate via WordPress admin

### 3. Test Plugin Directly

```bash
curl -X POST https://ncesoccer.com/wp-json/custom/v1/sql-query \
  -u "oreid@firstgm.com:VH0J XVL9 P9Fk 6B9n IP0h An6y" \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT 1 as test"}' \
  -v
```

**Expected Response:**
```json
{"result":[{"test":"1"}]}
```

### 4. Test Connection from Frappe

1. Go to: `https://nce-sync.v.frappe.cloud/app/wp-sync-settings`
2. Log in with email link
3. Verify credentials are filled in:
   - WordPress Site URL: `https://ncesoccer.com`
   - WordPress Username: `oreid@firstgm.com`
   - Application Password: (already saved)
4. Click **"Test Connection"** button
5. Should see: "Connection Successful!" alert

### 5. Configure First Sync Task

Once connection works, create a sync task:

1. Go to: **WP Sync Task** DocType
2. Click: **New**
3. Configure:
   - Task Name: e.g., "Sync Zoho Registrations"
   - SQL Query: `SELECT * FROM wp_zoho_registrations_new_site`
   - Target DocType: `WP Zoho Registration`
   - Field Mappings: Map WordPress columns to Frappe fields
4. Save
5. Test manually first before enabling scheduled sync

---

## Important Files and Locations

### Local Project Structure

```
/Users/oliver2/Library/Mobile Documents/com~apple~CloudDocs/_NCE_projects/Frappe/
├── custom-sql-endpoint/
│   └── custom-sql-endpoint.php          # WordPress plugin
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DEPLOYMENT-CHECKLIST.md
│   ├── QUICK-START.md
│   └── SESSION-HANDOFF-2025-12-29.md    # This file
└── nce_frappe_app/                      # MAIN GIT REPOSITORY
    ├── .git/                            # Git repo is HERE, not in parent
    ├── nce/
    │   ├── hooks.py
    │   └── wp_sync/
    │       ├── api.py
    │       ├── tasks.py
    │       └── doctype/
    │           ├── wp_sync_settings/
    │           │   ├── wp_sync_settings.py        # Backend logic
    │           │   ├── wp_sync_settings.js        # Frontend button handler
    │           │   └── wp_sync_settings.json      # DocType definition
    │           ├── wp_sync_task/
    │           ├── wp_sync_log/
    │           └── wp_zoho_registration/
    ├── setup.py
    └── requirements.txt
```

### Key Files Modified This Session

1. **wp_sync_settings.js** - Created and fixed
   - Handles Test Connection button clicks
   - Current version: `454997e`

### GitHub Repository

**Location:** `https://github.com/oliver-nce/nce`
**Branch:** `main`
**Latest Commit:** `454997e` - Fix: Handle button click event correctly

---

## How to Make Code Changes and Deploy

### 1. Navigate to Correct Directory

```bash
cd "/Users/oliver2/Library/Mobile Documents/com~apple~CloudDocs/_NCE_projects/Frappe/nce_frappe_app"
```

⚠️ **CRITICAL:** Git repo is in `nce_frappe_app/`, NOT in parent `Frappe/` folder!

### 2. Make Changes

Edit files as needed in `nce/` directory

### 3. Commit and Push

```bash
git add .
git commit -m "Description of changes"
git push origin main
```

### 4. Deploy to Frappe Cloud

1. Open: https://frappecloud.com/dashboard
2. Navigate to: **Bench Groups** (in left sidebar)
3. Click on: **NCE Group**
4. Go to: **Apps** tab
5. Click three-dot menu (⋮) next to **NCE** app
6. Click: **"Fetch Latest Updates"**
7. Wait for "Update Available" to appear
8. Click: **"Deploy"** (or similar button)
9. Select apps to update (usually just select all)
10. Click: **"Deploy and update site"**
11. Wait 2-5 minutes for completion
12. Check: **Deploys** tab for "Success" status

### 5. Test Changes

1. Go to site: `https://nce-sync.v.frappe.cloud`
2. **Hard refresh:** Cmd+Shift+R (Mac) or Ctrl+Shift+F5 (Windows)
3. Test your changes

---

## Known Issues and Gotchas

### 1. Frappe Cloud Dashboard vs Site

**Two Different Places:**
- **Frappe Cloud Dashboard:** For managing infrastructure (bench groups, deployments, apps)
- **Frappe Site:** The actual application (where you configure WP Sync Settings)

Different login credentials:
- Cloud Dashboard: Frappe Cloud account (`oliver@fmpconnect.com` or `gcloud@fmpconnect.com`)
- Site: Site-specific users (email link login)

### 2. Deployment Rebuilds All Apps

- Deploying a bench rebuilds ALL apps, not just the one that changed
- Includes: Frappe Framework, ERPNext, all custom apps
- Takes 2-5 minutes even for one-line code changes
- **No verified way to update only custom apps**

**For faster development:**
- Develop locally with bench/Frappe Framework installed
- Only deploy to cloud when ready for testing/production

### 3. JavaScript Files Need to Match Button Field Names

The JavaScript event handler name must match the fieldname in JSON:

**JSON (wp_sync_settings.json):**
```json
{
    "fieldname": "test_connection_button",
    "fieldtype": "Button",
    "label": "Test Connection"
}
```

**JavaScript (wp_sync_settings.js):**
```javascript
frappe.ui.form.on('WP Sync Settings', {
    test_connection_button: function(frm) {  // Must match fieldname!
        // Handle click
    }
});
```

### 4. Button Field vs Custom Button

**Two ways to add buttons in Frappe:**

**Option A: Button Field (what we used)**
- Defined in DocType JSON
- Appears as a form field
- Needs JS to handle clicks
- Use `fieldname: function(frm)` in JS

**Option B: Custom Button**
- Added dynamically via JS
- Use `frm.add_custom_button()`
- Can appear in different locations (toolbar, sidebar)

We use Option A (Button Field) for Test Connection.

### 5. Site Creation Issues

Original site (`ncesoccer.v.frappe.cloud`) had issues:
- No admin user was created during site creation
- Had to create new site (`nce-sync.v.frappe.cloud`)

**Lesson:** Verify site login works immediately after creation.

---

## WordPress Plugin Details

### Plugin Code Location

Local: `/Users/oliver2/Library/Mobile Documents/com~apple~CloudDocs/_NCE_projects/Frappe/custom-sql-endpoint/custom-sql-endpoint.php`

### Plugin Purpose

Exposes a REST API endpoint that accepts SQL queries and executes them against the WordPress database.

**Endpoint:** `POST /wp-json/custom/v1/sql-query`

**Authentication:** WordPress Application Passwords (HTTP Basic Auth)

**Request Format:**
```json
{
  "sql": "SELECT * FROM wp_table_name WHERE condition"
}
```

**Response Format:**
```json
{
  "result": [
    {"column1": "value1", "column2": "value2"},
    ...
  ]
}
```

### Security Notes

- Only accepts SELECT and CALL statements (no INSERT/UPDATE/DELETE/DROP)
- Uses WordPress's built-in authentication
- Requires admin/read permissions
- Should NOT be exposed publicly without proper security

---

## Testing Checklist

Once WordPress site is back online, verify each of these:

- [ ] WordPress site loads: `https://ncesoccer.com`
- [ ] WordPress admin accessible: `https://ncesoccer.com/wp-admin`
- [ ] Custom SQL Endpoint plugin installed and activated
- [ ] Test plugin directly with curl (returns JSON result)
- [ ] Frappe site accessible: `https://nce-sync.v.frappe.cloud`
- [ ] Can log into Frappe site (email link method)
- [ ] WP Sync Settings page accessible
- [ ] All credentials filled in correctly
- [ ] Test Connection button triggers (shows loading message)
- [ ] Test Connection succeeds (shows success alert)
- [ ] Connection Status field updates to "Connected Successfully"
- [ ] Create test sync task
- [ ] Run sync task manually
- [ ] Verify data appears in target DocType
- [ ] Check WP Sync Log shows success
- [ ] Enable scheduled sync
- [ ] Wait 5 minutes, verify auto-sync runs

---

## User Preferences and Important Notes

### Communication Style

**User prefers:**
- Direct, verified answers only
- NO GUESSING or speculative suggestions
- When unsure, search documentation FIRST, then answer
- Never say "look for" or "check if" without verifying it exists first
- Be honest when you don't know something

**User dislikes:**
- Being asked to repeatedly check obvious places
- Unverified suggestions that waste time
- Guessing at solutions without checking documentation
- Making assumptions about what exists in UI/menus

### User's Development Setup

- macOS (darwin 25.0.0)
- Shell: zsh
- Editor: VS Code / Cursor
- Browser: Chrome (for testing)

---

## Useful URLs

| Resource | URL |
|----------|-----|
| Frappe Cloud Dashboard | https://frappecloud.com/dashboard |
| Bench Group | https://cloud.frappe.io/dashboard/groups/bench-29150 |
| GitHub Repository | https://github.com/oliver-nce/nce |
| Frappe Site | https://nce-sync.v.frappe.cloud |
| WordPress Site | https://ncesoccer.com |
| WordPress Admin | https://ncesoccer.com/wp-admin |
| WP Sync Settings | https://nce-sync.v.frappe.cloud/app/wp-sync-settings |

---

## API Credentials

### Frappe Cloud Account
- Email: `gcloud@fmpconnect.com` or `oliver@fmpconnect.com`
- Login: Via Frappe Cloud dashboard

### Frappe Site
- Login Method: Email link (passwordless)
- Email: Try `gcloud@fmpconnect.com` or `oliver@fmpconnect.com`

### WordPress
- Site: https://ncesoccer.com
- Username: `oreid@firstgm.com`
- App Password: `VH0J XVL9 P9Fk 6B9n IP0h An6y`

### GitHub
- Repository: https://github.com/oliver-nce/nce
- Access: Via user's GitHub account (oliver-nce organization)

---

## Questions for User (When They Return)

1. Is ncesoccer.com back online after DNS migration?
2. Is the Custom SQL Endpoint plugin installed and activated on WordPress?
3. Does Test Connection work now?
4. What WordPress table(s) need to be synced to Frappe?
5. What is the schema of the target table(s)?
6. Should we remove unused apps (ERPNext, CRM, etc.) to speed up deployments?

---

*Last updated: 2025-12-29*
*Session completed by: Claude (Sonnet 4.5)*
*Next agent: Start with "Current Status" section and verify WordPress site is online before proceeding*

