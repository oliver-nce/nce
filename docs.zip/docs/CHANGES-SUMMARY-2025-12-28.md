# Changes Summary - REST API Migration

**Date:** 2025-12-28  
**Version:** 0.0.1 → 0.0.2  
**Purpose:** Migrate from direct MySQL connection to WordPress REST API

---

## Overview

Successfully migrated the NCE Frappe App from using direct MySQL database connections to using WordPress REST API via the Custom SQL Endpoint plugin. This makes the app compatible with WP Engine and other shared hosting providers.

---

## Files Modified

### 1. **`nce/wp_sync/doctype/wp_sync_settings/wp_sync_settings.json`**

**Changes:**
- Removed MySQL credential fields:
  - `wp_db_host`
  - `wp_db_port`
  - `wp_db_name`
  - `wp_db_user`
  - `wp_db_password`
  
- Added REST API credential fields:
  - `wp_site_url` (Data, required)
  - `wp_username` (Data, required)
  - `wp_app_password` (Password, required)

- Updated section label: "WordPress Database Connection" → "WordPress REST API Connection"

### 2. **`nce/wp_sync/doctype/wp_sync_settings/wp_sync_settings.py`**

**Changes:**
- Added imports:
  - `import requests`
  - `from requests.auth import HTTPBasicAuth`

- Removed `get_wp_connection()` function (MySQL connection)

- Added `execute_wp_query(sql_query)` function:
  - Makes POST request to `/wp-json/custom/v1/sql-query`
  - Uses HTTP Basic Auth with WordPress credentials
  - Returns list of dictionaries (query results)
  - Handles WordPress error responses
  - 30-second timeout

- Updated `test_connection()` method to use REST API

- Updated docstring: "WordPress database" → "WordPress REST API"

### 3. **`nce/wp_sync/tasks.py`**

**Changes:**
- Updated imports:
  - Removed: `get_wp_connection`
  - Added: `execute_wp_query`

- Refactored `sync_wp_to_frappe()` function:
  - Removed database connection/cursor management
  - Changed from `cursor.execute()` + `cursor.fetchall()` to `execute_wp_query()`
  - Removed `try/finally` block for connection cleanup
  - Kept all sync logic identical (field mapping, upsert, error handling)

### 4. **`requirements.txt`**

**Changes:**
- Removed: `pymysql>=1.0.0`
- Added: `requests>=2.31.0`

### 5. **`nce/__init__.py`**

**Changes:**
- Updated version: `"0.0.1"` → `"0.0.2"`

### 6. **`README.md`**

**Major updates:**
- Added subtitle: "via REST API"
- Added "WP Engine Compatible" feature
- Rewrote "Configuration" section:
  - Step 1: Install Custom SQL Endpoint plugin
  - Step 2: Create Application Password
  - Step 3: Configure API credentials
- Updated "DocTypes" table description
- Rewrote "Security Considerations" section
- Rewrote "Troubleshooting" section
- Added version history entry for 0.0.2

### 7. **`MIGRATION_TO_REST_API.md`** *(NEW)*

**Contents:**
- Complete migration guide
- Before/after comparison
- Step-by-step migration instructions
- Troubleshooting for common issues
- API endpoint reference
- Security notes
- Rollback instructions

---

## How It Works

### Old Architecture (v0.0.1)

```
Frappe Cloud → MySQL Connection → WordPress Database
```

**Pros:**
- Faster (direct connection)

**Cons:**
- Requires external MySQL access
- Needs IP whitelisting
- Not supported on WP Engine/shared hosting
- Complex firewall configuration

### New Architecture (v0.0.2)

```
Frappe Cloud → HTTPS POST → WordPress REST API → Custom SQL Endpoint Plugin → MySQL (local)
```

**Pros:**
- Works everywhere (WP Engine, shared hosting)
- Simpler configuration (no firewall rules)
- WordPress handles authentication
- Application Passwords are revocable

**Cons:**
- Slightly slower (HTTP overhead)

---

## API Flow

1. **Frappe** calls `execute_wp_query("SELECT * FROM wp_table")`
2. **Function** makes POST request:
   ```
   POST https://yoursite.com/wp-json/custom/v1/sql-query
   Content-Type: application/json
   Authorization: Basic base64(username:app_password)
   
   {"sql": "SELECT * FROM wp_table"}
   ```
3. **WordPress** validates authentication (Application Password)
4. **Plugin** validates query (only SELECT/CALL allowed)
5. **Plugin** executes query on local MySQL
6. **Plugin** returns JSON response:
   ```json
   {
     "result": [
       {"id": 1, "name": "John"},
       {"id": 2, "name": "Jane"}
     ]
   }
   ```
7. **Frappe** processes results (same as before)

---

## Custom SQL Endpoint Plugin

**File:** `custom-sql-endpoint/custom-sql-endpoint.php`

**Features:**
- Registers REST endpoint: `/wp-json/custom/v1/sql-query`
- Requires WordPress authentication (`current_user_can('read')`)
- Only allows SELECT and CALL queries (security)
- Returns results as associative arrays
- Error handling for invalid queries

**Code highlights:**
```php
// Only allow safe queries
if (stripos($query, 'SELECT') !== 0 && stripos($query, 'CALL') !== 0) {
    return new WP_Error('invalid_query', 'Only SELECT or CALL queries allowed');
}

// Execute and return results
$results = $wpdb->get_results($query, ARRAY_A);
return new WP_REST_Response(array('result' => $results), 200);
```

---

## Testing Checklist

Before deploying to production:

- [ ] Test connection in WP Sync Settings
- [ ] Run a sync task manually
- [ ] Verify data appears in target DocType
- [ ] Check WP Sync Log for success
- [ ] Enable scheduled sync
- [ ] Monitor logs for 24 hours
- [ ] Verify sync runs automatically

---

## Deployment Steps

### On Frappe Cloud

1. **Push to GitHub:**
   ```bash
   cd /path/to/nce_frappe_app
   git add .
   git commit -m "Migrate to REST API (v0.0.2)"
   git push origin main
   ```

2. **Deploy on Frappe Cloud:**
   - Go to bench dashboard
   - Trigger deploy
   - Wait for completion
   - Run migrate if needed

3. **Install WordPress Plugin:**
   - Upload `custom-sql-endpoint.php` to WordPress
   - Activate plugin

4. **Configure Credentials:**
   - Create Application Password in WordPress
   - Update WP Sync Settings in Frappe
   - Test connection

5. **Verify Sync:**
   - Run test sync
   - Check logs
   - Enable scheduled sync

---

## Compatibility

### WordPress Requirements
- WordPress 5.6+ (for Application Passwords)
- PHP 7.4+
- Custom SQL Endpoint plugin v1.2+
- HTTPS recommended (required for security)

### Frappe Requirements
- Frappe Framework 14+
- Python 3.8+
- `requests` library 2.31.0+

### Hosting Compatibility
- ✅ WP Engine
- ✅ Shared hosting
- ✅ VPS/Dedicated
- ✅ WordPress.com Business+
- ✅ Kinsta, Flywheel, etc.

---

## Performance Notes

### Expected Performance

| Metric | MySQL Direct | REST API | Impact |
|--------|-------------|----------|--------|
| Query time | ~50ms | ~200ms | +150ms overhead |
| Throughput | High | Medium | HTTP overhead |
| Scalability | Limited | Good | Stateless API |

### Optimization Tips

1. **Limit result sets:** Use WHERE clauses to filter data
2. **Batch processing:** Sync in smaller chunks
3. **Caching:** Consider caching frequent queries
4. **Indexes:** Ensure WordPress tables are indexed
5. **Schedule wisely:** Adjust sync interval based on load

---

## Security Improvements

### What's Better

✅ **No database credentials** stored in Frappe  
✅ **Application Passwords** are WordPress-managed and revocable  
✅ **WordPress authentication** leverages built-in security  
✅ **No firewall changes** needed  
✅ **WordPress security plugins** protect the endpoint  
✅ **Query restrictions** enforced by plugin (SELECT/CALL only)  

### Best Practices

1. **Use HTTPS** for WordPress site (always)
2. **Rotate passwords** regularly
3. **Limit permissions** (use read-only user if possible)
4. **Monitor logs** for suspicious queries
5. **Keep plugin updated** for security patches

---

## Known Limitations

1. **Query size:** Large result sets may hit PHP memory limits
   - **Solution:** Use LIMIT clauses, pagination

2. **Execution time:** PHP scripts may timeout on long queries
   - **Solution:** Adjust `max_execution_time` or optimize queries

3. **Rate limiting:** Some hosts limit API requests
   - **Solution:** Adjust sync interval or contact host

4. **Read-only:** Plugin only allows SELECT/CALL (by design)
   - **Note:** This is a security feature, not a limitation

---

## Next Steps

### Immediate (Required)

1. Deploy updated code to Frappe Cloud
2. Install plugin on WordPress
3. Configure API credentials
4. Test sync manually
5. Enable scheduled sync

### Future Enhancements (Optional)

1. Add pagination for large result sets
2. Add query caching layer
3. Add retry logic for failed API calls
4. Add monitoring/alerting for sync failures
5. Support bidirectional sync (Frappe → WP)

---

## Support & Documentation

- **Migration Guide:** `MIGRATION_TO_REST_API.md`
- **README:** Updated with REST API instructions
- **Plugin Code:** `custom-sql-endpoint/custom-sql-endpoint.php`
- **GitHub Repo:** https://github.com/oliver-nce/nce

---

## Changelog

### Version 0.0.2 (2025-12-28)

**Added:**
- REST API support via Custom SQL Endpoint plugin
- WordPress Application Password authentication
- `execute_wp_query()` function for API calls
- Migration guide document
- Enhanced error handling for API requests

**Changed:**
- WP Sync Settings fields (MySQL → API credentials)
- Dependency: pymysql → requests
- Sync logic to use REST API instead of direct MySQL

**Removed:**
- Direct MySQL connection code
- Database credential fields
- pymysql dependency

**Fixed:**
- Compatibility with WP Engine and shared hosting

---

*Changes completed: 2025-12-28*  
*Status: Ready for deployment*

